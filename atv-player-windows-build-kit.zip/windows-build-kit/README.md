# 独立播放器 Windows 版 — 本地打包 Kit

Mac 版已验证的同一套补丁 + Windows 版独立脚本，在 Windows 机器/VM 上打 PyInstaller 包。

## 0. 前置：先装编译环境（只做一次）

右键 `setup-env.bat` → **以管理员身份运行**。它会装：Git + uv + Python 3.12（uv 管理）+ VC++ 运行库，最后打印验证结果（git / uv / uv python 3.12 都应有输出）。

- 系统 Python 3.15 **保持不动**：构建强制用 Python 3.12（官方 CI 同款），`build-player-windows.ps1` 里已锁定 `UV_PYTHON=3.12`。不要把系统 Python 降级/卸载，也不要手动把 3.15 换成 3.12。
- 装完关掉所有 PowerShell 窗口再重开（让 PATH 生效），再做第 1 步。

手动等价命令（setup 脚本失败时用）：`winget install Git.Git`，`powershell -c "irm https://astral.sh/uv/install.ps1 | iex"`，`uv python install 3.12`。

## 1. 解压 + 运行

把本 kit 解到一个**纯英文、无空格**的目录，例如 `C:\player-win-kit`（不要放桌面中文路径下，避免编码问题），双击 `run-build.bat`。

它等价于：

```powershell
.\build-player-windows.ps1 -PatchesDir .\patches -SrcDir "$HOME\src\atv-player" -OutDir "$HOME\Desktop\player-win"
```

脚本会做：下载 `libmpv-2.dll`（官方 workflow 同款 + SHA256 校验）→ 源码 `git reset --hard v0.105.0` → 按固定顺序打补丁（v8 → 字幕关闭 → 右键菜单 → `mpv_widget.py` 覆盖 → on-render-v2 → 外挂字幕 v7）→ `uv sync` → PyInstaller 打包 → 输出 zip + 按实际路径生成的 `register-atvplayer-scheme.reg`。

⚠️ `git reset --hard` 会丢弃 `~/src/atv-player` 里未提交的改动，有重要改动先备份。

## 2. 产物（桌面 `player-win` 里）

- `ATVPlayer\ATVPlayer.exe` — 主程序（onedir，`libmpv-2.dll` 必须和它在同一目录，不要单独拷 exe）
- `ATVPlayer-0.105.0-windows-x64.zip` — 分发包
- `register-atvplayer-scheme.reg` — 备用：双击导入可手动注册 `atvplayer://`（只写 HKCU，不用管理员）。一般不用——播放器首次启动会自动把当前 exe 路径写入注册表自注册（缺失/路径变了都会重写），之后浏览器点 `atvplayer://` 直接调起。

## 3. 验收（按顺序，任何一步失败先停，把报错贴回来）

1. 双击 `ATVPlayer.exe`，启动器出现。
2. 播一个本地 `.mkv`：有画面 + 有声 + 底部控制条正常。
3. 播一个本地 `.iso`：能出菜单/正片，字幕/音频菜单能按语言选轨道。
4. 粘一个签名 URL（带 `?sign=` 的）：能播，不闪退回启动器。
5. 先双击跑一次 `ATVPlayer.exe`（首次启动即自注册 `atvplayer://`），再在浏览器地址栏输 `atvplayer://play?url=<一个能播的链接>`，应调起播放器并直接播。验证注册：`reg query "HKCU\Software\Classes\atvplayer\shell\open\command"` 应显示当前 exe 路径。
6. 外挂字幕（和 Intel 版同逻辑）：播一个本地视频，同目录放同名 `.ass`，右键菜单点“外挂字幕”，应直接加载并在字幕菜单里出现且被选中；无同名字幕时弹文件选择框手动挑。

## 4. 排障

| 现象 | 做法 |
|---|---|
| 双击 exe 闪退、无任何报错 | 用控制台版重打：`.\build-player-windows.ps1 -Console …`（参数同 run-build.bat），看控制台输出 |
| 报找不到 `libmpv-2.dll` / `Cannot find libmpv` | 确认 `libmpv-2.dll` 在 `ATVPlayer\` 或 `ATVPlayer\_internal\`（PyInstaller 6 把依赖放 `_internal\`，两个位置都正常）；不要单独拷 exe |
| `git apply` 失败 | 源码目录不是 pristine：先 `cd ~/src/atv-player; git status`，确认无未提交改动，再重跑 |
| SmartScreen 拦截（未签名 exe） | 点“更多信息 → 仍要运行” |
| 缺 `VCRUNTIME140.dll` 之类 | 装 Microsoft Visual C++ Redistributable（x64）后重跑 exe |

## 文件清单

- `setup-windows-env.ps1` + `setup-env.bat` — 编译环境一键安装（先跑这个）
- `build-player-windows.ps1` — 打包脚本（全部逻辑在这里）
- `run-build.bat` — 一键入口（双击）
- `patches/` — 5 个补丁 + `mpv_widget.py`（覆盖用）+ `standalone_player_atv_windows.py`
- `register-atvplayer-scheme.template.reg` — 模板（仅供参考；打包脚本会按实际路径生成正式版）
