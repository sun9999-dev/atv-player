@echo off
REM Build env one-click install: right-click this file, Run as administrator.
REM Installs Git + uv + Python 3.12 (uv-managed) + VC++ Redist.
REM Does NOT touch system Python 3.15.
REM After install, close all PowerShell windows and reopen,
REM or just double-click run-build.bat.
REM This file must stay pure ASCII: cmd.exe reads .bat as GBK, UTF-8
REM Chinese comments become garbage and break commands.
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup-windows-env.ps1"
echo.
echo ===== Env setup script exited with code %ERRORLEVEL% =====
pause
