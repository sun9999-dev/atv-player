@echo off
REM Standalone Player (Windows) one-click build. Double-click this file.
REM Requires: git, uv in PATH (run setup-env.bat first if missing).
REM Output: %USERPROFILE%\Desktop\player-win\Player\Player.exe + zip + register .reg
REM NOTE: git reset --hard v0.105.0 will discard uncommitted changes in
REM %USERPROFILE%\src\atv-player. Back up important changes first.
REM This file must stay pure ASCII: cmd.exe reads .bat as GBK, UTF-8
REM Chinese comments become garbage and break commands.
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build-player-windows.ps1" -PatchesDir "%~dp0patches" -SrcDir "%USERPROFILE%\src\atv-player" -OutDir "%USERPROFILE%\Desktop\player-win"
echo.
echo ===== Build script exited with code %ERRORLEVEL% =====
pause
