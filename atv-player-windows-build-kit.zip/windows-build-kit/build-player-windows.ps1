﻿# 播放器 Windows 版（独立播放器，PyInstaller 打包）
# 用法（在 Windows PowerShell 里，x64）：
#   .\build-player-windows.ps1 [-Version 0.105.0] [-SrcDir "$HOME\src\atv-player"] `
#       [-PatchesDir "$HOME\atv-player-patches"] [-OutDir "$HOME\Desktop\player-win"]
#
# 要求：git、uv 已在 PATH；PatchesDir 里有 v2 补丁集 + Windows 版独立播放器脚本。
# 产物：<OutDir>\播放器\播放器.exe（onedir，libmpv-2.dll 在同目录）+
#       <OutDir>\播放器-0.105.0-windows-x64.zip + register-atvplayer-scheme.reg（按实际路径生成）。
#
# 补丁顺序（和 Mac 完整版完全一致，不要换顺序，换了会丢功能）：
#   1. git reset --hard v$Version（pristine）
#   2. git apply v8（bluray_iso + m3u8_ad_filter + player_window + mpv_widget）
#   3. git apply 字幕关闭 + 右键菜单（player_window）
#   4. 用交付的 mpv_widget.py 覆盖源码（渲染 API 版；会丢掉 v8 的 mpv_widget 部分，
#      这是故意的——v8 的 mpv_widget 去重逻辑在渲染版里由 label helper 实现）
#   5. git apply on-render-v2（给渲染版 mpv_widget 补 ISO 语言；只对渲染版生效，
#      不要在第 2 步之后、覆盖之前打，否则和 v8 的 mpv_widget 部分重复冲突）
# Windows 上渲染 API 代码是 darwin 分支才走的死代码（wid 嵌入 + vo=gpu），
# 但保持和 Mac 同一份源码树，不做 Windows 特判，免得两边行为分叉。
#
# 注意：本脚本不用官方 build.py（build.py 打的是全量 atv-player app），
# 独立播放器和 Mac 完整版一样，直接用 PyInstaller 打 standalone 脚本。
[CmdletBinding()]
param(
    [string]$Version = "0.105.0",
    [string]$SrcDir = "$HOME\src\atv-player",
    [string]$PatchesDir = "$HOME\atv-player-patches",
    [string]$OutDir = "$HOME\Desktop\player-win",
    [switch]$Console  # 调试用：带控制台窗口（默认 --windowed，无控制台，报错看不到）
)

$ErrorActionPreference = "Stop"

# 官方 workflow 同款 libmpv DLL（power721 v0.97.0 发布件，SHA256 由官方 workflow 校验）。
$MPV_DLL_URL = "https://github.com/power721/atv-player/releases/download/v0.97.0/libmpv-2.dll"
$MPV_DLL_SHA256 = "5825ffd2bef6fd6a4b78016d5890c6c9dedb16a31828a1c749be89eacf9e20ae"

function Assert-File($Path, $What) {
    if (-not (Test-Path $Path)) { throw "缺少 $What：$Path" }
}

Write-Host "== 0. 工具检查 =="
foreach ($cmd in @("git", "uv")) {
    if (-not (Get-Command $cmd -ErrorAction SilentlyContinue)) { throw "缺少 $cmd，请先跑 setup-env.bat 装编译环境" }
}

Write-Host "== 0b. Python 3.12（官方 CI 同款；强制锁定，不用系统 Python 3.15）=="
# 系统 Python 哪怕是 3.15 也不要用：PySide6 / PyInstaller 对 3.15 未验证。
# uv python install 只把 3.12 放到 uv 自己的目录，和系统 Python 共存。
uv python install 3.12
$env:UV_PYTHON = "3.12"
Write-Host "构建用 Python：$(uv run --no-project --python 3.12 python --version)"
Assert-File (Join-Path $PatchesDir "standalone_player_atv_windows.py") "Windows 版独立播放器脚本"
Assert-File (Join-Path $PatchesDir "mpv_widget.py") "渲染版 mpv_widget.py（覆盖用）"
foreach ($p in @("atv-iso-track-all-v8.patch", "atv-subtitle-off-fix.patch",
                 "atv-context-menu-click-fix.patch", "atv-iso-on-render-fix-v2.patch")) {
    Assert-File (Join-Path $PatchesDir $p) "补丁 $p"
}

Write-Host "== 1. libmpv-2.dll（下载 + SHA256 校验，和官方 workflow 同款）=="
$Work = Join-Path $env:TEMP "player-win-build"
New-Item -ItemType Directory -Force -Path $Work | Out-Null
$DllPath = Join-Path $Work "libmpv-2.dll"
if (-not (Test-Path $DllPath)) {
    Invoke-WebRequest -Uri $MPV_DLL_URL -OutFile $DllPath
}
$actualHash = (Get-FileHash $DllPath -Algorithm SHA256).Hash.ToLower()
if ($actualHash -ne $MPV_DLL_SHA256) {
    throw "libmpv-2.dll SHA256 不匹配：期望 $MPV_DLL_SHA256，实际 $actualHash（删除 $DllPath 后重跑）"
}
Write-Host "libmpv-2.dll OK：$DllPath ($([Math]::Round((Get-Item $DllPath).Length / 1MB, 2)) MB)"

Write-Host "== 2. 源码 reset 到 v$Version（pristine，丢弃未提交改动）=="
if (-not (Test-Path (Join-Path $SrcDir ".git"))) {
    git clone https://github.com/power721/atv-player.git $SrcDir
}
Push-Location $SrcDir
try {
    git fetch --tags origin
    git reset --hard "v$Version"

    Write-Host "== 3. 打补丁（顺序固定，见文件头注释）=="
    git apply (Join-Path $PatchesDir "atv-iso-track-all-v8.patch")
    git apply (Join-Path $PatchesDir "atv-subtitle-off-fix.patch")
    git apply (Join-Path $PatchesDir "atv-context-menu-click-fix.patch")
    Copy-Item (Join-Path $PatchesDir "mpv_widget.py") "src\atv_player\player\mpv_widget.py" -Force
    git apply (Join-Path $PatchesDir "atv-iso-on-render-fix-v2.patch")

    Write-Host "== 3b. 校验补丁生效 =="
    $mpvWidget = Get-Content "src\atv_player\player\mpv_widget.py" -Raw
    if ($mpvWidget -notmatch "set_iso_track_languages") { throw "mpv_widget.py 缺 ISO 语言修复（on-render-v2 没打上）" }
    $playerWindow = Get-Content "src\atv_player\ui\player_window.py" -Raw
    if ($playerWindow -notmatch "track_id") { throw "player_window.py 缺偏好 id 修复（v8 没打上）" }
    Write-Host "补丁校验通过"

    Write-Host "== 4. 同步依赖 =="
    uv sync --frozen --group dev --group build

    Write-Host "== 5. PyInstaller 打包独立播放器 =="
    $PlayerMain = Join-Path $Work "player_main.py"
    Copy-Item (Join-Path $PatchesDir "standalone_player_atv_windows.py") $PlayerMain -Force
    $AppName = "播放器"
    $DistPath = Join-Path $Work "dist"
    $BuildPath = Join-Path $Work "build"
    $SpecPath = $Work
    $windowedArgs = @()
    if (-not $Console) { $windowedArgs += "--windowed" }
    # Windows 上 --add-binary 用 "源;目标目录"（分号，不是冒号）；DLL 放 exe 同目录。
    Push-Location $SrcDir
    try {
        uv run --with pyinstaller pyinstaller --noconfirm --clean @windowedArgs `
            --name $AppName `
            --paths "$SrcDir\src" `
            --distpath $DistPath --workpath $BuildPath --specpath $SpecPath `
            --copy-metadata atv-player `
            --hidden-import PySide6.QtOpenGL --hidden-import PySide6.QtOpenGLWidgets `
            --hidden-import PySide6.QtGui --hidden-import PySide6.QtWidgets `
            --hidden-import PySide6.QtCore --hidden-import PySide6.QtNetwork `
            --hidden-import PySide6.QtMultimedia `
            --add-binary "$DllPath;." `
            --collect-all atv_player `
            --exclude-module PySide6.QtWebEngineWidgets --exclude-module PySide6.QtWebEngineCore `
            --exclude-module PySide6.Qt3DCore --exclude-module PySide6.Qt3DRender `
            --exclude-module PySide6.Qt3DExtras --exclude-module PySide6.QtCharts `
            --exclude-module PySide6.QtDataVisualization --exclude-module PySide6.QtPdf `
            --exclude-module PySide6.QtPdfWidgets --exclude-module PySide6.QtRemoteObjects `
            --exclude-module PySide6.QtScxml --exclude-module PySide6.QtStateMachine `
            --exclude-module PySide6.QtTextToSpeech --exclude-module PySide6.QtLocation `
            --exclude-module PySide6.QtPositioning --exclude-module PySide6.QtSensors `
            --exclude-module PySide6.QtSerialPort --exclude-module PySide6.QtSerialBus `
            --exclude-module PySide6.QtBluetooth --exclude-module PySide6.QtNfc `
            --exclude-module PySide6.QtSql --exclude-module PySide6.QtXml `
            --exclude-module PySide6.QtTest --exclude-module PySide6.QtDesigner `
            --exclude-module PySide6.QtHelp --exclude-module PySide6.QtUiTools `
            $PlayerMain
    } finally { Pop-Location }

    $ExePath = Join-Path $DistPath "$AppName\$AppName.exe"
    Assert-File $ExePath "打包产物"
    # PyInstaller 6 onedir 默认把依赖（含 --add-binary）放进 _internal\ 子目录，
    # exe 在根目录、DLL 在 _internal\ 里；exe 目录和 _internal\ 有一个算通过，
    # 不要重复拷一份（114MB，拷了也没用，loader 两个位置都会找）。
    $BundledDll = Join-Path $DistPath "$AppName\libmpv-2.dll"
    $InternalDll = Join-Path $DistPath "$AppName\_internal\libmpv-2.dll"
    if (Test-Path $BundledDll) {
        Write-Host "包内 libmpv-2.dll：$BundledDll（exe 同目录）"
    } elseif (Test-Path $InternalDll) {
        Write-Host "包内 libmpv-2.dll：$InternalDll（PyInstaller 6 _internal\ 布局，正常）"
    } else {
        throw "包内找不到 libmpv-2.dll（exe 目录和 _internal\ 里都没有）"
    }
    Write-Host "打包完成：$ExePath"
} finally { Pop-Location }

Write-Host "== 6. 输出 + 生成 atvplayer:// 注册表文件（按实际 exe 路径）=="
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
$DestDir = Join-Path $OutDir $AppName
if (Test-Path $DestDir) { Remove-Item $DestDir -Recurse -Force }
Copy-Item (Join-Path $DistPath $AppName) $DestDir -Recurse
$FinalExe = Join-Path $DestDir "$AppName.exe"
# .reg：路径里的反斜杠要双写；协议调起时把整个 URL 当 %1 传给 exe。
$RegExe = $FinalExe -replace "\\", "\\"
$RegContent = @"
Windows Registry Editor Version 5.00

; atvplayer:// 协议（alist 外部播放器调起用）。双击导入即可；换了安装路径后重新跑打包脚本会重生成。
; 导入后浏览器/其它应用点 atvplayer://play?url=<链接> 会调起本 exe，链接作为 argv[1] 由 open_paths 解包。
[HKEY_CURRENT_USER\Software\Classes\atvplayer]
@="URL:atvplayer Protocol"
"URL Protocol"=""
[HKEY_CURRENT_USER\Software\Classes\atvplayer\DefaultIcon]
@="$RegExe,0"
[HKEY_CURRENT_USER\Software\Classes\atvplayer\shell]
[HKEY_CURRENT_USER\Software\Classes\atvplayer\shell\open]
[HKEY_CURRENT_USER\Software\Classes\atvplayer\shell\open\command]
@="\"$RegExe\" \"%1\""
"@
$RegPath = Join-Path $OutDir "register-atvplayer-scheme.reg"
Set-Content -Path $RegPath -Value $RegContent -Encoding Unicode
Write-Host "注册表文件：$RegPath（双击导入；只写 HKCU，不动系统）"

Write-Host "== 7. 打 zip =="
$ZipPath = Join-Path $OutDir "播放器-$Version-windows-x64.zip"
if (Test-Path $ZipPath) { Remove-Item $ZipPath -Force }
Compress-Archive -Path $DestDir -DestinationPath $ZipPath
Write-Host "完成：$ZipPath"
Write-Host "下一步：在 Windows 上双击 $FinalExe，先播一个本地 mkv，再播一个签名 ISO 链接；"
Write-Host "若首次启动闪退/无窗口，用 -Console 重打一遍看控制台报错（--windowed 会吞掉报错）。"
Write-Host "注意：未签名 exe 首次运行 Windows SmartScreen 会拦截，点“更多信息 -> 仍要运行”。"
