﻿# atv-player 独立播放器 — Windows 11 编译环境一键安装
# 用法：右键 setup-env.bat → 以管理员身份运行（winget 装 Git / VC++ 运行库可能要提权）。
# 装完后关掉所有 PowerShell 窗口再重开，或直接双击 run-build.bat。
#
# 会装什么（都不动系统 Python 3.15）：
#   1. Git（winget，补丁要用 git apply）
#   2. uv（官方安装器，装到 $HOME\.local\bin）
#   3. Python 3.12（uv python install，只放 uv 自己的目录，供项目用；官方 CI 也是 3.12）
#   4. Microsoft Visual C++ Redistributable x64（打包出的 exe 运行时要它；Win11 多数机器已有，装不上也不致命）
#
# 为什么不用系统 Python 3.15：官方 CI 用 3.12；PySide6 / PyInstaller 对 3.15 的支持未验证，
# 拿 3.15 打包大概率在 uv sync 或 PyInstaller 阶段就失败。构建时强制 UV_PYTHON=3.12。
[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"

function Add-ToPath($Dir) {
    if ($Dir -and (Test-Path $Dir) -and ($env:PATH -notlike "*$Dir*")) {
        $env:PATH = "$Dir;$env:PATH"
    }
}

Write-Host "== 0. 检查 winget（Win11 自带；没有则去 Microsoft Store 装 App Installer）=="
if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
    throw "找不到 winget：请先去 Microsoft Store 安装 App Installer，再重跑本脚本。"
}

Write-Host "== 1. Git =="
if (Get-Command git -ErrorAction SilentlyContinue) {
    Write-Host "Git 已有：$(git --version)"
} else {
    winget install --id Git.Git -e --accept-source-agreements --accept-package-agreements
    Add-ToPath "C:\Program Files\Git\cmd"
    Add-ToPath "C:\Program Files\Git\bin"
    Write-Host "Git 已安装：$(git --version)"
}

Write-Host "== 2. uv =="
if (Get-Command uv -ErrorAction SilentlyContinue) {
    Write-Host "uv 已有：$(uv --version)"
} else {
    powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
    Add-ToPath "$HOME\.local\bin"
    Add-ToPath "$HOME\.cargo\bin"
    if (-not (Get-Command uv -ErrorAction SilentlyContinue)) {
        throw "uv 安装后仍找不到：请关掉所有终端重开，再跑 uv --version 检查 PATH。"
    }
    Write-Host "uv 已安装：$(uv --version)"
}

Write-Host "== 3. Python 3.12（uv 管理，和系统 3.15 共存，互不干扰）=="
uv python install 3.12
Write-Host "uv 可用的 Python："
uv python list | Select-String "3.12"

Write-Host "== 4. Visual C++ Redistributable x64（exe 运行时依赖）=="
try {
    winget install --id Microsoft.VCRedist.2015+.x64 -e --accept-source-agreements --accept-package-agreements
    Write-Host "VC++ 运行库已安装/已是最新。"
} catch {
    Write-Host "警告：VC++ 运行库安装失败（$_），多数 Win11 机器已有，可先继续；若 exe 报缺 VCRUNTIME140.dll 再手动装。"
}

Write-Host ""
Write-Host "== 验证（全部通过才算环境就绪）=="
Write-Host "git: $(git --version)"
Write-Host "uv: $(uv --version)"
Write-Host "uv python 3.12: $(uv run --no-project --python 3.12 python --version 2>&1)"
Write-Host "系统 python（保持 3.15 不动，构建不会用它）: $(python --version 2>&1)"
Write-Host ""
Write-Host "环境就绪。关掉所有 PowerShell 窗口再重开，或直接双击 run-build.bat 开始打包。"
