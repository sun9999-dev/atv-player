package com.xiaohei.atvplayer.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

/**
 * 启动器：URL 输入 / 粘贴播放 / 文件选择（SAF）/ 最近记录。
 * 对应 desktop 的 Launcher（standalone_player_atv_windows.py:592）。
 *
 * TV：键鼠操作（点击输入框打字、点按钮），不做 DPAD/遥控器导航。
 * Pad：触摸。同一套布局。
 */
/** kit 版本：每次发版改这里，起始页和日志都用它，杜绝“装的到底是哪版”的歧义 */
const val KIT_VERSION = "v52"

class MainActivity : AppCompatActivity() {

    private lateinit var urlInput: EditText
    private lateinit var recentList: LinearLayout
    private val recent = ArrayList<String>()

    // 电视上没有 DocumentsUI，OpenDocument 会 ActivityNotFoundException；改 GetContent
    //（ES 等接 GET_CONTENT 的应用能响应）。GetContent 不给持久授权，不能调
    // takePersistableUriPermission（会抛 SecurityException），靠 playInput 里
    // FLAG_GRANT_READ_URI_PERMISSION 马上播；但最近记录里的这类 URI 跨重启会失效。
    private val pickFile = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri ?: return@registerForActivityResult
        playInput(uri.toString(), uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 开始界面也遵从设置里的初始方向
        requestedOrientation = if (Prefs.orientation(this) == "portrait")
            android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        else
            android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE

        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(24), dp(24), dp(24))
        }

        root.addView(TextView(this).apply {
            text = "播放器"
            textSize = 26f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, dp(10))
        })

        root.addView(TextView(this).apply {
            text = "native $KIT_VERSION"
            textSize = 12f
            setPadding(0, 0, 0, dp(10))
        })

        urlInput = EditText(this).apply {
            hint = "粘贴链接（支持 atvplayer://）"
            textSize = 17f
            gravity = android.view.Gravity.TOP
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            isVerticalScrollBarEnabled = true
            movementMethod = android.text.method.ScrollingMovementMethod.getInstance()
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(android.graphics.Color.WHITE)
                setStroke(dp(1), android.graphics.Color.parseColor("#BDBDBD"))
                cornerRadius = dp(8).toFloat()
            }
        }
        root.addView(urlInput, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(120)))

        // 三个按钮一行等宽；行距加在整行上（逐个加 topMargin 会错位）
        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        fun rowBtn(label: String, last: Boolean, onClick: () -> Unit) = Button(this).apply {
            text = label
            textSize = 17f
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f
            ).apply { if (!last) marginEnd = dp(10) }
        }
        btnRow.addView(rowBtn("播放链接", false) {
            playInput(urlInput.text.toString().trim())
        })
        btnRow.addView(rowBtn("打开本地文件", false) {
            // GetContent 只接受单个 MIME；video/* 会漏掉 .iso（MIME 不固定），故用 */*，播放时再校验
            pickFile.launch("*/*")
        })
        btnRow.addView(rowBtn("设置", true) {
            startActivity(android.content.Intent(this, SettingsActivity::class.java))
        })
        root.addView(btnRow, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(12) })

        root.addView(TextView(this).apply {
            text = "最近"
            textSize = 20f
            setPadding(0, dp(14), 0, dp(4))
        })
        recentList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val recentScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = true
            addView(recentList)
        }
        root.addView(recentScroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        refreshRecent()
    }

    private fun playInput(input: String, uri: Uri? = null) {
        if (input.isEmpty()) {
            Toast.makeText(this, "先输入链接或选文件", Toast.LENGTH_SHORT).show()
            return
        }
        remember(input)
        val intent = Intent(this, PlayerActivity::class.java).apply {
            action = Intent.ACTION_VIEW
            putExtra(PlayerActivity.EXTRA_INPUT, input)
            uri?.let {
                setData(it)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
        startActivity(intent)
    }

    private fun remember(input: String) {
        recent.remove(input)
        recent.add(0, input)
        while (recent.size > 20) recent.removeAt(recent.size - 1)
        getPreferences(MODE_PRIVATE).edit()
            .putStringSet("recent", recent.toSet()).apply()
        refreshRecent()
    }

    private fun refreshRecent() {
        if (!::recentList.isInitialized) return
        recentList.removeAllViews()
        val saved = getPreferences(MODE_PRIVATE).getStringSet("recent", emptySet()) ?: emptySet()
        recent.clear()
        recent.addAll(saved)
        for (item in recent) {
            recentList.addView(Button(this).apply {
                text = item.take(80)
                textSize = 16f
                setOnClickListener { playInput(item) }
            })
        }
    }
}
