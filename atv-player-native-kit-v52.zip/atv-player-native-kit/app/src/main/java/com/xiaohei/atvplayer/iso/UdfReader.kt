package com.xiaohei.atvplayer.iso

import android.os.ParcelFileDescriptor
import android.system.Os
import android.system.OsConstants
import com.xiaohei.atvplayer.net.LocalFileGet
import com.xiaohei.atvplayer.net.SignedUrl
import java.io.Closeable
import java.io.File

/**
 * UDF（ECMA-167）读取器 —— 替代 Python 的 pycdlib。
 *
 * 对应 bluray_iso.py 的远程 UDF 路径：
 *   _open_pycdlib_iso -> _build_remote_udf_iso -> _RemoteUdfIso
 *   _find_remote_udf_entry / _iter_udf_dir_entries / _read_remote_udf_file_range
 *   _build_cached_iso_stream_source / _stat_remote_udf_streams
 *
 * Blu-ray ISO 都是 UDF 2.5/2.6、逻辑块 2048、无 ISO9660 PVD（走 Python 的
 * "MISSING_PVD" fallback 分支）。本实现只走 UDF 分支，不解析 ISO9660。
 *
 * **偏移全部对照 pycdlib 源码校准**（pycdlib.udf 的 FMT 串）：
 * - FSD（tag 256）：root_dir_icb（long_ad 16）@ 400
 *   FMT `<16s12sHHLLLL64s128s64s32s32s32s16s32s16s16s32s`
 * - LVD（tag 6）：logical_block_size @ 212，map_table_length @ 264，
 *   num_partition_maps @ 268，分区表 @ 440（长 map_table_length）
 *   FMT `<16sL64s128sL32s16sLL32s128s8s72s`
 * - PD（tag 5）：part_num @ 22，part_start_location @ 188
 *   FMT `<16sLHH32s128sLLL32s128s156s`
 * - File Entry（tag 261）：information_length @ 56，
 *   len_extended_attrs @ 168，len_alloc_descs @ 172，
 *   分配描述符 @ 176+lenEA；icbtag.flags @ 34，AD 类型 = flags & 7
 *   （0=short_ad 8字节，1=long_ad 16字节，2=extended_ad 不支持，3=embedded 内嵌数据）
 *   FMT `<16s20sLLLHBBLQQ12s12s12sL16s32sQLL`
 * - FID（tag 257）：file_characteristics @ 18（bit1=目录，bit3=parent），
 *   len_fi @ 19，icb（long_ad）@ 20，len_impl_use @ 36，
 *   名字 @ 38+len_impl_use（首字节 compression id：0x08=latin-1，0x10=utf-16_be；
 *   len_fi 含这 1 字节）；总长 4 字节对齐
 *   FMT `<16sHBB16sH`
 * - long_ad `<LLH6s`：extent_length@0，lb@4，part@8；short_ad `<LL`：len@0，pos@4
 * - extent_length 高 2 位是分配类型 flag，取 `& 0x3FFFFFFF`
 *
 * 块读取抽象：本地文件（RandomAccessFile）/ 远程（SignedUrl Range）。
 * 对应 Python 的 RemoteRangeReader（bluray_iso.py:819）。
 */
interface BlockReader {
    val logicalBlockSize: Int   // 2048
    fun totalSize(): Long       // 整个 ISO 字节数（远程：首次 Range 读 Content-Range 取）
    fun readBlock(physicalBlock: Long, blockCount: Int = 1): ByteArray
    fun readBytes(absoluteStart: Long, length: Int): ByteArray
}

class FileBlockReader(private val path: String) : BlockReader {
    override val logicalBlockSize = 2048
    private val len = File(path).length()
    override fun totalSize(): Long = len
    override fun readBlock(physicalBlock: Long, blockCount: Int): ByteArray =
        readBytes(physicalBlock * logicalBlockSize, blockCount * logicalBlockSize)

    override fun readBytes(absoluteStart: Long, length: Int): ByteArray {
        val resp = LocalFileGet.get(path, mapOf("Range" to "bytes=$absoluteStart-${absoluteStart + length - 1}"))
        if (resp.status != 206) throw IllegalStateException("本地 Range 读失败：${resp.status}")
        return resp.body
    }
}

/**
 * content:// 的 fd 直读（SAF）：全程不落盘——旧实现先把整个文件拷进
 * cacheDir(NAND) 再读，大 ISO 既慢又写闪存。fd 由调用方持有，close 释放。
 */
class FdBlockReader(private val pfd: ParcelFileDescriptor) : BlockReader, Closeable {
    override val logicalBlockSize = 2048
    private val fd = pfd.fileDescriptor
    private var cachedSize: Long? = null

    @Synchronized
    override fun totalSize(): Long {
        cachedSize?.let { return it }
        val sz = Os.lseek(fd, 0, OsConstants.SEEK_END)
        cachedSize = sz
        return sz
    }

    override fun readBlock(physicalBlock: Long, blockCount: Int): ByteArray =
        readBytes(physicalBlock * logicalBlockSize, blockCount * logicalBlockSize)

    @Synchronized
    override fun readBytes(absoluteStart: Long, length: Int): ByteArray {
        // Os.read 走共享文件偏移，必须串行 lseek+read
        val out = ByteArray(length)
        Os.lseek(fd, absoluteStart, OsConstants.SEEK_SET)
        var off = 0
        while (off < length) {
            val n = Os.read(fd, out, off, length - off)
            if (n <= 0) break
            off += n
        }
        return if (off == length) out else out.copyOf(off)
    }

    override fun close() {
        try { pfd.close() } catch (_: Exception) { }
    }
}

class HttpRangeBlockReader(
    private val url: String,
    private val headers: Map<String, String>,
) : BlockReader {
    override val logicalBlockSize = 2048
    private var cachedTotal: Long? = null

    override fun totalSize(): Long {
        cachedTotal?.let { return it }
        // bytes=0-0 探测：SignedUrl 会扩到 1MB 并回 206 + Content-Range ".../total"
        // v51 取数日志：totalSize 在 fetchWindow 打“range fetch”行之前调，
        // 它挂起会导致 fetchWindow 一行日志都没有，必须单独打开始/结束。
        // v52: probe 也走重试（滴流被 callTimeout 打断后换新链再探）。
        return retryFetch("totalSize probe") {
            val t0 = System.currentTimeMillis()
            IsoLog.i("totalSize probe start: ${url.take(120)}")
            try {
                val resp = SignedUrl.get(url, headers + mapOf("Range" to "bytes=0-0"))
                if (resp.status != 206) throw IllegalStateException("远程 ISO 不支持 Range（status=${resp.status}）")
                val cr = resp.headers.entries.firstOrNull {
                    it.key.equals("Content-Range", ignoreCase = true)
                }?.value ?: throw IllegalStateException("远程 ISO 未返回 Content-Range")
                val total = cr.substringAfterLast("/").toLong()
                cachedTotal = total
                IsoLog.i("totalSize probe ok: total=$total ${System.currentTimeMillis() - t0}ms")
                total
            } catch (e: Throwable) {
                IsoLog.e("totalSize probe fail: ${e.javaClass.simpleName} ${e.message} ${System.currentTimeMillis() - t0}ms")
                throw e
            }
        }
    }

    override fun readBlock(physicalBlock: Long, blockCount: Int): ByteArray =
        readBytes(physicalBlock * logicalBlockSize, blockCount * logicalBlockSize)

    // ---- 窗口缓存（对应桌面 _RemoteRangeWindowCache）----
    // 元数据（VDS/FSD/目录/mpls/clpi）在盘上高度聚集，无缓存时每个 2048 块
    // 都是一次 HTTP 往返（实测每跳 0.4~2.4s，扫 playlist 要几分钟）。
    // 4MB 对齐窗口 + LRU(24 窗口=96MB)：mpv 的头部读/尾部探测/多连接并存时
    // 不再互相挤掉（6 窗口时同一窗口被重复拉 3-4 次，实测）。
    // 每次按需拉取后后台预取后续 2 个窗口：单窗拉取走签名重定向链约 1s，
    // UHD 码率下无预取必然播 1-2s 卡 4s（实测）。
    // 窗口 8MB / 缓存窗口数按内存分档（见 CacheTuning）：每窗都要过一次 AList 重定向（服务端
    // 现算下载链），窗口越大、并行预取越深，单位 MB 的往返成本越低。
    // 实测 4MB+单线程预取时聚合吞吐 ~4MB/s，跟不上 UHD 码率（播3s卡3s）。
    private val windowSize = 8 * 1024 * 1024
    private val cacheLock = Any()
    private val windowCache = object : LinkedHashMap<Long, ByteArray>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Long, ByteArray>?): Boolean =
            size > CacheTuning.maxWindows
    }
    private val inFlight = HashSet<Long>()
    private val prefetchPool = java.util.concurrent.Executors.newFixedThreadPool(4) { r ->
        Thread(r, "iso-prefetch").apply { isDaemon = true }
    }

    @Volatile private var lastDemandIdx = -1L   // 上次“按需”拉取的窗口（播放前锋）

    // v52: 取数失败换新连接重试。callTimeout 把滴流打断成可见异常后，
    // 这里重走签名链（拿新直链）再拉，而不是静默挂起。最多 3 次
    // （首拉 + 2 次重试），每次间隔 1s；3 次都失败则把最后一次异常抛
    // 给调用方（按需读会报给 mpv，预取失败仍静默吞掉等按需再拉）。
    private fun <T> retryFetch(tag: String, block: () -> T): T {
        var lastErr: Throwable? = null
        repeat(3) { attempt ->
            if (attempt > 0) {
                try {
                    Thread.sleep(1000)
                } catch (ie: InterruptedException) {
                    Thread.currentThread().interrupt()
                    throw ie
                }
                IsoLog.i("$tag retry: attempt=${attempt + 1}/3 after ${lastErr?.javaClass?.simpleName} ${lastErr?.message}")
            }
            try {
                return block()
            } catch (e: Throwable) {
                lastErr = e
            }
        }
        throw lastErr!!
    }

    private fun fetchWindow(winIdx: Long, demand: Boolean): ByteArray? {
        val ws = winIdx * windowSize
        val total = totalSize()
        if (ws >= total) return null
        val wlen = minOf(windowSize.toLong(), total - ws).toInt()
        if (wlen <= 0) return null
        // totalSize 在外层（自带重试，之后走缓存）；这里只重试窗口取数，
        // 不与 totalSize 的重试嵌套（否则全挂时最多 9 次）。
        return retryFetch("range fetch window @$ws") {
            fetchWindowOnce(winIdx, ws, wlen, demand)
        }
    }

    private fun fetchWindowOnce(winIdx: Long, ws: Long, wlen: Int, demand: Boolean): ByteArray? {
        // v51 取数日志：开始/成功/失败成对打。开始有行、成功失败都没行
        // = 取数挂在 SignedUrl.get 里；开始都没行 = 卡在 totalSize（上
        // 面已单独打日志）或根本没进 fetchWindow。v52 在此之上加重试
        // （fetchWindow 包一层 retryFetch），每次尝试各打一套日志。
        val t0 = System.currentTimeMillis()
        IsoLog.i("range fetch start: window @$ws len=$wlen demand=$demand thread=${Thread.currentThread().name}")
        val resp = try {
            val r = SignedUrl.get(url, headers + mapOf("Range" to "bytes=$ws-${ws + wlen - 1}"))
            if (r.status != 206) throw IllegalStateException("远程 Range 读失败：${r.status}")
            synchronized(cacheLock) { windowCache[winIdx] = r.body }
            IsoLog.i("range fetch ok: window @$ws bytes=${r.body.size} ${System.currentTimeMillis() - t0}ms")
            r
        } catch (e: Throwable) {
            IsoLog.e("range fetch fail: window @$ws ${e.javaClass.simpleName} ${e.message} ${System.currentTimeMillis() - t0}ms")
            throw e
        }
        if (demand) {
            // 只跟播放前锋：与上次按需窗口顺序相邻（差 ≤2）→ 深预取 6 窗；
            // 随机跳（mpv 尾部探测/seek）→ 只浅探 2 窗，不追探测位置烧带宽。
            // 预取完成不再级联，前锋由 mpv 的连续读自然推进。
            val prev = lastDemandIdx
            lastDemandIdx = winIdx
            val depth = if (prev >= 0 && winIdx >= prev && winIdx - prev <= 2) 6 else 2
            for (k in 1..depth) schedulePrefetch(winIdx + k)
        }
        return resp.body
    }

    private fun schedulePrefetch(winIdx: Long) {
        synchronized(cacheLock) {
            if (windowCache.containsKey(winIdx) || !inFlight.add(winIdx)) return
        }
        prefetchPool.execute {
            try {
                fetchWindow(winIdx, demand = false)
            } catch (_: Exception) {
                // 预取失败无所谓，按需读时会再拉（并抛给调用方）
            } finally {
                synchronized(cacheLock) { inFlight.remove(winIdx) }
            }
        }
    }

    private fun window(winIdx: Long): ByteArray? {
        synchronized(cacheLock) { windowCache[winIdx]?.let { return it } }
        return fetchWindow(winIdx, demand = true)
    }

    override fun readBytes(absoluteStart: Long, length: Int): ByteArray {
        val out = ByteArray(length)
        var off = 0
        while (off < length) {
            val pos = absoluteStart + off
            val winIdx = pos / windowSize
            val win = window(winIdx) ?: break
            val within = (pos - winIdx * windowSize).toInt()
            val n = minOf(win.size - within, length - off)
            if (n <= 0) break
            win.copyInto(out, off, within, within + n)
            off += n
        }
        return out
    }
}

/** UDF 描述符 tag（ECMA-167 7.2），16 字节，小端 */
private data class DescTag(val id: Int, val location: Long)

/** 分区解析器：(partRefNum, 逻辑块) -> 物理块（对应 _UdfPartitionResolver） */
private sealed class PartitionResolver {
    abstract val partRefNum: Int

    /** 物理分区：物理块 = 分区起始 + 逻辑块 */
    data class Physical(
        override val partRefNum: Int,
        val physicalPartitionStart: Long,  // 物理块号
    ) : PartitionResolver()

    /**
     * metadata 分区（UDF 2.50）：虚拟分区，逻辑块落在 metadata 文件的数据区里，
     * 要经 metadata 文件条目的 AD 二次映射到物理分区。根目录 ICB 的分区引用
     * 就指向它（实测 root part_ref=1）。
     */
    data class Metadata(
        override val partRefNum: Int,
        val metaEntry: UdfFileEntry,
    ) : PartitionResolver()
}

/** 文件分配描述符 */
sealed class AllocDesc {
    abstract val extentLength: Long
    data class ShortAd(override val extentLength: Long, val logBlockNum: Long) : AllocDesc()
    data class LongAd(override val extentLength: Long, val logBlockNum: Long, val partRefNum: Int) : AllocDesc()
}

data class UdfFileEntry(
    val isDir: Boolean,
    val informationLength: Long,   // 文件字节数（_stream_size_from_record）
    val allocDescs: List<AllocDesc>,
    val partRefNum: Int,           // entry 所在的分区引用号
    /** AD 类型 3（embedded）：文件数据内嵌在这里 */
    val embeddedData: ByteArray? = null,
)

private data class FileIdent(
    val name: String,
    val isDir: Boolean,
    val isParent: Boolean,
    val icbLogBlock: Long,
    val icbPartRef: Int,
    val icbLen: Long,
)

/**
 * UDF 卷解析 + 文件走读。
 *
 * 流程（对应 Python）：
 * 1. 读 256 扇区 AnchorVDP -> 主卷描述符序列位置
 * 2. 扫 VDS：PD(tag 5, 分区号 -> 物理起始) / LVD(tag 6) / TD(tag 8 结束)
 *    FSD(tag 256) 不在 VDS 里——它在分区起始块（pycdlib 同款读法）
 * 3. 建 PartitionResolver（type-1 map；metadata type-2 罕见，见 PORTING.md）
 * 4. findEntry("/BDMV/STREAM/00001.M2TS")：从 root ICB 逐级读 File Entry，
 *    枚举 File Identifier Descriptor（名字大写比对，跳过 parent）
 * 5. readFileRange / buildStreamSource：allocDescs -> 物理块
 */
class UdfReader(private val reader: BlockReader) {

    private val lbSize = 2048
    private lateinit var resolvers: List<PartitionResolver>
    private lateinit var rootIcb: Triple<Long, Int, Long>  // (logBlock, partRef, len)

    // ---- 小端读数 ----
    private fun u16le(b: ByteArray, o: Int) = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)
    private fun u32le(b: ByteArray, o: Int) =
        (b[o].toLong() and 0xFF) or ((b[o + 1].toLong() and 0xFF) shl 8) or
            ((b[o + 2].toLong() and 0xFF) shl 16) or ((b[o + 3].toLong() and 0xFF) shl 24)
    private fun u64le(b: ByteArray, o: Int): Long {
        var v = 0L
        for (i in 0 until 8) v = v or ((b[o + i].toLong() and 0xFF) shl (8 * i))
        return v
    }

    private fun parseTag(sector: ByteArray): DescTag? {
        if (sector.size < 16) return null
        val id = u16le(sector, 0)
        if (id == 0) return null
        return DescTag(id, u32le(sector, 12))
    }

    /** 入口：解析卷并建分区映射。对应 _open_pycdlib_iso 的 UDF fallback 分支。 */
    fun open() {
        // 1. AnchorVDP 在 256 扇区（ECMA-167 2.2.3）；读不到试 N-2
        var anchor = reader.readBlock(256)
        var tag = parseTag(anchor)
        if (tag?.id != 2) {
            val lastSector = reader.totalSize() / lbSize - 1
            anchor = reader.readBlock(lastSector - 1)
            tag = parseTag(anchor)
            check(tag?.id == 2) { "UDF AnchorVDP 缺失" }
        }
        // AnchorVDP：tag(16) + main_vds_extent{len(4)@16, loc(4)@20} + reserve(8)
        val mainExtLen = u32le(anchor, 16)
        val mainExtLoc = u32le(anchor, 20)
        IsoLog.i("UDF anchor ok: mainVDS loc=$mainExtLoc len=$mainExtLen")

        // 2. 扫主 VDS
        var lvdData: ByteArray? = null
        val partitions = HashMap<Int, Long>()        // partNum -> 物理起始块
        var firstPartStart = -1L                     // VDS 里第一个 PD 的起始（FSD 在其首块）
        val vdsBlocks = (mainExtLen / lbSize).toInt().coerceAtLeast(1)
        for (i in 0 until vdsBlocks) {
            val sector = reader.readBlock(mainExtLoc + i)
            when (parseTag(sector)?.id) {
                5 -> { // Partition Descriptor（tag 5）：part_num @ 22，part_start @ 188
                    val partNum = u16le(sector, 22)
                    val partStart = u32le(sector, 188)
                    partitions[partNum] = partStart
                    if (firstPartStart < 0) firstPartStart = partStart
                }
                6 -> lvdData = sector               // Logical Volume Descriptor
                8 -> break                          // Terminating Descriptor
            }
        }
        checkNotNull(lvdData) { "UDF 逻辑卷信息缺失" }
        check(firstPartStart >= 0) { "UDF 分区描述符缺失" }

        // LVD：logical_block_size @ 212；分区表 @ 440，长 map_table_length（@264）
        val logicalBlockSize = u32le(lvdData, 212).toInt()
        check(logicalBlockSize == 2048) { "UDF 逻辑块大小不是 2048：$logicalBlockSize" }
        val mapTableLength = u32le(lvdData, 264).toInt()
        val mapCount = u32le(lvdData, 268).toInt()
        var mapOff = 440
        val resList = ArrayList<PartitionResolver>()
        val metaRefs = ArrayList<Int>()
        repeat(mapCount) { refNum ->
            if (mapOff + 2 > 440 + mapTableLength) return@repeat
            val mapType = lvdData[mapOff].toInt() and 0xFF
            val mapLen = lvdData[mapOff + 1].toInt() and 0xFF
            if (mapType == 1 && mapLen >= 6) {
                // Type1 map 布局 BBHH：@+2 是卷序列号（恒 1），分区号在 @+4
                // ——读 +2 会永远查“分区 1”（实测踩过）。
                val partNum = u16le(lvdData, mapOff + 4)
                val physStart = partitions[partNum]
                    ?: throw IllegalStateException("分区 $partNum 无描述符")
                resList.add(PartitionResolver.Physical(refNum, physStart))
            } else if (mapType == 2) {
                // metadata 分区映射：解析器需要 metadata 文件条目，
                // 等 loadFileSet 拿到后在下面补建（见 Metadata 分支）。
                metaRefs.add(refNum)
            }
            // type 0（虚拟分区）Blu-ray 不用，跳过
            mapOff += mapLen
        }
        // 无 partition map 时的 fallback（对应 Python 的 fallback 分支）
        if (resList.isEmpty()) {
            partitions.entries.forEachIndexed { index, e ->
                resList.add(PartitionResolver.Physical(index, e.value))
            }
        }
        check(resList.isNotEmpty()) { "UDF 分区解析失败" }
        resolvers = resList
        IsoLog.i("UDF VDS: PDs=$partitions firstPartStart=$firstPartStart " +
            "resolvers=${resList.map { it.partRefNum }} metaRefs=$metaRefs")

        // FSD 位置（root_directory_icb 是 16 字节 long_ad @ 400）：
        // - 无 metadata 分区的盘：FSD 就在分区起始块（pycdlib 同款）；
        // - UDF 2.50 metadata 盘：分区首块是 metadata 文件的 (E)FE（tag 261/266），
        //   FSD 在它 AD 指向的数据首块（实测此盘首块 tag=266）。
        val (fsdData, metaEntry) = loadFileSet(firstPartStart, resolvers)
        if (metaEntry != null) {
            // 给每个 type-2 映射补 Metadata 解析器（标准盘只有一个 metadata 分区）
            val grown = ArrayList(resolvers)
            for (ref in metaRefs) grown.add(PartitionResolver.Metadata(ref, metaEntry))
            resolvers = grown
        }
        val rootLen = u32le(fsdData, 400)
        val rootLb = u32le(fsdData, 404)
        val rootPart = u16le(fsdData, 408)
        rootIcb = Triple(rootLb, rootPart, rootLen)
        IsoLog.i("UDF rootIcb: lb=$rootLb part=$rootPart len=$rootLen")
    }

    /**
     * 从分区起始块找到 FSD：直接是 256，或经 metadata 文件 (E)FE 的首个 AD 跳一跳。
     * 返回 (FSD 数据, metadata 文件条目——直接命中 256 时为 null)。
     */
    private fun loadFileSet(partStart: Long, res: List<PartitionResolver>): Pair<ByteArray, UdfFileEntry?> {
        val first = reader.readBlock(partStart)
        val tagId = parseTag(first)?.id
        IsoLog.i("FSD check: partStart=$partStart firstTag=$tagId")
        if (tagId == 256) return first to null
        if (tagId == 261 || tagId == 266) {
            // 该分区在 resolver 里的引用号（短 AD 按条目所在分区解析）
            val refNum = (res.firstOrNull { it is PartitionResolver.Physical && it.physicalPartitionStart == partStart }
                ?.partRefNum) ?: 0
            val metaEntry = parseFileEntry(partStart, refNum)
            metaEntry.embeddedData?.let { emb ->
                if (emb.size >= 2048 && parseTag(emb.copyOfRange(0, 2048))?.id == 256) {
                    return emb.copyOfRange(0, 2048) to metaEntry
                }
            }
            val desc = metaEntry.allocDescs.firstOrNull()
                ?: throw IllegalStateException("UDF 文件集缺失（metadata 文件无 AD）")
            val phys = when (desc) {
                is AllocDesc.ShortAd -> mapBlock(metaEntry.partRefNum, desc.logBlockNum)
                is AllocDesc.LongAd -> mapBlock(desc.partRefNum, desc.logBlockNum)
            }
            val dataBlk = reader.readBlock(phys)
            IsoLog.i("FSD via metadata: phys=$phys tag=${parseTag(dataBlk)?.id}")
            check(parseTag(dataBlk)?.id == 256) {
                "UDF 文件集缺失（metadata 数据首块 tag=${parseTag(dataBlk)?.id}）"
            }
            return dataBlk to metaEntry
        }
        throw IllegalStateException("UDF 文件集缺失（分区首块 tag=$tagId）")
    }

    private fun mapBlock(partRefNum: Int, logicalBlockNum: Long): Long {
        val r = resolvers.firstOrNull { it.partRefNum == partRefNum }
            ?: throw IllegalStateException("分区引用 $partRefNum 无解析器")
        return when (r) {
            is PartitionResolver.Physical -> r.physicalPartitionStart + logicalBlockNum
            is PartitionResolver.Metadata -> {
                // 在 metadata 文件的 AD 链里定位逻辑块，再落到物理分区
                var acc = 0L
                var found = -1L
                for (d in r.metaEntry.allocDescs) {
                    val blocks = (d.extentLength + lbSize - 1) / lbSize
                    if (logicalBlockNum < acc + blocks) {
                        val base = when (d) {
                            is AllocDesc.ShortAd -> mapBlock(r.metaEntry.partRefNum, d.logBlockNum)
                            is AllocDesc.LongAd -> mapBlock(d.partRefNum, d.logBlockNum)
                        }
                        found = base + (logicalBlockNum - acc)
                        break
                    }
                    acc += blocks
                }
                check(found >= 0) { "metadata 分区逻辑块越界：$logicalBlockNum" }
                found
            }
        }
    }

    /**
     * 读 File Entry（tag 261）。对应 pycdlib 的 UDFFileEntry.parse。
     * AD 类型从 icbtag.flags（@34）的低 3 位取，不用启发式。
     */
    private fun parseFileEntry(physBlock: Long, partRefNum: Int): UdfFileEntry {
        val data = reader.readBlock(physBlock)
        val tag = parseTag(data) ?: throw IllegalStateException("UDF File Entry 缺失")
        // FE(261) 与 EFE(266)：infoLen@56 / icbtag.flags@34 两者相同；
        // EA/AD 长度字段位置不同（pycdlib FMT 核对）：
        //   261: lenEA@168 lenAD@172，AD 起始 176
        //   266: lenEA@208 lenAD@212，AD 起始 216（中间多了 objectSize 等字段）
        val infoLen = u64le(data, 56)
        val icbFlags = u16le(data, 34)
        val isDir = (icbFlags and 0x02) != 0
        val adType = icbFlags and 0x0007
        val lenEA: Int
        val lenAD: Int
        val adBase: Int
        when (tag.id) {
            261 -> { lenEA = u32le(data, 168).toInt(); lenAD = u32le(data, 172).toInt(); adBase = 176 }
            266 -> { lenEA = u32le(data, 208).toInt(); lenAD = u32le(data, 212).toInt(); adBase = 216 }
            else -> throw IllegalStateException("非 File Entry（tag=${tag.id}），暂不支持")
        }
        var adOff = adBase + lenEA
        val adEnd = adOff + lenAD
        val descs = ArrayList<AllocDesc>()
        var embedded: ByteArray? = null
        when (adType) {
            3 -> {
                // embedded：AD 区本身就是文件数据
                embedded = data.copyOfRange(adOff, minOf(adEnd, data.size))
            }
            0, 1 -> {
                while (adOff + 8 <= adEnd && adOff + 8 <= data.size) {
                    val extentLen = u32le(data, adOff) and 0x3FFFFFFF
                    if (extentLen == 0L) break
                    if (adType == 0) {
                        val pos = u32le(data, adOff + 4)
                        descs.add(AllocDesc.ShortAd(extentLen, pos))
                        adOff += 8
                    } else {
                        val lb = u32le(data, adOff + 4)
                        val pr = u16le(data, adOff + 8)
                        descs.add(AllocDesc.LongAd(extentLen, lb, pr))
                        adOff += 16
                    }
                }
            }
            else -> throw IllegalStateException("不支持的 UDF AD 类型：$adType")
        }
        return UdfFileEntry(isDir, infoLen, descs, partRefNum, embedded)
    }

    /**
     * 枚举目录的 File Identifier Descriptor。对应 _iter_udf_dir_entries。
     * FID：characteristics @ 18（bit1=目录，bit3=parent），len_fi @ 19，
     * icb @ 20（long_ad），len_impl_use @ 36，名字 @ 38+len_impl_use
     *（首字节 compression id：0x08=latin-1，0x10=utf-16_be；len_fi 含这 1 字节），
     * 总长 4 字节对齐。对应 pycdlib UDFFileIdentifierDescriptor.parse。
     */
    private fun iterDirIdents(entry: UdfFileEntry): List<FileIdent> {
        // embedded 目录：数据就在 entry 里（小目录可能内嵌）
        val embeddedDir = entry.embeddedData
        val out = ArrayList<FileIdent>()
        if (embeddedDir != null) {
            parseFidBuffer(embeddedDir, entry, out)
            return out
        }
        for (desc in entry.allocDescs) {
            val physBlock = when (desc) {
                is AllocDesc.ShortAd -> mapBlock(entry.partRefNum, desc.logBlockNum)
                is AllocDesc.LongAd -> mapBlock(desc.partRefNum, desc.logBlockNum)
            }
            val blockCount = ((desc.extentLength + lbSize - 1) / lbSize).toInt().coerceAtLeast(1)
            val data = reader.readBlock(physBlock, blockCount).copyOf(desc.extentLength.toInt())
            parseFidBuffer(data, entry, out)
        }
        return out
    }

    private fun parseFidBuffer(data: ByteArray, entry: UdfFileEntry, out: MutableList<FileIdent>) {
        var offset = 0
        while (offset + 38 <= data.size) {
            val tag = parseTag(data.copyOfRange(offset, minOf(offset + 16, data.size))) ?: break
            if (tag.id != 257) break
            val charFlags = data[offset + 18].toInt() and 0xFF
            val fiLen = data[offset + 19].toInt() and 0xFF
            val icbLen = u32le(data, offset + 20)
            val icbLb = u32le(data, offset + 24)
            val icbPart = u16le(data, offset + 28)
            val lenIu = u16le(data, offset + 36)
            val nameStart = offset + 38 + lenIu
            val nameEnd = minOf(nameStart + fiLen, data.size)
            val nameBytes = if (nameStart < nameEnd) data.copyOfRange(nameStart, nameEnd) else ByteArray(0)
            // 首字节 compression id；parent 条目（bit3）没有名字
            val isParent = (charFlags and 0x08) != 0
            val name = if (isParent || nameBytes.isEmpty()) {
                ""
            } else {
                when (nameBytes[0].toInt() and 0xFF) {
                    0x10 -> try {
                        nameBytes.copyOfRange(1, nameBytes.size).toString(Charsets.UTF_16BE)
                    } catch (_: Exception) { "" }
                    0x08 -> nameBytes.copyOfRange(1, nameBytes.size)
                        .toString(Charsets.ISO_8859_1)
                    else -> ""
                }
            }
            out.add(
                FileIdent(
                    name = name,
                    isDir = (charFlags and 0x02) != 0,
                    isParent = isParent,
                    icbLogBlock = icbLb,
                    icbPartRef = icbPart,
                    icbLen = icbLen,
                )
            )
            // 总长：38 + lenIu + lenFi，4 字节对齐（对应 pycdlib 的 pad）
            val total = 38 + lenIu + fiLen
            offset += ((total + 3) / 4) * 4
        }
    }

    private fun rootEntry(): UdfFileEntry {
        val (lb, part, _) = rootIcb
        return parseFileEntry(mapBlock(part, lb), part)
    }

    private fun entryFromIcb(ident: FileIdent): UdfFileEntry {
        return parseFileEntry(mapBlock(ident.icbPartRef, ident.icbLogBlock), ident.icbPartRef)
    }

    /** 路径查找。对应 _find_remote_udf_entry（名字大写比对，跳过 parent）。 */
    fun findEntry(normalizedPath: String): UdfFileEntry {
        val comps = normalizedPath.split("/").filter { it.isNotEmpty() }
        var current = rootEntry()
        if (comps.isEmpty()) return current
        for (comp in comps) {
            var matched: FileIdent? = null
            for (ident in iterDirIdents(current)) {
                if (ident.isParent) continue
                if (ident.name.uppercase() == comp.uppercase()) {
                    matched = ident
                    break
                }
            }
            checkNotNull(matched) { "UDF 路径不存在：$normalizedPath" }
            current = entryFromIcb(matched)
        }
        IsoLog.i("findEntry $normalizedPath -> infoLen=${current.informationLength} descs=${current.allocDescs.size} dir=${current.isDir}")
        return current
    }

    /** 列出 /BDMV/STREAM 下的 .M2TS。对应 _stat_remote_udf_streams。 */
    fun statStreams(): List<BluRayIsoStream> {
        val streamDir = findEntry("/BDMV/STREAM")
        val out = ArrayList<BluRayIsoStream>()
        val re = Regex("^/BDMV/STREAM/[^/]+\\.M2TS$", RegexOption.IGNORE_CASE)
        for (ident in iterDirIdents(streamDir)) {
            if (ident.isParent || ident.isDir) continue
            val p = "/BDMV/STREAM/${ident.name.uppercase()}"
            if (!re.matches(p)) continue
            val e = entryFromIcb(ident)
            out.add(BluRayIsoStream(p, e.informationLength))
        }
        IsoLog.i("statStreams: ${out.size} streams, top=${out.maxByOrNull { it.size }}")
        return out
    }

    /** 读整个小文件（如 .mpls/.clpi）。对应 _read_remote_udf_file。 */
    fun readWholeFile(normalizedPath: String): ByteArray {
        val entry = findEntry(normalizedPath)
        val total = entry.informationLength
        if (total <= 0) return ByteArray(0)
        return readFileRange(entry, 0, total - 1)
    }

    /** 读文件 [start, end] 闭区间。对应 _read_remote_udf_file_range。 */
    fun readFileRange(entry: UdfFileEntry, start: Long, inclusiveEnd: Long): ByteArray {
        // embedded：数据内嵌
        entry.embeddedData?.let { emb ->
            val s = start.coerceIn(0, emb.size.toLong()).toInt()
            val e = minOf(inclusiveEnd, emb.size - 1L).toInt()
            if (e < s) return ByteArray(0)
            return emb.copyOfRange(s, e + 1)
        }
        val chunks = ArrayList<ByteArray>()
        var offset = 0L
        for (desc in entry.allocDescs) {
            val extentLen = desc.extentLength
            if (extentLen <= 0) continue
            val extentEnd = offset + extentLen - 1
            if (start > extentEnd) { offset += extentLen; continue }
            if (inclusiveEnd < offset) break
            val localStart = maxOf(0L, start - offset)
            val localEnd = minOf(extentLen - 1, inclusiveEnd - offset)
            val physBlock = when (desc) {
                is AllocDesc.ShortAd -> mapBlock(entry.partRefNum, desc.logBlockNum)
                is AllocDesc.LongAd -> mapBlock(desc.partRefNum, desc.logBlockNum)
            }
            val absStart = physBlock * lbSize + localStart
            chunks.add(reader.readBytes(absStart, (localEnd - localStart + 1).toInt()))
            if (offset + localEnd >= inclusiveEnd) break
            offset += extentLen
        }
        var total = 0
        chunks.forEach { total += it.size }
        val out = ByteArray(total)
        var o = 0
        chunks.forEach { it.copyInto(out, o); o += it.size }
        return out
    }

    /**
     * 建逻辑流分段。对应 _build_cached_iso_stream_source：
     * 每个 alloc desc -> CachedIsoSegment(logicalOffset, length=extentLength,
     * physicalStart=物理块*2048)。
     */
    fun buildStreamSource(entry: UdfFileEntry): CachedIsoStreamSource {
        // embedded 小文件：整个文件就是一段（数据内嵌，不走物理块）
        entry.embeddedData?.let { emb ->
            return CachedIsoStreamSource(
                size = entry.informationLength,
                segments = emptyList(),
                embeddedData = emb.copyOf(entry.informationLength.toInt().coerceAtMost(emb.size)),
            )
        }
        val segments = ArrayList<CachedIsoSegment>()
        var logicalOffset = 0L
        for (desc in entry.allocDescs) {
            val extentLen = desc.extentLength
            if (extentLen <= 0) continue
            val physBlock = when (desc) {
                is AllocDesc.ShortAd -> mapBlock(entry.partRefNum, desc.logBlockNum)
                is AllocDesc.LongAd -> mapBlock(desc.partRefNum, desc.logBlockNum)
            }
            segments.add(
                CachedIsoSegment(
                    logicalOffset = logicalOffset,
                    length = extentLen,
                    physicalStart = physBlock * lbSize,
                )
            )
            logicalOffset += extentLen
        }
        check(segments.isNotEmpty()) { "Blu-ray ISO 中没有可播放的 m2ts 文件" }
        return CachedIsoStreamSource(size = entry.informationLength, segments = segments)
    }

    /** 读 .clpi。对应 _read_remote_udf_clipinfo。 */
    fun readClipInfo(clipId: String): ParsedClpi {
        val data = readWholeFile("/BDMV/CLIPINF/$clipId.CLPI")
        return ClpiParser.parseEntryPoints(clipId, data)
    }

    /** 枚举 playlist。对应 _iter_remote_udf_playlists（按路径排序）。 */
    fun iterPlaylists(): List<Pair<String, ByteArray>> {
        val playlistDir = findEntry("/BDMV/PLAYLIST")
        val out = ArrayList<Pair<String, ByteArray>>()
        val re = Regex("^/BDMV/PLAYLIST/[^/]+\\.MPLS$", RegexOption.IGNORE_CASE)
        for (ident in iterDirIdents(playlistDir)) {
            if (ident.isParent || ident.isDir) continue
            val p = "/BDMV/PLAYLIST/${ident.name.uppercase()}"
            if (!re.matches(p)) continue
            val e = entryFromIcb(ident)
            out.add(p to readFileRange(e, 0, e.informationLength - 1))
        }
        return out.sortedBy { it.first }
    }

    fun hasBluRayIndex(): Boolean = try {
        findEntry("/BDMV/INDEX.BDMV"); true
    } catch (_: Exception) { false }
}
