package com.xiaohei.atvplayer.proxy

import com.xiaohei.atvplayer.iso.IsoLog

import com.xiaohei.atvplayer.iso.BlurayIsoInspector
import com.xiaohei.atvplayer.iso.CachedIsoStreamSource
import com.xiaohei.atvplayer.iso.IsoPlaybackSegment
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.Executors
import kotlin.math.ceil

/**
 * 本地 ISO 代理 —— 移植 LocalHlsProxyServer（proxy/server.py）的 ISO 相关路径。
 *
 * - 绑 127.0.0.1:2323（被占则换空闲端口），对应 server.py:615 start()
 * - create_iso_media_url -> http://127.0.0.1:PORT/iso/{token}/BDMV/STREAM/xxx.M2TS
 *   （对应 server.py:678，token=uuid4 hex）
 * - create_iso_playlist_url -> m3u8（#EXT-X-VERSION:3, VOD, TARGETDURATION,
 *   段间 #EXT-X-DISCONTINUITY, #EXT-X-ENDLIST；对应 server.py:698）,
 *   返回 http://127.0.0.1:PORT/m3u/{token}
 * - 服务 Range：解析 Range 头 -> inspector.readRangeFromSource -> 206 +
 *   Content-Range / Content-Length；无 Range 回 200 全量（本地小文件场景）
 *   （对应 server.py:1355 _iso 段 + 1602/1679/1912 的服务分支）
 *
 * 注意：只实现 ISO 代理（/iso/、/m3u/）。Python 的通用媒体代理（/media/、
 * DASH/CENC 等）桌面独立播放器用不上，不移植。
 */
class IsoProxyServer(private val inspector: BlurayIsoInspector) {

    private data class IsoSession(
        val url: String,                       // ISO 的 URL（远程 http(s) 或本地 file）
        val headers: Map<String, String>,
        val streamPath: String,
        val streamSize: Long,
        val source: CachedIsoStreamSource?,    // null = 按 streamPath 直读（单文件无分段）
    )

    private val sessions = ConcurrentHashMap<String, IsoSession>()
    // 外挂字幕会话：本地和远端统一走代理——本地是读进内存的字节，
    // 远端是 App 代拉的 URL；mpv 永远只读本机，不落盘、不分两种挂法
    private class SubSession(val remoteUrl: String?, val bytes: ByteArray?)
    private val subSessions = ConcurrentHashMap<String, SubSession>()
    private val subClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .followRedirects(true)
            .followSslRedirects(true)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()
    }
    private val playlists = ConcurrentHashMap<String, String>()
    private var serverSocket: ServerSocket? = null
    private val pool = Executors.newCachedThreadPool()
    var port: Int = 2323
        private set

    fun start() {
        if (serverSocket != null) return
        val ss = try {
            ServerSocket(2323, 50, java.net.InetAddress.getByName("127.0.0.1"))
        } catch (_: Exception) {
            ServerSocket(0, 50, java.net.InetAddress.getByName("127.0.0.1"))
        }
        serverSocket = ss
        port = ss.localPort
        IsoLog.i("proxy started: port=$port")
        pool.execute {
            while (!ss.isClosed) {
                try {
                    val sock = ss.accept()
                    pool.execute { handleConnection(sock) }
                } catch (_: Exception) { break }
            }
        }
    }

    fun close() {
        try { serverSocket?.close() } catch (_: Exception) { }
        serverSocket = null
    }

    fun baseUrl(): String = "http://127.0.0.1:$port"

    fun createIsoMediaUrl(
        url: String,
        headers: Map<String, String>?,
        streamPath: String,
        streamSize: Long,
        isoStreamSource: CachedIsoStreamSource?,
    ): String {
        val token = UUID.randomUUID().toString().replace("-", "")
        sessions[token] = IsoSession(url, headers ?: emptyMap(), streamPath, streamSize, isoStreamSource)
        IsoLog.i("proxy session: $streamPath size=$streamSize source=${isoStreamSource != null}")
        return "${baseUrl()}/iso/$token$streamPath"
    }

    fun createIsoPlaylistUrl(
        url: String,
        headers: Map<String, String>?,
        segments: List<IsoPlaybackSegment>,
    ): String {
        require(segments.isNotEmpty()) { "iso playlist requires at least one segment" }
        val segmentUrls = segments.map { seg ->
            createIsoMediaUrl(url, headers, seg.streamPath, seg.streamSize, seg.source)
        }
        val targetDuration = maxOf(
            1, ceil(segments.maxOf { it.durationSeconds }).toInt()
        )
        val lines = ArrayList<String>()
        lines.add("#EXTM3U")
        lines.add("#EXT-X-VERSION:3")
        lines.add("#EXT-X-PLAYLIST-TYPE:VOD")
        lines.add("#EXT-X-TARGETDURATION:$targetDuration")
        lines.add("#EXT-X-MEDIA-SEQUENCE:0")
        segments.zip(segmentUrls).forEachIndexed { index, (seg, segUrl) ->
            if (index > 0) lines.add("#EXT-X-DISCONTINUITY")
            lines.add("#EXTINF:${"%.3f".format(seg.durationSeconds)},")
            lines.add(segUrl)
        }
        lines.add("#EXT-X-ENDLIST")
        val playlistText = lines.joinToString("\n") + "\n"
        val token = UUID.randomUUID().toString().replace("-", "")
        playlists[token] = playlistText
        return "${baseUrl()}/m3u/$token"
    }

    // ---- HTTP 服务 ----
    /** 远端字幕代理地址：/sub/{token}.{ext}（ext 让 ffmpeg 直接按扩展名选 demuxer） */
    fun createSubUrl(remoteUrl: String, ext: String): String {
        val token = UUID.randomUUID().toString().replace("-", "")
        subSessions[token] = SubSession(remoteUrl, null)
        return "${baseUrl()}/sub/$token.$ext"
    }

    /** 本地字幕代理地址：字节已在内存，与远端走同一挂载逻辑 */
    fun createSubBytesUrl(bytes: ByteArray, ext: String): String {
        val token = UUID.randomUUID().toString().replace("-", "")
        subSessions[token] = SubSession(null, bytes)
        return "${baseUrl()}/sub/$token.$ext"
    }

    private fun handleConnection(sock: Socket) {
        sock.use { s ->
            try {
                val reader = BufferedReader(InputStreamReader(s.getInputStream()))
                val requestLine = reader.readLine() ?: return
                val parts = requestLine.split(" ")
                if (parts.size < 2) return
                val method = parts[0]
                val rawPath = parts[1].substringBefore("?")
                val headers = HashMap<String, String>()
                while (true) {
                    val line = reader.readLine() ?: break
                    if (line.isEmpty()) break
                    val i = line.indexOf(':')
                    if (i > 0) headers[line.substring(0, i).trim()] = line.substring(i + 1).trim()
                }
                val path = URLDecoder.decode(rawPath, "UTF-8")
                IsoLog.i("proxy req: $method $path range=${headers.entries.firstOrNull { it.key.equals("Range", true) }?.value}")
                when {
                    path.startsWith("/iso/") -> serveIso(s.getOutputStream(), method, path, headers)
                    path.startsWith("/m3u/") -> servePlaylist(s.getOutputStream(), path)
                    path.startsWith("/sub/") -> serveSub(s.getOutputStream(), path)
                    else -> sendStatus(s.getOutputStream(), 404, "Not Found")
                }
            } catch (e: Throwable) {
                // Throwable 而非 Exception：OOM 等 Error 也要落日志，别无声死线程
                IsoLog.e("proxy handleConnection failed", e)
                try { sendStatus(sock.getOutputStream(), 500, "Internal Error") } catch (_: Exception) { }
            }
        }
    }

    /**
     * 远端字幕代理：App 用浏览器 UA 跟随跳转拉取正文（mpv 自带的 ffmpeg
     * http 客户端在部分站上会因 UA/Referer/跳转被拒），再经本机喂给 mpv。
     * 字幕只有几十 KB，全程内存，不落盘。
     */
    private fun serveSub(out: OutputStream, path: String) {
        val token = path.removePrefix("/sub/").substringBefore('.')
        val session = subSessions[token] ?: return sendStatus(out, 404, "Not Found")
        try {
            val bytes = session.bytes ?: run {
                val remote = session.remoteUrl
                    ?: return sendStatus(out, 404, "Not Found")
                val req = Request.Builder().url(remote)
                    .header("User-Agent", "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                    .build()
                subClient.newCall(req).execute().use { resp ->
                    if (!resp.isSuccessful) return sendStatus(out, 502, "Bad Gateway")
                    resp.body?.bytes()
                }
            } ?: return sendStatus(out, 502, "Bad Gateway")
            val head = "HTTP/1.1 200 OK\r\nContent-Type: text/plain; charset=utf-8\r\n" +
                "Content-Length: ${bytes.size}\r\nConnection: close\r\n\r\n"
            out.write(head.toByteArray())
            out.write(bytes)
            out.flush()
        } catch (e: Exception) {
            IsoLog.e("serveSub failed", e)
            try { sendStatus(out, 502, "Bad Gateway") } catch (_: Exception) { }
        }
    }

    private fun servePlaylist(out: OutputStream, path: String) {
        val token = path.removePrefix("/m3u/").substringBefore("/")
        val text = playlists[token] ?: return sendStatus(out, 404, "Not Found")
        val body = text.toByteArray(Charsets.UTF_8)
        val head = "HTTP/1.1 200 OK\r\nContent-Type: application/vnd.apple.mpegurl\r\n" +
            "Content-Length: ${body.size}\r\nConnection: close\r\n\r\n"
        out.write(head.toByteArray())
        out.write(body)
        out.flush()
    }

    private fun serveIso(out: OutputStream, method: String, path: String, headers: Map<String, String>) {
        // /iso/{token}/BDMV/STREAM/xxx.M2TS
        val rest = path.removePrefix("/iso/")
        val slash = rest.indexOf('/')
        if (slash < 0) return sendStatus(out, 404, "Not Found")
        val token = rest.substring(0, slash)
        val streamPath = rest.substring(slash)   // 含前导 /
        val session = sessions[token] ?: return sendStatus(out, 404, "Not Found")

        val rangeHeader = headers.entries.firstOrNull {
            it.key.equals("Range", ignoreCase = true)
        }?.value
        val range = rangeHeader?.let { parseRange(it, session.streamSize) }
        val source = session.source
            ?: return sendStatus(out, 500, "single-file source not wired (see PORTING.md)")
        val total = session.streamSize

        if (method.equals("HEAD", ignoreCase = true)) {
            val head = "HTTP/1.1 200 OK\r\nContent-Type: video/mp2t\r\n" +
                "Content-Length: $total\r\nAccept-Ranges: bytes\r\nConnection: close\r\n\r\n"
            out.write(head.toByteArray())
            out.flush()
            return
        }

        // 流式发：先发头，再 4MB 一片读一片写。
        // 绝不能把整个 Range 读进内存——mpv 首开就是 bytes=0-（整片 65GB），
        // 一次性 materialize 直接 OOM 且 Error 不被 catch(Exception) 捕获，
        // 表现为“服务器无响应”（实测踩过）。桌面代理同款分片语义。
        val start = range?.first ?: 0L
        val end = range?.second ?: (total - 1)
        val len = end - start + 1
        val head = if (range != null) {
            "HTTP/1.1 206 Partial Content\r\nContent-Type: video/mp2t\r\n" +
                "Content-Range: bytes $start-$end/$total\r\n" +
                "Content-Length: $len\r\nAccept-Ranges: bytes\r\n" +
                "Connection: close\r\n\r\n"
        } else {
            "HTTP/1.1 200 OK\r\nContent-Type: video/mp2t\r\n" +
                "Content-Length: $len\r\nAccept-Ranges: bytes\r\n" +
                "Connection: close\r\n\r\n"
        }
        out.write(head.toByteArray())
        out.flush()
        // v51 取数日志：每片起止成对打。某片只有 start 没 ok =
        // 代理卡在读这一片（再往下看 range fetch / http fetch 行定
        // 是 reader 还是某跳 HTTP）。只加日志，不改发片逻辑。
        var off = start
        val reqT0 = System.currentTimeMillis()
        while (off <= end) {
            val chunkEnd = minOf(off + 8 * 1024 * 1024 - 1, end)
            val chunkT0 = System.currentTimeMillis()
            IsoLog.i("serveIso chunk start: $streamPath off=$off end=$chunkEnd")
            val (chunk, _) = inspector.readRangeFromSource(
                session.url, session.headers, source, off, chunkEnd
            )
            IsoLog.i("serveIso chunk ok: $streamPath off=$off bytes=${chunk.size} ${System.currentTimeMillis() - chunkT0}ms")
            if (chunk.isEmpty()) break
            out.write(chunk)
            out.flush()
            off += chunk.size
        }
        IsoLog.i("serveIso done: $streamPath start=$start end=$end ${System.currentTimeMillis() - reqT0}ms")
    }

    private fun parseRange(header: String, total: Long): Pair<Long, Long>? {
        val m = Regex("""bytes=(\d+)-(\d*)""").matchEntire(header.trim()) ?: return null
        val start = m.groupValues[1].toLong()
        val end = m.groupValues[2].takeIf { it.isNotEmpty() }?.toLong() ?: (total - 1)
        if (start < 0 || start >= total) return null
        return start to minOf(end, total - 1)
    }

    private fun sendStatus(out: OutputStream, code: Int, message: String) {
        out.write("HTTP/1.1 $code $message\r\nConnection: close\r\n\r\n".toByteArray())
        out.flush()
    }
}
