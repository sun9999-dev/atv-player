# PORTING.md — desktop Python → 原生 Kotlin 移植规格

基线：上游 `power721/atv-player` v0.105.0 + 独立播放器补丁
（`atv-iso-track-all-v8` / `atv-subtitle-off-fix` / `atv-context-menu-click-fix` /
`atv-iso-on-render-fix-v2` + `mpv_widget.py` render 版）。
Python 源码位置：`/tmp/atv-upstream`（或重 clone 后 `git checkout v0.105.0`）。

## 一、模块映射

| Python（desktop） | Kotlin（本 kit） | 状态 |
|---|---|---|
| `standalone_player_atv_windows.py::_signed_url_get` / `_signed_url_fetch_once` | `net/SignedUrl.kt` | ✅ 完整移植（含 Content-Length 双头 bug 修复） |
| `::_local_file_get` / `_LocalFileResponse` | `net/LocalFileGet.kt` | ✅ 完整移植 |
| `::_unwrap_scheme_url` | `ui/SchemeActivity.unwrapSchemeUrl` | ✅ 完整移植 |
| `::_make_play_item` 路由（远程 ISO/本地 ISO/直链） | `ui/PlayerActivity.resolvePlayUrl` | ✅ 完整移植 |
| `player/bluray_iso.py::_parse_mpls_playlist` | `iso/MplsParser.kt` | ✅ 完整移植 |
| `::_parse_clpi_entry_points` 系列 | `iso/ClpiParser.kt`（entry points） | ✅ 完整移植 |
| v8 补丁 `_parse_clpi_program_languages` / `_clpi_coding_type_kind` | `iso/ClpiParser.kt`（program languages） | ✅ 完整移植 |
| `::pick_main_feature_stream` / 各 `_looks_like_*` / `_trim_leading_intro_play_items` | `iso/BlurayIsoInspector.kt` | ✅ 完整移植 |
| `::_compute_trimmed_clip_range` / `_slice_cached_iso_stream_source` / `_compose_cached_iso_stream_sources` | 同上 | ✅ 完整移植 |
| `::read_iso_stream_range_from_source` | `IsoModels.CachedIsoStreamSource.mapRange` + `BlurayIsoInspector.readRangeFromSource` | ✅ 完整移植 |
| `proxy/server.py::create_iso_media_url` / `create_iso_playlist_url` + `/iso/` `/m3u/` 服务 | `proxy/IsoProxyServer.kt` | ✅ 核心移植（只含 ISO 路径；DASH/CENC/通用媒体代理不移植，独立播放器用不上） |
| `mpv_widget.py` render 路径（`vo=gpu-next`/`hwdec=auto-safe`） | `app/src/main/jni/mpv_jni.c` + `mpv/Mpv.kt` + `mpv/MpvView.kt` | ✅ JNI 子集（够用；log/event 全量按需加） |
| v8 补丁 `set_iso_track_languages` / `_iso_language_for_track` | `ui/PlayerActivity.readTracks` | ✅ 完整移植（同类型顺序补空 lang） |
| `player/bluray_iso.py` 的 pycdlib UDF 路径（`_RemoteUdfIso` 全套） | `iso/UdfReader.kt` | ⚠️ 结构完整、字节解析已实现，**需真机 ISO 联调验证**（风险见二） |
| desktop PlayerWindow 完整 UI | `ui/PlayerActivity.kt` + `ui/MainActivity.kt` | ⚠️ 简化版（播放/进度/音轨/字幕/倍速入口）；右键菜单→按钮，文件对话框→SAF |

## 二、UDF（UdfReader.kt）说明 —— 偏移已对照 pycdlib 校准

Python 用 pycdlib 解析 ECMA-167 描述符；Kotlin 直接手写。**所有关键偏移
已对照 pycdlib 源码的 FMT 串逐一校准**（`python3 -c "import pycdlib.udf"`，
Ubuntu 本机验证）：

| 描述符 | 字段 | 偏移 | pycdlib FMT |
|---|---|---|---|
| FSD（tag 256） | root_dir_icb（long_ad 16） | 400 | `<16s12sHHLLLL64s128s64s32s32s32s16s32s16s16s32s` |
| LVD（tag 6） | logical_block_size | 212 | `<16sL64s128sL32s16sLL32s128s8s72s` |
| LVD | map_table_length / num_partition_maps / 分区表 | 264 / 268 / 440 | 同上 |
| PD（tag 5） | part_num / part_start_location | 22 / 188 | `<16sLHH32s128sLLL32s128s156s` |
| File Entry（tag 261） | information_length | 56 | `<16s20sLLLHBBLQQ12s12s12sL16s32sQLL` |
| File Entry | len_extended_attrs / len_alloc_descs / AD 起始 | 168 / 172 / 176+lenEA | 同上 |
| File Entry | icbtag.flags（AD 类型 = flags & 7） | 34 | 同上 |
| FID（tag 257） | characteristics / len_fi / icb / len_impl_use / 名字 | 18 / 19 / 20 / 36 / 38+len_impl_use | `<16sHBB16sH` |
| long_ad / short_ad | | `<LLH6s` / `<LL` | 同上 |

`is_parent` = `(characteristics & 0x08) != 0`（不是空名判断）；
`is_dir` = `(characteristics & 0x02) != 0`；
FID 名字首字节是 compression id（0x08=latin-1，0x10=utf-16_be），
`len_fi` 含这 1 字节；`extent_length` 取 `& 0x3FFFFFFF`。

仍需真机 ISO 联调验证的点：

1. **Anchor 位置**：先读 256 扇区，失败读 N-2。Blu-ray 都是 256。
2. **metadata 分区（type-2 map）**：Blu-ray 罕见，直接抛错；真遇到再实现
   `_parse_udf_metadata_partition_map` 的等价逻辑。
3. **中文文件名**：UTF-16BE 路径（compression id 0x10）需用中文名 ISO 实测。
4. **extended_ad（AD 类型 2）**：直接抛错；Blu-ray 实测应为 short_ad。

验证顺序（每步独立可测）：
```
a) UdfReader.open() 不抛错，statStreams() 列出 /BDMV/STREAM/*.M2TS 且大小合理
b) readWholeFile("/BDMV/PLAYLIST/00000.MPLS") -> MplsParser.parse 不抛错
c) readClipInfo("00001") -> entryPoints 非空
d) preparePlayback 返回 plan（含 playlist_segments 或单 stream）
e) IsoProxyServer 出 /m3u/ 或 /iso/ URL，curl -r bytes=0-1023 能拿到 206
f) mpv 播代理 URL，音轨/字幕菜单语言标签正确
```
a-d 可以在 JVM 单元测试里跑（UdfReader/BlockReader 都是纯 Kotlin，不依赖 Android），
**建议先写单元测试再上真机**。

## 三、行为对照（不要回退的坑）

1. **SignedUrl Content-Length 双头**：扩 Range 回 206 时必须先删旧的
   `content-range`/`content-length`（忽略大小写）再写新的，否则调用方按
   1048576 等 body 报 "peer closed connection"。这是 desktop 修过的真 bug。
2. **重定向 query 合并只在同 host**：跨 host（源站->CDN）用目标原样，签名按 host 隔离。
3. **CLPI 裁剪 192 对齐**：`start = (ep.byte_offset / 192) * 192`，
   `end = ((next_ep.byte_offset + 191) / 192) * 192`，超界 clamp 到 streamSize。
4. **m3u8 段间 `#EXT-X-DISCONTINUITY`**：多段 playlist 必须有，否则切段花屏。
5. **语言补顺序**：只补 `lang` 为空的轨道，按同类型在 ProgramInfo 里的顺序，
   不是按 mpv track id 顺序。
6. **`atvplayer://` 解包**：按 `?url=` 切一次；只有 `http%3A` 开头才 unquote；
   幂等（解过的再解不变）。

## 四、没移植的东西（有意）

- DASH/CENC/通用媒体代理（`/media/`、`/dash/` 等）：独立播放器只播直链和 ISO。
- M3U8AdFilter：独立播放器场景用不上（那是主 app 的去广告）。
- 字幕下载/匹配、danmaku、插件系统：主 app 功能，不在独立播放器范围。
- desktop 的右键菜单/快捷键全集：TV 键鼠 + Pad 触摸只保留核心操作。

## 五、GPL

libmpv + ffmpeg 是 GPL。分发 APK 时遵守 GPL（提供源码获取方式）。
本 kit 的 Kotlin/C 代码建议同样 GPLv3+，与 mpv-android 一致。
