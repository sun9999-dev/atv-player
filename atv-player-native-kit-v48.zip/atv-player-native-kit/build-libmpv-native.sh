#!/usr/bin/env bash
# 用 mpv-android 的 buildscripts 编 libmpv（只编 native 依赖 + libmpv，不编 APK），
# 产物放到 app/src/main/jniLibs/<abi>/，双 ABI：arm64-v8a + armeabi-v7a。
#
# 复用路径（A）：./buildall.sh --arch <arch> mpv
#   arch 取值：arm64 / armv7l / x86_64（mpv-android 的 buildscripts 命名）
#   产物：prefix/<arch>/lib/libmpv.so + ffmpeg/libplacebo 等依赖 .so
# 捷径验证（B）：--from-apk <mpv-android.apk> 从官方 APK 解 lib/<abi>/*.so
#
# 用法：
#   ./build-libmpv-native.sh [--arch arm64|armv7l|both] [--from-apk xxx.apk]
#                            [--mpv-android-dir ~/src/mpv-android]
set -euo pipefail
KIT_DIR="$(cd "$(dirname "$0")" && pwd)"
ARCH="both"
FROM_APK=""
MPV_ANDROID_DIR="${MPV_ANDROID_DIR:-$HOME/src/mpv-android}"
OUT="$KIT_DIR/app/src/main/jniLibs"
INCLUDE="$KIT_DIR/app/src/main/jni/include"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --arch) ARCH="$2"; shift 2 ;;
    --from-apk) FROM_APK="$2"; shift 2 ;;
    --mpv-android-dir) MPV_ANDROID_DIR="$2"; shift 2 ;;
    *) echo "未知参数 $1"; exit 1 ;;
  esac
done

# arch 名映射：mpv-android buildscripts 用 arm64/armv7l；Android ABI 用 arm64-v8a/armeabi-v7a
declare -A ABI_MAP=( [arm64]="arm64-v8a" [armv7l]="armeabi-v7a" )
TARGETS=()
case "$ARCH" in
  both) TARGETS=(arm64 armv7l) ;;
  arm64|armv7l) TARGETS=("$ARCH") ;;
  *) echo "arch 只能是 arm64|armv7l|both"; exit 1 ;;
esac

if [[ -n "$FROM_APK" ]]; then
  # ---- 捷径：从官方 APK 解 .so ----
  [[ -f "$FROM_APK" ]] || { echo "APK 不存在：$FROM_APK"; exit 1; }
  TMP="$(mktemp -d)"
  trap 'rm -rf "$TMP"' EXIT
  for t in "${TARGETS[@]}"; do
    abi="${ABI_MAP[$t]}"
    dest="$OUT/$abi"
    mkdir -p "$dest"
    echo "解 $abi ..."
    unzip -o -q "$FROM_APK" "lib/$abi/*.so" -d "$TMP"
    cp -f "$TMP/lib/$abi/"*.so "$dest/"
    ls "$dest"
  done
  echo "OK：$OUT"
  exit 0
fi

# ---- 正规：buildall.sh ----
# buildall.sh 在仓库的 buildscripts/ 子目录里，不在仓库根
[[ -x "$MPV_ANDROID_DIR/buildscripts/buildall.sh" ]] || {
  echo "找不到 $MPV_ANDROID_DIR/buildscripts/buildall.sh"
  echo "先 git clone https://github.com/mpv-android/mpv-android"
  echo "或用 --mpv-android-dir 指定，或 --from-apk 走捷径"
  exit 1
}
# meson 版本门（fontconfig 要 >= 1.11.0；apt 的 meson 在 22.04 是 0.61.2，会报
# "Meson version is 0.61.2 but project requires >= 1.11.0"）。用 pip 升到新版。
MESON_MIN="1.11.0"
meson_ok() {
  command -v meson >/dev/null || return 1
  python3 - "$MESON_MIN" <<'PYEOF'
import subprocess, sys
try:
    cur = subprocess.run(["meson", "--version"], capture_output=True, text=True).stdout.strip().split()[0]
    t = lambda v: [int(x) for x in v.split(".")[:3]]
    sys.exit(0 if t(cur) >= t(sys.argv[1]) else 1)
except Exception:
    sys.exit(1)
PYEOF
}
export PATH="$HOME/.local/bin:/usr/local/bin:$PATH"
if ! meson_ok; then
  echo "=== meson < $MESON_MIN 或没有，pip 升级（要 >= $MESON_MIN）==="
  python3 -m pip install --upgrade --user "meson>=$MESON_MIN"     || python3 -m pip install --upgrade --break-system-packages "meson>=$MESON_MIN"
  hash -r
  meson_ok || { echo "meson 升级后仍不满足 >= $MESON_MIN，当前：$(meson --version 2>/dev/null)"; exit 1; }
  echo "meson 已升到 $(meson --version)"
fi
# meson 版本变了就清掉全部 _build_*：旧 meson 配的目录（如 dav1d，它能过旧版检查）
# 在新 meson 下会报 "build.dat references functions or classes that don't exist"。
# 用版本戳判断，没变就不清（不误伤已编好的目录）。
MESON_STAMP="$MPV_ANDROID_DIR/buildscripts/.kit-meson-version"
CUR_MESON="$(meson --version 2>/dev/null | head -n1 | tr -d ' \r')"
if [[ -d "$MPV_ANDROID_DIR/buildscripts/deps" && "$(cat "$MESON_STAMP" 2>/dev/null)" != "$CUR_MESON" ]]; then
  echo "meson 版本与上次不同（当前 $CUR_MESON），清理旧 _build_* 目录"
  find "$MPV_ANDROID_DIR/buildscripts/deps" -maxdepth 2 -type d -name "_build_*" -exec rm -rf {} + 2>/dev/null || true
  echo "$CUR_MESON" > "$MESON_STAMP"
fi

# 环境没搭好时（首次）：先下 SDK/NDK + 依赖源码（buildall.sh 在 buildscripts/sdk 里找 NDK）
if [[ ! -d "$MPV_ANDROID_DIR/buildscripts/sdk" ]]; then
  echo "=== 首次：下载 SDK/NDK + 依赖（download.sh，很久，只跑一次）==="
  ( cd "$MPV_ANDROID_DIR/buildscripts" && ./download.sh )
fi
for t in "${TARGETS[@]}"; do
  abi="${ABI_MAP[$t]}"
  echo "=== 编 $t ($abi) ==="
  ( cd "$MPV_ANDROID_DIR/buildscripts" && ./buildall.sh --arch "$t" mpv )
  dest="$OUT/$abi"
  mkdir -p "$dest"
  # libmpv.so + 依赖 .so（ffmpeg/libplacebo 等）全拷：扫整棵 prefix 树。
  # 依赖可能装在 prefix/<arch>/lib，也可能在 prefix/<arch>/usr/local/lib 等子目录
  # （只抄 lib/ 会漏 libplacebo/libass → 运行时 UnsatisfiedLinkError 闪退）。
  # SONAME/版本号文件名保留
  find "$MPV_ANDROID_DIR/buildscripts/prefix/$t" -name "lib*.so*" -exec cp -f {} "$dest/" \; 2>/dev/null || true
  echo "--- $abi:"
  ls "$dest"
done

# libmpv 头文件（mpv_jni.c 要 include <mpv/client.h> 等）
# buildscripts 的 prefix 里通常没有头文件；从 mpv 源码拷：
# mpv-android/buildscripts 会下 mpv 源码，头在 <mpv-android>/mpv/libmpv/
# 头文件在 buildscripts 下载的 mpv 源码里（include/mpv/）；用 find 兜底找
CLIENT_H="$(find "$MPV_ANDROID_DIR/buildscripts" -name client.h -path "*mpv*" 2>/dev/null | head -n 1)"
if [[ -n "$CLIENT_H" ]]; then
  HDR_DIR="$(dirname "$CLIENT_H")"
  mkdir -p "$INCLUDE/mpv"
  cp -f "$HDR_DIR/client.h" "$HDR_DIR/render.h" "$HDR_DIR/render_gl.h" "$INCLUDE/mpv/" 2>/dev/null || true
  echo "头文件 -> $INCLUDE/mpv/（来源 $HDR_DIR）"
  ls "$INCLUDE/mpv/"
else
  echo "没找到 mpv 头文件，手动把 mpv 源码的 include/mpv/*.h 拷到 $INCLUDE/mpv/"
fi
echo "OK"
