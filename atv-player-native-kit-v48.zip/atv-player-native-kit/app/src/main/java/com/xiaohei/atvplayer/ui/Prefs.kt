package com.xiaohei.atvplayer.ui

import android.content.Context

/** 用户设置（初始值），设置页读写；播放器/主页读取。 */
object Prefs {
    private const val FILE = "atv_settings"
    private fun sp(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    /** 播放器初始方向："landscape" / "portrait" */
    fun orientation(ctx: Context): String =
        sp(ctx).getString("orientation", "landscape") ?: "landscape"
    fun setOrientation(ctx: Context, v: String) {
        sp(ctx).edit().putString("orientation", v).apply()
    }

    /** 远程 ISO 起播预读时长（秒）；按平均码率换算字节，缓存上限封顶 */
    fun preRollSeconds(ctx: Context): Int = sp(ctx).getInt("preroll_seconds", 10)
    fun setPreRollSeconds(ctx: Context, v: Int) {
        sp(ctx).edit().putInt("preroll_seconds", v.coerceIn(0, 120)).apply()
    }

    /** 播放默认语言（ISO 639 代码；"" = 不指定，走播放器默认选轨） */
    fun defaultLanguage(ctx: Context): String =
        sp(ctx).getString("default_language", "") ?: ""
    fun setDefaultLanguage(ctx: Context, v: String) {
        sp(ctx).edit().putString("default_language", v).apply()
    }

    /** 播放器初始音量 0-100 */
    fun volume(ctx: Context): Int = sp(ctx).getInt("volume", 100)
    fun setVolume(ctx: Context, v: Int) {
        sp(ctx).edit().putInt("volume", v.coerceIn(0, 100)).apply()
    }
}
