package com.xiaohei.atvplayer.mpv

import android.content.Context
import android.opengl.GLSurfaceView
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/**
 * mpv render API 的 GLSurfaceView。
 * 用法：add 到布局；surface 建好后调 attach(mpv)。
 */
class MpvView(context: Context) : GLSurfaceView(context) {

    private var mpv: Mpv? = null
    private var viewW = 0
    private var viewH = 0

    /** render context 建好后回调（GL 线程触发，实现方自己切线程） */
    var onRenderReady: (() -> Unit)? = null
    var onRenderError: (() -> Unit)? = null

    init {
        setEGLContextClientVersion(3)
        preserveEGLContextOnPause = true
        setRenderer(object : Renderer {
            override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
                val m = mpv ?: return
                if (m.initRender() == 0) onRenderReady?.invoke() else onRenderError?.invoke()
            }
            override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
                viewW = width
                viewH = height
            }
            override fun onDrawFrame(gl: GL10?) {
                mpv?.render(viewW, viewH)
            }
        })
        // 按需渲染：mpv 的 update 回调里 requestRender。
        // 必须在 setRenderer 之后设：setRenderMode 要用 GLThread，提前调必 NPE（实测崩溃）。
        renderMode = RENDERMODE_WHEN_DIRTY
    }

    fun attach(mpv: Mpv) {
        this.mpv = mpv
        // 渲染更新走独立通道，不跟 PlayerActivity 的事件回调抢
        mpv.renderUpdateListener = { requestRender() }
    }
}
