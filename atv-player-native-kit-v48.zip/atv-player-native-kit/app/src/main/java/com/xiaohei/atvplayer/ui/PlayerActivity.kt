package com.xiaohei.atvplayer.ui

import android.app.AlertDialog
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import androidx.activity.result.contract.ActivityResultContracts
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.xiaohei.atvplayer.iso.BlurayIsoInspector
import com.xiaohei.atvplayer.iso.CacheTuning
import com.xiaohei.atvplayer.iso.IsoLog
import com.xiaohei.atvplayer.mpv.Mpv
import com.xiaohei.atvplayer.mpv.MpvView
import com.xiaohei.atvplayer.proxy.IsoProxyServer
import org.json.JSONArray
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors

/**
 * 播放器。路由逻辑对应 desktop 的 `_make_play_item`
 *（standalone_player_atv_windows.py:527）：
 *
 * - 远程 http(s) 且 path 以 .iso 结尾 -> BlurayIsoInspector 解析
 *   （SignedUrl 取流）+ IsoProxyServer 出 /m3u/ 或 /iso/ 代理 URL -> mpv 播代理
 * - 本地 .iso（/storage/... 真实路径）-> 同上，本地文件读
 * - content:// -> v1 拷到 cache 再按本地 .iso 走（大文件慢；fd 直通见 PORTING.md）
 * - 其它 -> mpv 直播
 *
 * ISO 语言：plan.streamLanguages（.clpi ProgramInfo 的 (kind, lang)，顺序），
 * mpv track-list 里同类型按顺序补空 lang —— 照抄 desktop 的
 * set_iso_track_languages / _iso_language_for_track（v8 补丁）。
 *
 * 操作：TV 键鼠（空格/方向键/点击），Pad 触摸。不做 DPAD/遥控器。
 */
class PlayerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_INPUT = "input"
    }

    private lateinit var mpv: Mpv
    private lateinit var mpvView: MpvView
    private lateinit var seekBar: SeekBar
    private lateinit var timeLabel: TextView
    private lateinit var playBtn: Button
    private lateinit var controls: LinearLayout

    private val bg = Executors.newSingleThreadExecutor()
    private var inspector: BlurayIsoInspector? = null
    private var proxy: IsoProxyServer? = null
    /** 当前 ISO 的 (kind, lang)，ProgramInfo 顺序；非 ISO 为空 */
    private var isoLanguages: List<Pair<String, String>> = emptyList()
    private var durationSec: Double = 0.0
    private var contentPfd: android.os.ParcelFileDescriptor? = null
    private var renderReady = false
    private var pendingInput: Pair<String, Uri?>? = null
    private var seeking = false
    private lateinit var volumeBar: SeekBar
    private var portraitMode = false
    private lateinit var btnRow: LinearLayout
    private lateinit var btnRow2: LinearLayout
    private lateinit var volRow: LinearLayout
    private lateinit var audioBtn: Button
    private lateinit var subBtn: Button
    private lateinit var orientBtn: Button
    private lateinit var settingsBtn: Button
    private lateinit var extSubBtn: Button
    private var extSubChecked = false
    private var mountedSubSource: String? = null   // 本次播放已挂载的外挂字幕源（null=未挂）
    private var currentMediaInput: String = ""

    // 手动选外挂字幕（SAF）：fd 直通给 mpv，不落盘
    // 手动选外挂字幕（SAF）：读成字节进代理会话，与远端走同一挂载逻辑
    private val pickSub = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        try {
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: return@registerForActivityResult
            val name = queryDisplayName(uri) ?: "外挂字幕"
            val ext = name.substringAfterLast('.', "").ifEmpty { "srt" }
            val proxyUrl = getProxy().createSubBytesUrl(bytes, ext)
            mpv.command("sub-add", proxyUrl, "select", name)
            mountedSubSource = "manual"
            Toast.makeText(this, "已加载外挂字幕", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "字幕加载失败：${e.message}", Toast.LENGTH_LONG).show()
        }
    }
    private lateinit var volLabel: TextView
    // 控制条 30 秒无操作自动隐藏
    private val hideHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val hideRunnable = Runnable { controls.visibility = View.GONE }
    private fun scheduleHide() {
        hideHandler.removeCallbacks(hideRunnable)
        hideHandler.postDelayed(hideRunnable, 30_000)
    }
    private fun showControls() {
        controls.visibility = View.VISIBLE
        scheduleHide()
    }
    // 默认语言选轨（轨道清单就绪后执行一次）
    @Volatile private var langApplied = false
    private var appliedLangPref: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 初始方向按设置（播放中可经控制条按钮临时切换）
        portraitMode = Prefs.orientation(this) == "portrait"
        requestedOrientation = if (portraitMode)
            android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        else
            android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE

        mpvView = MpvView(this)
        controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 16, 32, 32)
        }
        timeLabel = TextView(this).apply { textSize = 16f; setTextColor(android.graphics.Color.WHITE) }
        seekBar = SeekBar(this).apply {
            max = 1000
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser && durationSec > 0) {
                        timeLabel.text = "${fmtTime(p / 1000.0 * durationSec)} / ${fmtTime(durationSec)}"
                    }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) { seeking = true }
                override fun onStopTrackingTouch(sb: SeekBar?) {
                    seeking = false
                    if (durationSec > 0) mpv.seek(seekBar.progress / 1000.0 * durationSec)
                }
            })
        }
        btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        btnRow2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        playBtn = Button(this).apply {
            text = "⏸"
            textSize = 16f
            setOnClickListener { mpv.playPause() }
        }
        audioBtn = Button(this).apply {
            text = "音轨"
            textSize = 16f
            setOnClickListener { showTrackMenu("audio") }
        }
        subBtn = Button(this).apply {
            text = "字幕"
            textSize = 16f
            setOnClickListener { showTrackMenu("sub") }
        }
        // 横/竖屏切换（manifest 有 orientation configChanges，不重建播放）
        orientBtn = Button(this).apply {
            textSize = 16f
            setOnClickListener {
                // 先乐观翻转排版，onConfigurationChanged 再与真实方向对齐
                portraitMode = !portraitMode
                requestedOrientation = if (portraitMode)
                    android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                else
                    android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                applyControlLayout()
            }
        }
        // 外挂字幕按钮（手动选字幕文件）
        extSubBtn = Button(this).apply {
            text = "外挂字幕"
            textSize = 16f
            setOnClickListener { onExtSubButton() }
        }
        // 设置按钮（从 g-box 直进播放、跳过起始页时也能进设置）
        settingsBtn = Button(this).apply {
            text = "设置"
            textSize = 16f
            setOnClickListener {
                startActivity(android.content.Intent(this@PlayerActivity, SettingsActivity::class.java))
            }
        }
        // 音量控件（横屏并入按钮行，竖屏单独一行，见 applyControlLayout）
        volLabel = TextView(this).apply {
            text = "🔊"
            textSize = 18f
            setPadding(16, 0, 8, 0)
        }
        volumeBar = SeekBar(this).apply {
            max = 100
            progress = 100
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) mpv.setProperty("volume", p.toString())
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        volRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        controls.addView(timeLabel)
        controls.addView(seekBar)
        controls.addView(btnRow)
        applyControlLayout()

        val root = FrameLayout(this)
        root.setBackgroundColor(android.graphics.Color.BLACK)
        root.addView(mpvView, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        root.addView(controls, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT).apply {
            gravity = android.view.Gravity.BOTTOM
        })
        setContentView(root)

        // 点击画面切换控制条（TV 鼠标 / Pad 触摸）；无操作 30 秒自动隐藏
        mpvView.setOnClickListener {
            if (controls.visibility == View.VISIBLE) {
                hideHandler.removeCallbacks(hideRunnable)
                controls.visibility = View.GONE
            } else {
                showControls()
            }
        }
        scheduleHide()

        // 缓存按设备总内存分档（窗口缓存 + mpv 缓存）
        val am = getSystemService(android.app.ActivityManager::class.java)
        val memInfo = android.app.ActivityManager.MemoryInfo()
        am?.getMemoryInfo(memInfo)
        CacheTuning.applyForDevice(memInfo.totalMem)

        mpv = Mpv()
        if (mpv.create(caBundleFile(), CacheTuning.mpvCacheMiB, CacheTuning.mpvBackCacheMiB) != 0) {
            Toast.makeText(this, "mpv 初始化失败", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        mpvView.attach(mpv)
        // 初始音量按设置
        try {
            val v = Prefs.volume(this)
            mpv.setProperty("volume", v.toString())
            volumeBar.progress = v
        } catch (_: Exception) { }
        // 播放默认语言按设置：在 loadfile 之前设 alang/slang，起播选轨时生效；
        // 片源没有该语言时 mpv 按自身默认处理
        try {
            val lang = Prefs.defaultLanguage(this)
            if (lang.isNotEmpty()) {
                mpv.setProperty("alang", lang)
                mpv.setProperty("slang", lang)
            }
        } catch (_: Exception) { }
        // 必须等 render context 建好再 loadfile：VO 先于 render context 初始化时，
        // gpu-next 会去走 Android 原生 Surface 后端（要 wid），直接报
        // "Missing surface pointer" 然后只剩声音（实测）。
        mpvView.onRenderReady = {
            renderReady = true
            pendingInput?.let { (i, d) ->
                pendingInput = null
                openInput(i, d)
            }
        }
        mpvView.onRenderError = {
            runOnUiThread {
                Toast.makeText(this, "渲染初始化失败（见 logcat atvplayer_jni）", Toast.LENGTH_LONG).show()
            }
        }
        mpv.eventCallback = object : Mpv.EventCallback {
            override fun onEvent(name: String, data: String) {
                when (name) {
                    "property-change" -> onPropertyChange(data)
                    "end-file" -> runOnUiThread {
                        Toast.makeText(this@PlayerActivity, "播放结束", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            override fun onRenderUpdate() { /* MpvView 的 renderUpdateListener 已处理 */ }
        }
        mpv.observeProperty("duration")
        mpv.observeProperty("time-pos")
        mpv.observeProperty("pause")
        mpv.observeProperty("track-list")

        val input = intent.getStringExtra(EXTRA_INPUT)
            ?: intent.data?.toString() ?: ""
        pendingInput = SchemeActivity.unwrapSchemeUrl(input) to intent.data
        if (renderReady) {
            val (i, d) = pendingInput!!
            pendingInput = null
            openInput(i, d)
        }
    }

    /** assets 里的 Mozilla CA 包释放到 filesDir（Android 没有 curl/ffmpeg 能用的系统 CA 文件） */
    private fun caBundleFile(): String {
        val out = File(filesDir, "cacert.pem")
        if (!out.exists() || out.length() == 0L) {
            assets.open("cacert.pem").use { ins ->
                FileOutputStream(out).use { o -> ins.copyTo(o) }
            }
        }
        return out.absolutePath
    }

    private fun onPropertyChange(data: String) {
        // data = 属性名（JNI 只透了名字；值现取）
        when (data) {
            "duration" -> mpv.getPropertyString("duration")?.toDoubleOrNull()?.let {
                durationSec = it
            }
            "time-pos" -> if (!seeking) {
                mpv.getPropertyString("time-pos")?.toDoubleOrNull()?.let { pos ->
                    runOnUiThread {
                        if (durationSec > 0) {
                            seekBar.progress = (pos / durationSec * 1000).toInt()
                            timeLabel.text = "${fmtTime(pos)} / ${fmtTime(durationSec)}"
                        }
                    }
                }
            }
            "pause" -> runOnUiThread {
                playBtn.text = if (mpv.getPropertyString("pause") == "yes") "▶" else "⏸"
            }
            "track-list" -> {
                applyDefaultLanguage()
                maybeAutoExternalSub()
            }
        }
    }

    private fun openInput(input: String, dataUri: Uri?) {
        langApplied = false
        appliedLangPref = null
        currentMediaInput = input
        extSubChecked = false
        mountedSubSource = null
        IsoLog.i("atv-player native $KIT_VERSION openInput: ${input.take(140)}")
        if (needsNetworkConfirm(input, dataUri)) {
            // 非 WiFi（流量计费网络）先确认：4K 原盘流量很大
            runOnUiThread {
                AlertDialog.Builder(this)
                    .setTitle("当前不是 WiFi")
                    .setMessage("当前网络不是 WiFi，4K 原盘流量很大，是否继续播放？")
                    .setCancelable(false)
                    .setPositiveButton("是") { _, _ -> startPlayback(input, dataUri) }
                    .setNegativeButton("否") { _, _ -> finish() }
                    .show()
            }
        } else {
            startPlayback(input, dataUri)
        }
    }

    private fun startPlayback(input: String, dataUri: Uri?) {
        bg.execute {
            try {
                val playUrl = resolvePlayUrl(input, dataUri)
                IsoLog.i("openInput resolved -> $playUrl")
                runOnUiThread { mpv.loadFile(playUrl) }
            } catch (e: Exception) {
                IsoLog.e("openInput failed", e)
                runOnUiThread {
                    Toast.makeText(this, "打开失败：${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    /** 远程播放才需要确认：本地文件不走网络不提示；WiFi/有线不过问 */
    private fun needsNetworkConfirm(input: String, dataUri: Uri?): Boolean {
        if (dataUri?.scheme == "content") return false
        val inner = SchemeActivity.unwrapSchemeUrl(input)
        if (inner.startsWith("content://") || inner.startsWith("file://")
            || inner.startsWith("/")) return false
        if (!inner.startsWith("http://") && !inner.startsWith("https://")) return false
        val cm = getSystemService(android.net.ConnectivityManager::class.java)
            ?: return false
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return !caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI)
            && !caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_ETHERNET)
    }

    /**
     * 输入 -> mpv 可播 URL。ISO 走解析+代理（对应 _make_play_item + _local_iso_proxy_url）。
     */
    private fun resolvePlayUrl(input: String, dataUri: Uri?): String {
        // content://：fd 直读，全程不落盘（旧版全量拷 cacheDir 既慢又写 NAND）
        if (input.startsWith("content://") || dataUri?.scheme == "content") {
            val uri = dataUri ?: Uri.parse(input)
            val name = queryDisplayName(uri) ?: "media"
            val pfd = contentResolver.openFileDescriptor(uri, "r")
                ?: throw IllegalStateException("无法打开所选文件")
            contentPfd = pfd
            return if (name.lowercase().endsWith(".iso")) {
                // 以 content URI 为 key 注册 fd reader，inspector/代理全程复用
                getInspector().registerReader(
                    input, com.xiaohei.atvplayer.iso.FdBlockReader(pfd)
                )
                resolveRemoteIso(input)
            } else {
                // 普通媒体：/proc/self/fd 直通 mpv（同进程，fd 有效）
                "/proc/self/fd/${pfd.fd}"
            }
        }
        if (input.startsWith("http://") || input.startsWith("https://")) {
            val path = try { Uri.parse(input).path ?: "" } catch (_: Exception) { "" }
            if (path.lowercase().endsWith(".iso")) {
                return resolveRemoteIso(input)
            }
            return input
        }
        // 本地路径（/storage/...）
        val p = if (input.startsWith("file://")) Uri.parse(input).path ?: input else input
        return resolveLocal(p)
    }

    private fun resolveLocal(path: String): String {
        if (!path.lowercase().endsWith(".iso")) return path
        val insp = getInspector()
        val plan = insp.preparePlayback("file://$path", emptyMap())
        isoLanguages = plan.streamLanguages
        val px = getProxy()
        val playUrl = if (plan.playlistSegments.isNotEmpty()) {
            px.createIsoPlaylistUrl("file://$path", emptyMap(), plan.playlistSegments)
        } else {
            px.createIsoMediaUrl(
                "file://$path", emptyMap(),
                streamPath = plan.stream.path, streamSize = plan.stream.size,
                isoStreamSource = plan.source,
            )
        }
        warmupIso("file://$path", plan)
        return playUrl
    }

    private fun resolveRemoteIso(url: String): String {
        val insp = getInspector()
        // 远程 ISO：SignedUrl 做 get（含签名/Range 逻辑）；header 透 UA/Referer 由 SignedUrl 补
        val plan = insp.preparePlayback(url, emptyMap())
        isoLanguages = plan.streamLanguages
        val px = getProxy()
        val playUrl = if (plan.playlistSegments.isNotEmpty()) {
            px.createIsoPlaylistUrl(url, emptyMap(), plan.playlistSegments)
        } else {
            px.createIsoMediaUrl(
                url, emptyMap(),
                streamPath = plan.stream.path, streamSize = plan.stream.size,
                isoStreamSource = plan.source,
            )
        }
        warmupIso(url, plan)
        return playUrl
    }

    /** 起播预读（远程 ISO 才真正拉数据，本地在 warmup 内部跳过）。
     *  时长按设置（秒）：字节数 = 秒数 × 平均码率（有总时长用 总大小/总时长，
     *  否则按 8MB/s 估），并受窗口缓存总量 70% 封顶（超了也会被 LRU 挤掉）。 */
    private fun warmupIso(key: String, plan: com.xiaohei.atvplayer.iso.IsoPlaybackPlan) {
        val insp = getInspector()
        val seconds = Prefs.preRollSeconds(this)
        if (seconds <= 0) return
        val totalDur = plan.playlistSegments.sumOf { it.durationSeconds }
        val size = plan.source?.size ?: plan.stream.size
        val bytesPerSec = if (totalDur > 5 && size > 0) (size / totalDur).toLong()
            else 8L * 1024 * 1024
        val cap = (CacheTuning.maxWindows * 8L * 1024 * 1024 * 0.7).toLong()
        val bytes = (seconds * bytesPerSec)
            .coerceIn(8L * 1024 * 1024, maxOf(cap, 8L * 1024 * 1024))
        if (plan.playlistSegments.isNotEmpty()) {
            val seg = plan.playlistSegments[0]
            insp.warmup(key, emptyMap(), seg.source, minOf(bytes, seg.streamSize))
        } else if (plan.source != null) {
            insp.warmup(key, emptyMap(), plan.source!!, minOf(bytes, plan.stream.size))
        }
    }

    private fun getInspector(): BlurayIsoInspector {
        var i = inspector
        if (i == null) {
            i = BlurayIsoInspector()
            inspector = i
        }
        return i
    }

    private fun getProxy(): IsoProxyServer {
        var p = proxy
        if (p == null) {
            p = IsoProxyServer(getInspector())
            p.start()
            proxy = p
        }
        return p
    }

    // ---- 軌道菜单（语言标签按 .clpi 补）----
    private data class Track(val id: String, val type: String, val label: String, val selected: Boolean = false)

    private fun showTrackMenu(type: String) {
        bg.execute {
            val tracks = readTracks(type)
            runOnUiThread {
                val names = tracks.map { it.label }.toTypedArray()
                // 当前选中项打勾（单选列表系统自带标记）；“关闭”项在无选中时勾
                val checked = tracks.indexOfFirst { it.selected }.let { if (it >= 0) it else 0 }
                AlertDialog.Builder(this)
                    .setTitle(if (type == "audio") "音轨" else "字幕")
                    .setSingleChoiceItems(names, checked) { dialog, which ->
                        if (type == "audio") mpv.setAid(tracks[which].id)
                        else mpv.setSid(tracks[which].id)
                        dialog.dismiss()
                    }
                    .setNegativeButton("关闭", null)
                    .show()
            }
        }
    }

    /** ISO 639 代码 -> 语言自称（与桌面版菜单一致：English / 日本語 / 简体中文） */
    private fun displayLangName(code: String): String? {
        val c = code.lowercase().trim()
        when (c) {
            "zho", "chi", "zh", "zh-cn", "zh-hans", "cmn" -> return "简体中文"
            "zh-tw", "zh-hk", "zh-hant", "cht" -> return "繁體中文"
            "eng", "en" -> return "English"
            "jpn", "ja" -> return "日本語"
            "kor", "ko" -> return "한국어"
            "ces", "cze", "cs" -> return "čeština"
            "fra", "fre", "fr" -> return "français"
            "deu", "ger", "de" -> return "Deutsch"
            "spa", "es" -> return "español"
            "ita", "it" -> return "italiano"
            "rus", "ru" -> return "русский"
            "por", "pt" -> return "português"
            "nld", "dut", "nl" -> return "Nederlands"
            "pol", "pl" -> return "polski"
            "tur", "tr" -> return "Türkçe"
            "ara", "ar" -> return "العربية"
            "hin", "hi" -> return "हिन्दी"
            "tha", "th" -> return "ไทย"
            "vie", "vi" -> return "Tiếng Việt"
            "ind", "id" -> return "Bahasa Indonesia"
            "msa", "may", "ms" -> return "Bahasa Melayu"
            "dan", "da" -> return "dansk"
            "swe", "sv" -> return "svenska"
            "nor", "no" -> return "norsk"
            "fin", "fi" -> return "suomi"
            "ell", "gre", "el" -> return "ελληνικά"
            "heb", "he" -> return "עברית"
            "ukr", "uk" -> return "українська"
        }
        if (c.length in 2..3) {
            try {
                val loc = java.util.Locale(c)
                val n = loc.getDisplayLanguage(loc)
                if (n.isNotEmpty() && !n.equals(c, ignoreCase = true)) return n
            } catch (_: Exception) { }
        }
        return null
    }

    /** mpv codec 名 -> 菜单里短标签（与桌面版 [PGS] 风格一致） */
    private fun codecTag(codec: String): String = when (codec.lowercase()) {
        "hdmv_pgs_subtitle" -> "PGS"
        "dvd_subtitle" -> "VobSub"
        "subrip" -> "SRT"
        "ass", "ssa" -> "ASS"
        "webvtt" -> "WebVTT"
        "mov_text" -> "TX3G"
        "truehd" -> "TrueHD"
        "dts" -> "DTS"
        "eac3" -> "DD+"
        "ac3" -> "AC3"
        "aac" -> "AAC"
        "flac" -> "FLAC"
        "mp3" -> "MP3"
        "opus" -> "Opus"
        "pcm_bluray", "pcm_s16le", "pcm_s24le" -> "PCM"
        else -> ""
    }

    /** ISO 639 代码归一化（2 字母/旧 3 字母 -> mpv/CLPI 常用 3 字母） */
    private fun normalizeLang(code: String): String {
        return when (code.lowercase().trim()) {
            "zh", "chi" -> "zho"
            "zh-tw", "zh-hk", "cht" -> "zht"
            "zh-cn", "zh-hans" -> "zho"
            "en" -> "eng"
            "ja" -> "jpn"
            "ko" -> "kor"
            "fr", "fre" -> "fra"
            "de", "ger" -> "deu"
            "es" -> "spa"
            "ru" -> "rus"
            "cs", "cze" -> "ces"
            "pt" -> "por"
            "nl", "dut" -> "nld"
            "pl" -> "pol"
            "tr" -> "tur"
            "ar" -> "ara"
            "hi" -> "hin"
            "th" -> "tha"
            "vi" -> "vie"
            "id" -> "ind"
            "ms", "may" -> "msa"
            "da" -> "dan"
            "sv" -> "swe"
            "no" -> "nor"
            "fi" -> "fin"
            "el", "gre" -> "ell"
            "he" -> "heb"
            "uk" -> "ukr"
            else -> code.lowercase().trim()
        }
    }

    /**
     * 默认语言选轨：轨道清单就绪后执行。mpv 自带的 alang/slang 匹配不到
     * 是因为这盘在 mpv 层语言是空的（CLPI 补的语言只进了菜单标签），所以
     * 按与菜单同款的“mpv lang 为空时按同类型顺序补 CLPI 语言”算出每条轨道
     * 的实际语言，命中设置语言的第一条就设为当前轨；没命中不做任何事
     * （按播放器默认处理）。只在清单非空时才标记完成，避免文件未加载
     * 时的空清单把机会用掉。
     */
    private fun applyDefaultLanguage() {
        val pref = Prefs.defaultLanguage(this)
        if (pref.isEmpty() || langApplied) return
        val want = normalizeLang(pref)
        val json = mpv.getPropertyString("track-list") ?: return
        val arr = try { JSONArray(json) } catch (_: Exception) { return }
        if (arr.length() == 0) return
        for (type in listOf("audio", "sub")) {
            // 外挂字幕已挂载时不再按默认语言改 sid（否则 sub-add 触发的
            // 第二次 track-list 事件会把外挂字幕顶回内嵌轨道）
            if (type == "sub" && mountedSubSource != null) continue
            var typedIndex = 0
            var targetId: String? = null
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.optString("type") != type) continue
                var lang = o.optString("lang", "")
                if (lang.isEmpty() && isoLanguages.isNotEmpty()) {
                    val langs = isoLanguages.filter { it.first == kindFor(type) }.map { it.second }
                    if (typedIndex < langs.size) lang = langs[typedIndex]
                }
                if (normalizeLang(lang) == want) {
                    targetId = o.optString("id")
                    break
                }
                typedIndex++
            }
            if (targetId != null) {
                if (type == "audio") mpv.setAid(targetId) else mpv.setSid(targetId)
            }
        }
        langApplied = true
        appliedLangPref = pref
    }

    /**
     * 同名外挂字幕自动探测：轨道清单就绪后执行一次。只看“同目录同名、
     * 换字幕扩展名”的文件（srt/ass/ssa/vtt），有就直接 sub-add 启用，
     * 没有不处理。本地 file:// 查磁盘；http(s) 按扩展名 HEAD 探测
     * （带原 query 先试一次，不行再试不带 query 的公开直链）。
     * 注意：签名链接的 sign 通常绑定视频路径，拿它拼字幕路径会验签
     * 失败——此时探测自然返回不存在，不报错、不处理。
     */
    private fun maybeAutoExternalSub() {
        if (extSubChecked) return
        extSubChecked = true
        val input = currentMediaInput
        if (input.isEmpty()) return
        bg.execute {
            try {
                val subUrl = findSiblingSubtitle(input)
                if (subUrl == null) {
                    com.xiaohei.atvplayer.iso.IsoLog.i("auto sub probe: no sibling")
                    return@execute
                }
                runOnUiThread {
                    mountExternalSub(subUrl)
                    IsoLog.i("auto external sub: $subUrl")
                }
            } catch (e: Exception) {
                IsoLog.e("external sub probe failed", e)
            }
        }
    }

    /**
     * 字幕候选名：只精确同名（Movie.srt / .ass / .ssa / .vtt）。
     * 带语言小尾巴的（Movie.zh.srt 等）下不到，一律按不存在处理，不探测。
     */
    private fun subtitleCandidates(base: String, exts: List<String>): List<String> {
        return exts.map { "$base.$it" }
    }

    private fun findSiblingSubtitle(input: String): String? {
        val inner = SchemeActivity.unwrapSchemeUrl(input)
        // 入口就记：输入若不是 http(s)/file，远端分支根本进不去，之前这里是静默的
        com.xiaohei.atvplayer.iso.IsoLog.i("sub probe entry: ${inner.take(160)}")
        val exts = listOf("srt", "ass", "ssa", "vtt")
        if (inner.startsWith("file://") || inner.startsWith("/")) {
            val path = if (inner.startsWith("file://")) {
                try {
                    java.net.URI(inner).path
                } catch (_: Exception) {
                    // 中文等非 ASCII 的 file:// 同样会让 URI 抛异常，退回解码
                    java.net.URLDecoder.decode(inner.removePrefix("file://"), "UTF-8")
                }
            } else inner
            val dot = path.lastIndexOf('.')
            val slash = path.lastIndexOf('/')
            if (dot <= slash) return null
            val base = path.substring(0, dot)
            for (cand in subtitleCandidates(base, exts)) {
                val f = java.io.File(cand)
                if (f.isFile) return f.absolutePath
            }
            return null
        }
        if (!inner.startsWith("http://") && !inner.startsWith("https://")) return null
        val noQuery = inner.substringBefore('?')
        val query = inner.substringAfter('?', "")
        val dot = noQuery.lastIndexOf('.')
        val slash = noQuery.lastIndexOf('/')
        if (dot <= slash) return null
        val base = noQuery.substring(0, dot)
        val cands = subtitleCandidates(base, exts)
        com.xiaohei.atvplayer.iso.IsoLog.i("sub probe input: ${inner.take(160)}")
        for ((i, cand) in cands.withIndex()) {
            // 带原 query 只试精确同名（签名通常绑定视频路径，拼到字幕路径上
            // 必然验签失败，没必要每个小尾巴都带 query 试一遍）
            var hit: String? = null
            if (query.isNotEmpty() && i < exts.size
                && com.xiaohei.atvplayer.net.SignedUrl.exists("$cand?$query")) {
                hit = "$cand?$query"
            } else if (com.xiaohei.atvplayer.net.SignedUrl.exists(cand)) {
                hit = cand
            }
            com.xiaohei.atvplayer.iso.IsoLog.i("sub probe: ${cand.take(160)} -> ${hit != null}")
            if (hit != null) return hit
        }
        return null
    }

    /**
     * 挂载外挂字幕（本地和远端同一逻辑）：一律走本机代理——本地读成字节
     * 进会话，远端由代理代拉正文；mpv 永远只读 127.0.0.1，不落盘，
     * 绕开 mpv 自带 http 客户端的 UA/跳转/中文 URL 问题。
     */
    private fun mountExternalSub(cand: String) {
        try {
            val proxyUrl = if (cand.startsWith("http://") || cand.startsWith("https://")) {
                val ext = cand.substringBefore('?').substringAfterLast('.', "")
                    .ifEmpty { "srt" }
                getProxy().createSubUrl(cand, ext)
            } else {
                val bytes = java.io.File(cand).readBytes()
                val ext = cand.substringAfterLast('.', "").ifEmpty { "srt" }
                getProxy().createSubBytesUrl(bytes, ext)
            }
            mpv.command("sub-add", proxyUrl, "select", subtitleTitleFor(cand))
            mountedSubSource = cand
        } catch (_: Exception) { }
    }

    /** 外挂字幕在菜单里显示的名字：URL 取路径文件名，本地取文件名 */
    private fun subtitleTitleFor(cand: String): String {
        val name = if (cand.startsWith("http://") || cand.startsWith("https://")) {
            val raw = cand.substringBefore('?').substringAfterLast('/')
            try { java.net.URLDecoder.decode(raw, "UTF-8") } catch (_: Exception) { raw }
        } else {
            java.io.File(cand).name
        }
        return name.ifEmpty { "外挂字幕" }
    }

    /**
     * 外挂字幕按钮流程（与桌面版一致）：先探同名文件，有就直接挂载；
     * 没有才打开选文件框。已挂载过时再点 = 换一个，直接开选框
     * （避免把同一个同名字幕重复挂两次）。
     */
    private fun onExtSubButton() {
        com.xiaohei.atvplayer.iso.IsoLog.i("extSub btn: input=${currentMediaInput.take(160)} mounted=$mountedSubSource")
        if (currentMediaInput.isEmpty()) {
            pickSub.launch(arrayOf("*/*"))
            return
        }
        bg.execute {
            val subUrl = try { findSiblingSubtitle(currentMediaInput) } catch (_: Exception) { null }
            runOnUiThread {
                when {
                    subUrl == null -> pickSub.launch(arrayOf("*/*"))
                    subUrl == mountedSubSource ->
                        Toast.makeText(this, "同名字幕已挂载", Toast.LENGTH_SHORT).show()
                    else -> {
                        mountExternalSub(subUrl)
                        Toast.makeText(this, "已挂载同名字幕", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    private fun readTracks(type: String): List<Track> {
        val out = ArrayList<Track>()
        // 关闭选项（selected 在下面读完轨道后按“无轨道被选”回填）
        out.add(Track("no", type, "关闭"))
        val json = mpv.getPropertyString("track-list") ?: return out
        val arr = try { JSONArray(json) } catch (_: Exception) { return out }
        // 同类型计数（给 .clpi 语言按顺序补；外挂轨道不参与计数）
        var typedIndex = 0
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("type") != type) continue
            val id = o.optString("id")
            val title = o.optString("title", "")
            val codec = o.optString("codec", "")
            val tag = codecTag(codec)
            if (o.optBoolean("external", false)) {
                // 外挂字幕：显示文件名，不补 CLPI 语言（会错位）
                var name = title
                if (name.isEmpty() || name.startsWith("/proc/self/fd/")) {
                    name = o.optString("external-filename", "").substringAfterLast('/')
                }
                if (name.isEmpty()) name = "外挂字幕"
                val label = if (tag.isNotEmpty()) "$name [$tag]" else name
                out.add(Track(id, type, label, o.optBoolean("selected", false)))
                continue
            }
            var lang = o.optString("lang", "")
            if (lang.isEmpty() && isoLanguages.isNotEmpty()) {
                // 照抄 _iso_language_for_track：同类型第 typedIndex 条的语言
                val langs = isoLanguages.filter { it.first == kindFor(type) }.map { it.second }
                if (typedIndex < langs.size) lang = langs[typedIndex]
            }
            val name = when {
                title.isNotEmpty() -> title
                lang.isNotEmpty() -> displayLangName(lang) ?: lang
                else -> "轨道 $id"
            }
            val label = if (tag.isNotEmpty()) "$name [$tag]" else name
            out.add(Track(id, type, label, o.optBoolean("selected", false)))
            typedIndex++
        }
        if (out.none { it.selected }) {
            out[0] = out[0].copy(selected = true)
        }
        return out
    }

    private fun kindFor(type: String) = if (type == "audio") "audio" else "subtitle"

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) c.getString(i) else null
                } else null
            }
        } catch (_: Exception) { null }
    }

    private fun fmtTime(sec: Double): String {
        val s = sec.toInt().coerceAtLeast(0)
        return "%02d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
    }

    // 键盘：空格 播放/暂停，左右 ±10s，上下 音量
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_SPACE, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                mpv.playPause(); return true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> { mpv.seekRelative(-10.0); return true }
            KeyEvent.KEYCODE_DPAD_RIGHT -> { mpv.seekRelative(10.0); return true }
            KeyEvent.KEYCODE_DPAD_UP -> {
                val v = (mpv.getPropertyString("volume")?.toIntOrNull() ?: 100) + 5
                mpv.setVolume(v); return true
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                val v = (mpv.getPropertyString("volume")?.toIntOrNull() ?: 100) - 5
                mpv.setVolume(v); return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    /**
     * 控制条排版：横屏一行放全部（⏸ 音轨 字幕 🔊—滑杆 横/竖屏）；
     * 竖屏两行（按钮一行，音量独占一行拉满）。
     */
    /**
     * 控制条排版：所有按钮统一 48dp 高；
     * 横屏一行：按钮组放一起（⏸ 音轨 字幕 设置 竖屏），弹性空白把音量顶到最右边；
     * 竖屏两行：按钮一行，音量独占一行拉满。
     */
    /**
     * 控制条排版：所有按钮统一 48dp 高；
     * 横屏一行：按钮组放一起（⏸ 音轨 字幕 设置 竖屏），弹性空白把音量顶到最右边；
     * 竖屏三行：⏸ 音轨 字幕 / 设置 竖屏 / 🔊 音量滑杆（五键一行放不下）。
     */
    private fun applyControlLayout() {
        if (!::volumeBar.isInitialized) return
        val dp48 = (48 * resources.displayMetrics.density).toInt()
        fun btnLp() = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, dp48)
        btnRow.removeAllViews()
        btnRow2.removeAllViews()
        volRow.removeAllViews()
        if (btnRow2.parent != null) controls.removeView(btnRow2)
        if (volRow.parent != null) controls.removeView(volRow)
        playBtn.layoutParams = btnLp()
        audioBtn.layoutParams = btnLp()
        subBtn.layoutParams = btnLp()
        settingsBtn.layoutParams = btnLp()
        extSubBtn.layoutParams = btnLp()
        orientBtn.layoutParams = btnLp()
        btnRow.addView(playBtn)
        btnRow.addView(audioBtn)
        btnRow.addView(subBtn)
        if (portraitMode) {
            btnRow2.addView(settingsBtn)
            btnRow2.addView(orientBtn)
            btnRow2.addView(extSubBtn)
            controls.addView(btnRow2)
            volumeBar.layoutParams = LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            volRow.addView(volLabel)
            volRow.addView(volumeBar)
            controls.addView(volRow)
        } else {
            btnRow.addView(extSubBtn)
            btnRow.addView(settingsBtn)
            btnRow.addView(orientBtn)
            // 弹性空白：把音量组顶到最右边
            btnRow.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            volumeBar.layoutParams = LinearLayout.LayoutParams(
                (150 * resources.displayMetrics.density).toInt(),
                LinearLayout.LayoutParams.WRAP_CONTENT)
            btnRow.addView(volLabel)
            btnRow.addView(volumeBar)
        }
        orientBtn.text = if (portraitMode) "横屏" else "竖屏"
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        val isPortrait =
            newConfig.orientation == android.content.res.Configuration.ORIENTATION_PORTRAIT
        if (isPortrait != portraitMode) {
            portraitMode = isPortrait
            applyControlLayout()
        }
    }

    override fun onDestroy() {
        hideHandler.removeCallbacks(hideRunnable)
        try { contentPfd?.close() } catch (_: Exception) { }
        try { proxy?.close() } catch (_: Exception) { }
        try { mpv.destroy() } catch (_: Exception) { }
        bg.shutdownNow()
        super.onDestroy()
    }
}
