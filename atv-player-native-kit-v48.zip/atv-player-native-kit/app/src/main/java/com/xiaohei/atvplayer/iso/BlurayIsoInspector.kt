package com.xiaohei.atvplayer.iso

import java.io.Closeable
import java.net.URI

/**
 * Blu-ray ISO 检查器 —— 移植 bluray_iso.py 的 UDF 分支编排：
 *   prepare_iso_playback（UDF 分支）/ _prepare_remote_udf_playlist_playback
 *   / pick_main_feature_stream / 各 _looks_like_* 菜单过滤
 *   / _compute_trimmed_clip_range / _slice_cached_iso_stream_source
 *   / _build_trimmed_playlist_clip_source / _compose_cached_iso_stream_sources
 *
 * Python 有三条路径（远程 UDF / pycdlib 提升 / 纯 pycdlib）；Kotlin 的
 * UdfReader 直接实现 ECMA-167，只有一条 UDF 路径，等价于 Python 的
 * `_RemoteUdfIso` 分支。
 *
 * 常量照抄 bluray_iso.py:20-34。
 */
class BlurayIsoInspector {

    companion object {
        const val BLURAY_INDEX_PATH = "/BDMV/INDEX.BDMV"
        private val BLURAY_STREAM_RE = Regex("^/BDMV/STREAM/[^/]+\\.M2TS$")
        private const val SHORT_INTRO_MAX_DURATION_45K = 5L * 60 * 45000
        private const val SHORT_INTRO_MAX_TOTAL_DURATION_45K = 10L * 60 * 45000
        private const val MAIN_FEATURE_MIN_DURATION_45K = 15L * 60 * 45000
        private const val LOOPING_PLAYLIST_MIN_ITEMS = 20
        private const val LOOPING_PLAYLIST_REPEAT_RATIO = 0.8
        private const val SMALL_LOOPING_PLAYLIST_MIN_ITEMS = 3
        private const val SMALL_LOOPING_PLAYLIST_REPEAT_RATIO = 0.8
        private const val SMALL_LOOPING_PLAYLIST_MAX_UNIQUE_SIGNATURES = 2

        fun isRemoteIsoUrl(url: String): Boolean {
            return try {
                val uri = URI(url)
                (uri.scheme == "http" || uri.scheme == "https") &&
                    uri.host != null &&
                    (uri.path ?: "").lowercase().endsWith(".iso")
            } catch (_: Exception) { false }
        }

        fun pickMainFeatureStream(streams: List<BluRayIsoStream>): BluRayIsoStream {
            if (streams.isEmpty()) throw IllegalStateException("Blu-ray ISO 中没有可播放的 m2ts 文件")
            return streams.maxWith(compareBy({ it.size }, { it.path }))
        }
    }

    private val planCache = HashMap<String, IsoPlaybackPlan>()

    // reader 按 URL 缓存复用：此前 readRangeFromSource 每次新建 reader，
    // HttpRangeBlockReader 的窗口缓存/预取根本跨不了请求（流畅度大损）。
    private val readerCache = HashMap<String, BlockReader>()

    /** 外部 reader 注册（如 content:// 的 FdBlockReader），key 与 preparePlayback 的 url 一致 */
    fun registerReader(key: String, reader: BlockReader) {
        synchronized(readerCache) { readerCache[key] = reader }
    }

    fun closeReader(key: String) {
        val r = synchronized(readerCache) { readerCache.remove(key) }
        (r as? Closeable)?.let { try { it.close() } catch (_: Exception) { } }
    }

    /**
     * 解析 ISO（本地路径或远程 URL），返回播放计划。
     * 对应 prepare_iso_playback 的 _RemoteUdfIso 分支。
     */
    @Synchronized
    fun preparePlayback(url: String, headers: Map<String, String>): IsoPlaybackPlan {
        planCache[url]?.let { IsoLog.i("preparePlayback cache hit: $url"); return it }
        IsoLog.i("preparePlayback: $url")
        val reader = makeReader(url, headers)
        val udf = UdfReader(reader)
        udf.open()
        IsoLog.i("preparePlayback: udf open ok")
        val plan = prepareUdfPlayback(udf)
        planCache[url] = plan
        return plan
    }

    private fun makeReader(url: String, headers: Map<String, String>): BlockReader {
        synchronized(readerCache) { readerCache[url]?.let { return it } }
        val r = if (url.startsWith("file://") || url.startsWith("/")) {
            val path = if (url.startsWith("file://")) URI(url).path else url
            FileBlockReader(path)
        } else {
            HttpRangeBlockReader(url, headers)
        }
        synchronized(readerCache) { readerCache[url] = r }
        return r
    }

    private fun prepareUdfPlayback(udf: UdfReader): IsoPlaybackPlan {
        // 先走 playlist（正片 playlist 拼 m2ts），失败回落到最大 m2ts
        preparePlaylistPlayback(udf)?.let { return it }
        val streams = udf.statStreams()
        IsoLog.i("fallback plan: ${streams.size} streams")
        val selected = pickMainFeatureStream(streams)
        val entry = udf.findEntry(selected.path)
        val languages = readStreamLanguages(udf, selected.path)
        return IsoPlaybackPlan(
            stream = selected,
            source = udf.buildStreamSource(entry),
            streamLanguages = languages,
        )
    }

    private fun preparePlaylistPlayback(udf: UdfReader): IsoPlaybackPlan? {
        val candidates = ArrayList<ParsedMplsPlaylist>()
        val playlists = try { udf.iterPlaylists() } catch (e: Exception) {
            IsoLog.e("iterPlaylists failed", e)
            return null
        }
        IsoLog.i("iterPlaylists: ${playlists.size} files")
        for ((path, data) in playlists) {
            val parsed = try { MplsParser.parse(path, data) } catch (_: Exception) { continue }
            if (looksLikeLoopingPlaylist(parsed)) continue
            if (looksLikeSameStreamOverlappingPlaylist(parsed.playItems)) continue
            candidates.add(parsed)
        }
        val sourceCache = HashMap<String, CachedIsoStreamSource>()
        // 按 payload 大小、时长、路径倒序（对应 Python 的 sorted(reverse=True)）
        val sorted = candidates.sortedWith(
            compareByDescending<ParsedMplsPlaylist> {
                estimatePlaylistPayloadSize(udf, trimLeadingIntroPlayItems(it.playItems), sourceCache)
            }.thenByDescending { it.duration }.thenByDescending { it.path }
        )
        for (parsed in sorted) {
            val selectedItems = trimLeadingIntroPlayItems(parsed.playItems)
            val childSources = try {
                selectedItems.map { buildTrimmedPlaylistClipSource(udf, it) }
            } catch (_: Exception) { continue }
            if (looksLikeRepeatedTrimmedSegmentLoop(selectedItems, childSources)) continue
            val selectedSource = composeStreamSources(childSources)
            val selectedPath = selectedItems[0].streamPath
            val segments = if (selectedItems.size > 1) {
                selectedItems.zip(childSources).map { (item, src) ->
                    IsoPlaybackSegment(
                        streamPath = item.streamPath,
                        streamSize = src.size,
                        durationSeconds = if (item.duration > 0) item.duration / 45000.0 else 0.0,
                        source = src,
                    )
                }
            } else emptyList()
            val languages = readStreamLanguages(udf, selectedPath)
            return IsoPlaybackPlan(
                stream = BluRayIsoStream(selectedPath, selectedSource.size),
                source = selectedSource,
                playlistSegments = segments,
                streamLanguages = languages,
            )
        }
        return null
    }

    private fun estimatePlaylistPayloadSize(
        udf: UdfReader,
        playItems: List<MplsPlayItem>,
        sourceCache: MutableMap<String, CachedIsoStreamSource>,
    ): Long {
        var total = 0L
        val counted = HashSet<String>()
        for (item in playItems) {
            if (!counted.add(item.streamPath)) continue
            val src = sourceCache.getOrPut(item.streamPath) {
                udf.buildStreamSource(udf.findEntry(item.streamPath))
            }
            total += src.size
        }
        return total
    }

    private fun trimLeadingIntroPlayItems(items: List<MplsPlayItem>): List<MplsPlayItem> {
        if (items.size < 2) return items
        val firstMain = items.indexOfFirst { it.duration >= MAIN_FEATURE_MIN_DURATION_45K }
        if (firstMain <= 0) return items
        val leading = items.subList(0, firstMain)
        if (leading.any { it.duration > SHORT_INTRO_MAX_DURATION_45K }) return items
        if (leading.sumOf { it.duration } > SHORT_INTRO_MAX_TOTAL_DURATION_45K) return items
        return items.subList(firstMain, items.size)
    }

    private fun looksLikeLoopingPlaylist(parsed: ParsedMplsPlaylist): Boolean {
        val counts = parsed.playItems.groupingBy {
            Triple(it.clipId, it.inTime, it.outTime)
        }.eachCount()
        if (counts.isEmpty()) return false
        val maxCount = counts.values.max()
        val repeatRatio = maxCount.toDouble() / parsed.playItems.size
        if (parsed.playItems.size >= LOOPING_PLAYLIST_MIN_ITEMS) {
            return repeatRatio >= LOOPING_PLAYLIST_REPEAT_RATIO
        }
        if (parsed.playItems.size < SMALL_LOOPING_PLAYLIST_MIN_ITEMS) return false
        return repeatRatio >= SMALL_LOOPING_PLAYLIST_REPEAT_RATIO &&
            counts.size <= SMALL_LOOPING_PLAYLIST_MAX_UNIQUE_SIGNATURES
    }

    private fun looksLikeSameStreamOverlappingPlaylist(items: List<MplsPlayItem>): Boolean {
        if (items.size < SMALL_LOOPING_PLAYLIST_MIN_ITEMS) return false
        if (items.map { it.streamPath }.toSet().size != 1) return false
        val intervals = items.mapNotNull { item ->
            if (item.outTime > item.inTime) item.inTime to item.outTime else null
        }.sortedBy { it.first }
        if (intervals.size < SMALL_LOOPING_PLAYLIST_MIN_ITEMS) return false
        val totalDuration = intervals.sumOf { it.second - it.first }
        if (totalDuration <= 0) return false
        var merged = 0L
        var curStart = intervals[0].first
        var curEnd = intervals[0].second
        for (i in 1 until intervals.size) {
            val (s, e) = intervals[i]
            if (s <= curEnd) curEnd = maxOf(curEnd, e)
            else { merged += curEnd - curStart; curStart = s; curEnd = e }
        }
        merged += curEnd - curStart
        return merged.toDouble() / totalDuration <= 0.6
    }

    private fun looksLikeRepeatedTrimmedSegmentLoop(
        items: List<MplsPlayItem>,
        childSources: List<CachedIsoStreamSource>,
    ): Boolean {
        if (items.size < SMALL_LOOPING_PLAYLIST_MIN_ITEMS || items.size != childSources.size) return false
        val counts = items.zip(childSources).groupingBy { (item, src) ->
            item.streamPath to src.size
        }.eachCount()
        if (counts.isEmpty()) return false
        val maxCount = counts.values.max()
        return maxCount.toDouble() / items.size >= SMALL_LOOPING_PLAYLIST_REPEAT_RATIO &&
            counts.size <= SMALL_LOOPING_PLAYLIST_MAX_UNIQUE_SIGNATURES
    }

    /**
     * 用 .clpi 的 EP map 把 play item 的 in/out_time 裁成字节区间
     *（对应 _build_trimmed_playlist_clip_source + _compute_trimmed_clip_range，
     * 192 字节 m2ts 包对齐）。
     */
    private fun buildTrimmedPlaylistClipSource(udf: UdfReader, playItem: MplsPlayItem): CachedIsoStreamSource {
        val clipEntry = udf.findEntry(playItem.streamPath)
        val clipSource = udf.buildStreamSource(clipEntry)
        val parsedClpi = udf.readClipInfo(playItem.clipId)
        val (start, endExclusive) = computeTrimmedClipRange(
            parsedClpi, playItem.inTime, playItem.outTime, clipSource.size
        )
        return sliceStreamSource(clipSource, start, endExclusive - start)
    }

    private fun computeTrimmedClipRange(
        parsedClpi: ParsedClpi, inTime: Long, outTime: Long, streamSize: Long,
    ): Pair<Long, Long> {
        if (streamSize <= 0) throw IllegalStateException("Blu-ray clip 大小无效")
        val startPoint = parsedClpi.entryPoints.lastOrNull { it.time45k <= inTime }
        val endPoint = parsedClpi.entryPoints.firstOrNull { it.time45k > outTime }
        val start = ((startPoint?.byteOffset ?: 0) / 192) * 192
        var endExclusive = endPoint?.let { ((it.byteOffset + 191) / 192) * 192 } ?: streamSize
        endExclusive = minOf(streamSize, endExclusive)
        if (endExclusive <= start) throw IllegalStateException("Blu-ray clip 裁剪区间无效")
        return start to endExclusive
    }

    private fun sliceStreamSource(
        source: CachedIsoStreamSource, start: Long, length: Long,
    ): CachedIsoStreamSource {
        if (start < 0 || length <= 0 || start + length > source.size) {
            throw IllegalStateException("Blu-ray clip 裁剪区间超出边界")
        }
        val endExclusive = start + length
        val segments = ArrayList<CachedIsoSegment>()
        var logicalOffset = 0L
        for (seg in source.segments) {
            val segStart = seg.logicalOffset
            val segEnd = seg.logicalOffset + seg.length
            if (segEnd <= start) continue
            if (segStart >= endExclusive) break
            val localStart = maxOf(start, segStart)
            val localEnd = minOf(endExclusive, segEnd)
            segments.add(
                CachedIsoSegment(
                    logicalOffset = logicalOffset,
                    length = localEnd - localStart,
                    physicalStart = seg.physicalStart + (localStart - segStart),
                )
            )
            logicalOffset += localEnd - localStart
        }
        if (logicalOffset != length || segments.isEmpty()) {
            throw IllegalStateException("Blu-ray clip 裁剪区间无法映射到底层分段")
        }
        return CachedIsoStreamSource(size = length, segments = segments)
    }

    private fun composeStreamSources(sources: List<CachedIsoStreamSource>): CachedIsoStreamSource {
        val segments = ArrayList<CachedIsoSegment>()
        var logicalOffset = 0L
        for (src in sources) {
            for (seg in src.segments) {
                segments.add(seg.copy(logicalOffset = logicalOffset + seg.logicalOffset))
            }
            logicalOffset += src.size
        }
        if (logicalOffset <= 0 || segments.isEmpty()) {
            throw IllegalStateException("Blu-ray ISO 中没有可播放的 m2ts 文件")
        }
        return CachedIsoStreamSource(size = logicalOffset, segments = segments)
    }

    /**
     * 读 .clpi ProgramInfo 语言（v8 补丁的 _read_iso_stream_languages）。
     * playlist 模式取第一个 play item 的 clip。
     */
    private fun readStreamLanguages(udf: UdfReader, streamPath: String): List<Pair<String, String>> {
        return try {
            val clipId = streamPath.substringAfterLast("/").substringBefore(".")
            val data = udf.readWholeFile("/BDMV/CLIPINF/$clipId.CLPI")
            ClpiParser.parseProgramLanguages(data)
        } catch (_: Exception) { emptyList() }
    }

    /**
     * 从 source 读逻辑 [start, end]（闭区间），返回 (bytes, total)。
     * 对应 read_iso_stream_range_from_source（bluray_iso.py:1497）。
     */
    /**
     * 起播预读：先把逻辑流开头 bytes 字节拉进窗口缓存再让 mpv 起播
     * （数据读完即弃，只为填充缓存）。仅远程 Range reader 有意义，
     * 本地 file/fd reader 读速快，直接跳过。须在后台线程调用。
     */
    fun warmup(url: String, headers: Map<String, String>, source: CachedIsoStreamSource, bytes: Long) {
        val reader = makeReader(url, headers)
        if (reader !is HttpRangeBlockReader) return
        try {
            var off = 0L
            val target = minOf(bytes, source.size)
            while (off < target) {
                val end = minOf(off + 8L * 1024 * 1024 - 1, target - 1)
                readRangeFromSource(url, headers, source, off, end)
                off = end + 1
            }
            IsoLog.i("warmup done: ${target}B")
        } catch (e: Exception) {
            IsoLog.e("warmup failed", e)
        }
    }

    fun readRangeFromSource(
        url: String, headers: Map<String, String>,
        source: CachedIsoStreamSource, start: Long, end: Long?,
    ): Pair<ByteArray, Long> {
        val total = source.size
        if (total <= 0) throw IllegalStateException("Blu-ray ISO 中没有可播放的 m2ts 文件")
        if (start < 0 || start >= total) return ByteArray(0) to total
        val inclusiveEnd = minOf(end ?: (total - 1), total - 1)
        if (inclusiveEnd < start) return ByteArray(0) to total
        // embedded：数据内嵌，直接切片
        source.embeddedData?.let { emb ->
            val s = start.coerceIn(0, emb.size.toLong()).toInt()
            val e = minOf(inclusiveEnd, emb.size - 1L).toInt()
            if (e < s) return ByteArray(0) to total
            return emb.copyOfRange(s, e + 1) to total
        }
        val reader = makeReader(url, headers)
        val chunks = ArrayList<ByteArray>()
        for ((physStart, physLen, _) in source.mapRange(start, inclusiveEnd)) {
            chunks.add(reader.readBytes(physStart, physLen.toInt()))
        }
        var n = 0
        chunks.forEach { n += it.size }
        val out = ByteArray(n)
        var o = 0
        chunks.forEach { it.copyInto(out, o); o += it.size }
        return out to total
    }
}
