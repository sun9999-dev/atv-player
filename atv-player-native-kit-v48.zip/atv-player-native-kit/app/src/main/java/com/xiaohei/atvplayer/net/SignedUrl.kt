package com.xiaohei.atvplayer.net

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.net.URI
import java.util.concurrent.TimeUnit

/**
 * 通用签名链接 GET —— 完整移植 desktop 的 `_signed_url_get`
 *（standalone_player_atv_windows.py:57-184）。
 *
 * 行为（必须一字不差）：
 * 1. 手动跟重定向（最多 11 跳），OkHttp 的 followRedirects 关掉：
 *    - 同 host：把原 URL 的查询串合并进重定向目标（目标自带参数优先）；
 *    - 跨 host（源站 -> CDN/存储）：目标原样用，签名按 host 隔离，合并会让
 *      目标签名校验失败；同时清空 original_query。
 * 2. 默认头：浏览器 User-Agent；无 Referer 时用 URL 自身 Origin 作 Referer。
 * 3. Range 扩包：调用方要的小 Range（<1MB）扩到 1MB 再发（有些 CDN 对
 *    tiny Range 回 200 不回 206）；若服务端回 206，把 body 裁回原 Range，
 *    重写 Content-Range / Content-Length 为 206（**删掉旧的两个头再写**，
 *    否则新旧并存拼成 "a, b"，调用方按扩包后的 1048576 等 body 会报
 *    "peer closed connection (received 0 bytes, expected 1048576)"——
 *    这是 desktop 修过的真 bug，不要回退）。
 * 4. 流式：服务端回 200（忽略 Range）时不读 body，避免整文件进内存；
 *    调用方见非 206 会按 Range 不支持处理。
 *
 * 返回：SimpleResponse(status, headers, body)。body 只在 206（或调用方
 * 明确不要 Range 的小请求）时有内容。
 */
object SignedUrl {

    private val BROWSER_UA =
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

    private val client: OkHttpClient = OkHttpClient.Builder()
        .followRedirects(false)   // 手动跟（要合并 query）
        .followSslRedirects(false)
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    // 存在性验证的 plain GET 客户端：自动跟跳转，与代理拉字幕同一路子
    private val plainClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .followRedirects(true)
            .followSslRedirects(true)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()
    }

    /**
     * 存在性验证的最后手段：与 curl / 代理拉字幕完全一致的 plain GET
     *（只带 UA，不扩 Range、不带 Referer、自动跟跳转），只看状态码不读 body。
     * 专门对付 SignedUrl.get 的 Range 扩包（0-0 → 0-1048575，小文件上简易
     * 服务器回 416）以及 Referer 被拒的情况。
     */
    private fun plainGetOk(url: String): Boolean {
        return try {
            val req = Request.Builder().url(url)
                .header("User-Agent", BROWSER_UA)
                .build()
            plainClient.newCall(req).execute().use { resp ->
                android.util.Log.i("atviso", "sub plainGET: ${url.take(120)} -> ${resp.code}")
                resp.code == 200 || resp.code == 206
            }
        } catch (e: Exception) {
            android.util.Log.i("atviso", "sub plainGET fail: ${url.take(120)} err=${e.message}")
            false
        }
    }

    data class SimpleResponse(
        val status: Int,
        val headers: Map<String, String>,
        val body: ByteArray,
    )

    private val RANGE_RE = Regex("""bytes=(\d+)-(\d*)""")
    private val CONTENT_RANGE_RE = Regex("""bytes\s+\d+-\d+/(\d+)""", RegexOption.IGNORE_CASE)

    fun get(url: String, headers: Map<String, String>? = null, timeoutSec: Long = 15): SimpleResponse {
        val reqHeaders = HashMap(headers ?: emptyMap())
        reqHeaders.putIfAbsent("User-Agent", BROWSER_UA)
        if (!reqHeaders.keys.any { it.equals("Referer", ignoreCase = true) }) {
            try {
                val uri = safeUri(url)
                if (uri != null && uri.scheme != null && uri.host != null) {
                    reqHeaders["Referer"] = "${uri.scheme}://${uri.host}/"
                }
            } catch (_: Exception) { /* ignore */ }
        }

        // 调用方要的 Range；小 Range 扩到 1MB
        var origStart: Long? = null
        var origEnd: Long? = null
        var expanded = false
        val rangeHeader = reqHeaders.entries.firstOrNull {
            it.key.equals("Range", ignoreCase = true)
        }?.value?.trim() ?: ""
        RANGE_RE.matchEntire(rangeHeader)?.let { m ->
            val s = m.groupValues[1].toLong()
            val e = m.groupValues[2].takeIf { it.isNotEmpty() }?.toLong()
            origStart = s
            origEnd = e
            if (e != null && (e - s + 1) < 1024 * 1024) {
                reqHeaders["Range"] = "bytes=$s-${s + 1024 * 1024 - 1}"
                expanded = true
            }
        }

        var originalQuery: Map<String, String> = parseQuery(safeUri(url)?.rawQuery)
        var currentUrl = url
        repeat(11) {
            val (status, respHeaders, body) = fetchOnce(
                currentUrl, reqHeaders,
                if (expanded) Pair(origStart!!, origEnd) else null,
            )
            if (status !in listOf(301, 302, 303, 307, 308)) {
                return SimpleResponse(status, respHeaders, body)
            }
            val location = respHeaders.entries.firstOrNull {
                it.key.equals("Location", ignoreCase = true)
            }?.value ?: return SimpleResponse(status, respHeaders, body)
            val target = safeUri(currentUrl)?.resolve(location)?.toString()
                ?: return SimpleResponse(status, respHeaders, body)
            if (safeUri(target)?.host == safeUri(currentUrl)?.host) {
                val targetQuery = parseQuery(safeUri(target)?.rawQuery)
                val merged = HashMap(originalQuery)
                merged.putAll(targetQuery)   // 目标自带参数优先
                currentUrl = setQuery(target, merged)
            } else {
                currentUrl = target
                originalQuery = emptyMap()
            }
        }
        val (status, respHeaders, body) = fetchOnce(
            currentUrl, reqHeaders,
            if (expanded) Pair(origStart!!, origEnd) else null,
        )
        return SimpleResponse(status, respHeaders, body)
    }

    /**
     * java.net.URI 遇中文/空格等非 ASCII 直接抛异常，导致 exists/get 对中文
     * 文件名 URL 全灭（外层 catch 吃掉后返回不存在/失败；本地查磁盘不走
     * URI，所以本地字幕行、URL 字幕不行）。先按 UTF-8 百分比编码再解析；
     * 已编码的 %XX 不动（% 是 ASCII），不会二次编码。
     */
    private fun encodeNonAscii(url: String): String {
        val sb = StringBuilder(url.length)
        for (ch in url) {
            if (ch.code < 128) sb.append(ch) else {
                for (b in ch.toString().toByteArray(Charsets.UTF_8)) {
                    sb.append('%')
                    sb.append(String.format("%02X", b))
                }
            }
        }
        return sb.toString()
    }

    private fun safeUri(url: String): java.net.URI? {
        return try {
            java.net.URI(url)
        } catch (_: Exception) {
            try { java.net.URI(encodeNonAscii(url)) } catch (_: Exception) { null }
        }
    }

    /** 单次 HEAD（不跟重定向）。返回 (status, headers)。 */
    private fun headOnce(
        url: String, headers: Map<String, String>,
    ): Pair<Int, Map<String, String>> {
        val builder = Request.Builder().url(url).head()
        headers.forEach { (k, v) -> builder.header(k, v) }
        return client.newCall(builder.build()).execute().use { resp ->
            val h = HashMap<String, String>()
            resp.headers.forEach { (k, v) -> h.putIfAbsent(k, v) }
            resp.code to h
        }
    }

    /**
     * 探测 URL 是否存在（外挂字幕同名探测用）：HEAD + 手动跟重定向
     * （与 get() 同款同 host query 合并规则），不读 body。
     * 405（不支持 HEAD）时回落到 Range 0-0 的 GET。
     * true 当且仅当最终状态为 200/206。
     */
    fun exists(url: String): Boolean {
        return try {
            val reqHeaders = HashMap<String, String>()
            reqHeaders["User-Agent"] = BROWSER_UA
            try {
                val uri = safeUri(url)
                if (uri != null && uri.scheme != null && uri.host != null) {
                    reqHeaders["Referer"] = "${uri.scheme}://${uri.host}/"
                }
            } catch (_: Exception) { }
            var originalQuery = parseQuery(safeUri(url)?.rawQuery)
            var currentUrl = url
            repeat(11) {
                val t0 = System.currentTimeMillis()
                val (status, respHeaders) = try {
                    headOnce(currentUrl, reqHeaders)
                } catch (e: Exception) {
                    android.util.Log.i("atviso", "sub HEAD fail: ${currentUrl.take(120)} err=${e.message} ${System.currentTimeMillis() - t0}ms")
                    // HEAD 抛异常也不直接放弃，走一次 plain GET 再定
                    return plainGetOk(currentUrl)
                }
                android.util.Log.i("atviso", "sub HEAD: ${currentUrl.take(120)} -> $status ${System.currentTimeMillis() - t0}ms")
                if (status !in listOf(200, 206, 301, 302, 303, 307, 308)) {
                    // HEAD 被拒/不支持时用 plain GET 再验证一次：不走 SignedUrl.get
                    //（它的 Range 扩包和 Referer 在简易服务器上会失败）；GET 404
                    // 仍返回 false，不会把不存在的文件误判为存在
                    return plainGetOk(currentUrl)
                }
                if (status !in listOf(301, 302, 303, 307, 308)) {
                    return status == 200 || status == 206
                }
                val location = respHeaders.entries.firstOrNull {
                    it.key.equals("Location", ignoreCase = true)
                }?.value ?: return false
                val target = safeUri(currentUrl)?.resolve(location)?.toString()
                    ?: return false
                if (safeUri(target)?.host == safeUri(currentUrl)?.host) {
                    val targetQuery = parseQuery(safeUri(target)?.rawQuery)
                    val merged = HashMap(originalQuery)
                    merged.putAll(targetQuery)   // 目标自带参数优先
                    currentUrl = setQuery(target, merged)
                } else {
                    currentUrl = target
                    originalQuery = emptyMap()
                }
            }
            false
        } catch (_: Exception) {
            false
        }
    }

    /** 单次 GET（不跟重定向）。返回 (status, headers, body)。 */
    private fun fetchOnce(
        url: String,
        headers: Map<String, String>,
        expandedRange: Pair<Long, Long?>?,
    ): Triple<Int, Map<String, String>, ByteArray> {
        val builder = Request.Builder().url(url)
        headers.forEach { (k, v) -> builder.header(k, v) }
        client.newCall(builder.build()).execute().use { resp ->
            val status = resp.code
            val respHeaders = HashMap<String, String>()
            resp.headers.forEach { (k, v) -> respHeaders.putIfAbsent(k, v) }
            if (status in listOf(301, 302, 303, 307, 308)) {
                return Triple(status, respHeaders, ByteArray(0))
            }
            if (status == 206 && expandedRange != null) {
                val (origStart, origEnd) = expandedRange
                val body = resp.body?.bytes() ?: ByteArray(0)
                val cr = respHeaders.entries.firstOrNull {
                    it.key.equals("Content-Range", ignoreCase = true)
                }?.value ?: ""
                val total = CONTENT_RANGE_RE.find(cr)?.groupValues?.get(1)
                val sliced = if (origEnd != null) {
                    body.copyOf(minOf(body.size, (origEnd - origStart + 1).toInt()))
                } else body
                // 关键：先删旧的 content-range / content-length（忽略大小写），再写新的
                val newHeaders = respHeaders.filterKeys {
                    !it.equals("content-range", ignoreCase = true) &&
                        !it.equals("content-length", ignoreCase = true)
                }.toMutableMap()
                if (total != null) {
                    newHeaders["Content-Range"] =
                        "bytes $origStart-${origStart + sliced.size - 1}/$total"
                } else if (cr.isNotEmpty()) {
                    newHeaders["Content-Range"] = cr
                }
                newHeaders["Content-Length"] = sliced.size.toString()
                return Triple(206, newHeaders, sliced)
            }
            if (status == 206) {
                return Triple(status, respHeaders, resp.body?.bytes() ?: ByteArray(0))
            }
            // 200（忽略 Range）/ 错误：不读 body
            return Triple(status, respHeaders, ByteArray(0))
        }
    }

    private fun parseQuery(rawQuery: String?): Map<String, String> {
        if (rawQuery.isNullOrEmpty()) return emptyMap()
        return rawQuery.split("&").mapNotNull { part ->
            val i = part.indexOf('=')
            if (i < 0) null else part.substring(0, i) to part.substring(i + 1)
        }.toMap()
    }

    private fun setQuery(url: String, query: Map<String, String>): String {
        val uri = URI(url)
        val q = query.entries.joinToString("&") { (k, v) -> "$k=$v" }
        return URI(uri.scheme, uri.authority, uri.path, q.ifEmpty { null }, uri.fragment).toString()
    }
}
