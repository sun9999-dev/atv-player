package com.xiaohei.atvplayer.net

import java.io.File
import java.io.RandomAccessFile

/**
 * 本地文件 GET —— 移植 desktop 的 `_local_file_get`
 *（standalone_player_atv_windows.py:330-362）。
 *
 * BlurayIsoInspector / 代理只用它定位文件：URL 是 content://（SAF，先拷到
 * cache）或 /storage/... 真实路径；这里统一按本地路径读，支持 Range，
 * 无 Range 时返回整文件（本地读整文件是安全的，不像远程）。
 */
object LocalFileGet {

    fun get(path: String, headers: Map<String, String>? = null): SignedUrl.SimpleResponse {
        val file = File(path)
        if (!file.isFile) throw java.io.FileNotFoundException("本地文件不存在：$path")
        val total = file.length()
        val rangeHeader = headers?.entries?.firstOrNull {
            it.key.equals("Range", ignoreCase = true)
        }?.value?.trim() ?: ""
        val m = Regex("""bytes=(\d+)-(\d*)""").matchEntire(rangeHeader)
        val (start, end) = if (m != null) {
            val s = m.groupValues[1].toLong()
            var e = m.groupValues[2].takeIf { it.isNotEmpty() }?.toLong() ?: (total - 1)
            e = minOf(e, total - 1)
            s to e
        } else {
            0L to total - 1
        }
        if (start < 0 || start > end || start >= total) {
            return SignedUrl.SimpleResponse(
                416, mapOf("Content-Range" to "bytes */$total"), ByteArray(0)
            )
        }
        val len = (end - start + 1).toInt()
        val buf = ByteArray(len)
        RandomAccessFile(file, "r").use { raf ->
            raf.seek(start)
            var off = 0
            while (off < len) {
                val n = raf.read(buf, off, len - off)
                if (n < 0) break
                off += n
            }
        }
        return SignedUrl.SimpleResponse(
            206,
            mapOf(
                "Content-Range" to "bytes $start-$end/$total",
                "Content-Length" to len.toString(),
            ),
            buf,
        )
    }
}
