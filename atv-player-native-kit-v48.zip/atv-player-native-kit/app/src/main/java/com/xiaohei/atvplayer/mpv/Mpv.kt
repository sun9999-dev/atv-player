package com.xiaohei.atvplayer.mpv

import android.os.Handler
import android.os.Looper

/**
 * libmpv 的薄 Kotlin 封装（对应 JNI mpv_jni.c）。
 *
 * 线程：command/setProperty 可在任意线程调（mpv 内部线程安全）；
 * 事件回调切到主线程；render 只在 GL 线程调。
 */
class Mpv {

    interface EventCallback {
        fun onEvent(name: String, data: String)
        fun onRenderUpdate()
    }

    // JNI 持有的 native 上下文指针（mpv_jni.c 读写）
    @Suppress("unused")
    private var nativeCtx: Long = 0

    private val mainHandler = Handler(Looper.getMainLooper())
    var eventCallback: EventCallback? = null
    /** 渲染更新（高频）：GLSurfaceView.requestRender，线程安全，直接调 */
    var renderUpdateListener: (() -> Unit)? = null

    private val jniCallback = object : EventCallback {
        override fun onEvent(name: String, data: String) {
            mainHandler.post { eventCallback?.onEvent(name, data) }
        }
        override fun onRenderUpdate() {
            renderUpdateListener?.invoke()
        }
    }

    init {
        // 先加载 libmpv，再加载胶水（胶水链了 libmpv 的符号）
        System.loadLibrary("mpv")
        System.loadLibrary("atvplayer_jni")
    }

    /** 返回 0 成功 */
    fun create(caPath: String? = null, cacheMiB: Int = 128, backCacheMiB: Int = 32): Int {
        nativeCreate(jniCallback, caPath, cacheMiB, backCacheMiB)
        return nativeInit()
    }

    fun command(vararg args: String) = nativeCommand(arrayOf(*args))
    fun setProperty(name: String, value: String?) = nativeSetPropertyString(name, value)
    fun getPropertyString(name: String): String? = nativeGetPropertyString(name)
    fun observeProperty(name: String) = nativeObserveProperty(name)

    /** 在 GL 线程（surface 已创建后）调用一次 */
    fun initRender(): Int = nativeRenderInit()
    /** 每帧：GLSurfaceView.Renderer.onDrawFrame 里调 */
    fun render(w: Int, h: Int) {
        nativeRender(w, h)
        nativeReportSwap()
    }

    fun destroy() = nativeDestroy()

    // ---- 常用便捷操作（对照 desktop mpv_widget.py 的行为）----
    fun loadFile(url: String) = command("loadfile", url, "replace")
    fun playPause() = command("cycle", "pause")
    fun seek(seconds: Double) = command("seek", seconds.toString(), "absolute")
    fun seekRelative(seconds: Double) = command("seek", seconds.toString(), "relative")
    fun setAid(id: String) = setProperty("aid", id)          // 音轨：track id / "no"
    fun setSid(id: String) = setProperty("sid", id)          // 字幕：track id / "no"
    fun setSpeed(v: Double) = setProperty("speed", v.toString())
    fun setVolume(v: Int) = setProperty("volume", v.coerceIn(0, 100).toString())

    private external fun nativeCreate(callback: EventCallback, caPath: String?, cacheMiB: Int, backCacheMiB: Int)
    private external fun nativeInit(): Int
    private external fun nativeCommand(args: Array<String>)
    private external fun nativeSetPropertyString(name: String, value: String?)
    private external fun nativeGetPropertyString(name: String): String?
    private external fun nativeObserveProperty(name: String)
    private external fun nativeRenderInit(): Int
    private external fun nativeRender(w: Int, h: Int)
    private external fun nativeReportSwap()
    private external fun nativeDestroy()
}
