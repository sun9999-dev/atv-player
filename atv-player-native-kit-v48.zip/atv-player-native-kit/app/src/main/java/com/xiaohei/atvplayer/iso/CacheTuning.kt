package com.xiaohei.atvplayer.iso

/**
 * 按设备总内存分档的缓存参数（PlayerActivity 启动时 applyForDevice 一次）。
 * 窗口缓存走 Java 堆、mpv demuxer 缓存走原生堆，分开配：
 * 两级合计约兜 10-20 秒 UHD 峰值码率即可，再大只挤系统内存招杀进程。
 */
object CacheTuning {
    @Volatile var maxWindows: Int = 12          // 8MB/窗口
    @Volatile var mpvCacheMiB: Int = 128
    @Volatile var mpvBackCacheMiB: Int = 32
    @Volatile var preRollMiB: Int = 32          // 起播前预读的逻辑流字节数（远程 ISO）

    fun applyForDevice(totalMemBytes: Long) {
        val gib = totalMemBytes / (1024.0 * 1024 * 1024)
        when {
            gib < 3.5 -> { maxWindows = 4; mpvCacheMiB = 64; mpvBackCacheMiB = 16; preRollMiB = 16 }
            gib < 5.5 -> { maxWindows = 8; mpvCacheMiB = 96; mpvBackCacheMiB = 24; preRollMiB = 24 }   // 4GB
            gib < 7.5 -> { maxWindows = 12; mpvCacheMiB = 128; mpvBackCacheMiB = 32; preRollMiB = 32 } // 6GB
            else -> { maxWindows = 16; mpvCacheMiB = 192; mpvBackCacheMiB = 48; preRollMiB = 48 }       // ≥8GB
        }
        IsoLog.i("CacheTuning: totalMem=${"%.1f".format(gib)}GiB windows=$maxWindows " +
            "mpvCache=${mpvCacheMiB}MiB back=${mpvBackCacheMiB}MiB preRoll=${preRollMiB}MiB")
    }
}
