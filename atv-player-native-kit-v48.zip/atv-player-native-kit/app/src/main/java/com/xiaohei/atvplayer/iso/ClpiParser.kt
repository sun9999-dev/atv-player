package com.xiaohei.atvplayer.iso

import com.xiaohei.atvplayer.iso.MplsParser.readU16BE
import com.xiaohei.atvplayer.iso.MplsParser.readU32BE
import com.xiaohei.atvplayer.iso.MplsParser.normalizeIsoPath

/**
 * CLPI 解析 —— 完整移植（bluray_iso.py:1016-1111 + v8 补丁的
 * `_parse_clpi_program_languages` / `_clpi_coding_type_kind`）：
 *
 * 1. entry points（EP map）：`_parse_clpi_entry_points` —— 给 playlist
 *    按 in/out_time 裁剪 clip 用（`_compute_trimmed_clip_range`）：
 *    - 文件头 "HDMV"；sequence_start = u32be(data, 8)；cpi_start = u32be(data, 16)
 *    - primary_stream_pid：sequence 区第一个 ATC 的第一个 STC 的 stream_pid
 *    - EP map：cpi_start+4 的低 4 位 == 1（EP_map 类型）；stream 条目 12 字节：
 *      pid(2) + coarse/fine 计数 + ep_map_start(4, 相对 ep_map_table_base)
 *      只取 stream_index==0 或 pid==primary 的流；coarse 表 8 字节/项，
 *      fine 表 4 字节/项；
 *      time_45k = ((coarse & 0x3FFE) << 18) | (((fine >> 17) & 0x7FF) << 8)
 *      byte_offset = ((fine_offset_base & 0xFFFFE000) | (fine & 0x1FFFF)) * 192
 *    - 按 time_45k 排序返回。
 *
 * 2. program languages：`_parse_clpi_program_languages` —— 给 mpv 軌道补语言
 *    标签（desktop 的 set_iso_track_languages 机制）：
 *    - program_info_start = u32be(data, 12)；program_count = data[program_info_start+5]
 *    - 每个 program：spn(4) + program_map_pid(2) + stream_count(1) + num_groups(1)
 *    - 每个 stream：pid(2) + len(1) + coding_type(1) + ...；len = 从 coding_type
 *      到条目尾的字节数；语言位置：PGS(0x90) 在条目+4，音频/Text 在条目+5，
 *      3 字母 ISO 639-2/T
 *    - kind：audio(0x03/0x04/0x80-0x87/0xA1/0xA2) / subtitle(0x90/0x92)，
 *      video/菜单无语言，跳过
 *    - 返回 (kind, lang) 列表，ProgramInfo 顺序
 */
object ClpiParser {

    fun parseEntryPoints(clipId: String, data: ByteArray): ParsedClpi {
        if (data.size < 20 || !(data[0] == 'H'.code.toByte() && data[1] == 'D'.code.toByte()
                    && data[2] == 'M'.code.toByte() && data[3] == 'V'.code.toByte())
        ) {
            throw IllegalArgumentException("无效的 Blu-ray clip info")
        }
        val sequenceStart = readU32BE(data, 8).toInt()
        val cpiStart = readU32BE(data, 16).toInt()
        val primaryPid = detectPrimaryStreamPid(data, sequenceStart)
        val entryPoints = parseEpMap(data, cpiStart, primaryPid)
        if (entryPoints.isEmpty()) throw IllegalArgumentException("Blu-ray clip info 中没有可用入口点")
        return ParsedClpi(clipId = clipId, entryPoints = entryPoints)
    }

    private fun detectPrimaryStreamPid(data: ByteArray, sequenceStart: Int): Int? {
        if (sequenceStart < 0 || sequenceStart + 6 > data.size) return null
        val atcCount = data[sequenceStart + 5].toInt() and 0xFF
        var cursor = sequenceStart + 6
        for (atcIndex in 0 until atcCount) {
            if (cursor + 6 > data.size) break
            val stcCount = data[cursor + 4].toInt() and 0xFF
            var stcCursor = cursor + 6
            for (stcIndex in 0 until stcCount) {
                if (stcCursor + 14 > data.size) break
                if (atcIndex == 0 && stcIndex == 0) return readU16BE(data, stcCursor)
                stcCursor += 14
            }
            cursor += stcCount * 14 + 6
        }
        return null
    }

    private fun parseEpMap(
        data: ByteArray,
        cpiStart: Int,
        primaryStreamPid: Int?,
    ): List<ClpiEntryPoint> {
        if (cpiStart < 0 || cpiStart + 10 > data.size) return emptyList()
        if ((readU16BE(data, cpiStart + 4) and 0x0F) != 1) return emptyList()
        val entryPoints = ArrayList<ClpiEntryPoint>()
        val epMapTableBase = cpiStart + 6
        val streamEntryCount = data[cpiStart + 7].toInt() and 0xFF
        var streamCursor = cpiStart + 8
        for (streamIndex in 0 until streamEntryCount) {
            if (streamCursor + 12 > data.size) break
            val streamPid = readU16BE(data, streamCursor)
            val coarseEntryCount = ((readU32BE(data, streamCursor + 3) shr 10) and 0xFFFF).toInt()
            val fineEntryCount0 = ((readU32BE(data, streamCursor + 5) shr 8) and 0x3FFFF).toInt()
            val epMapStart = readU32BE(data, streamCursor + 8).toInt() + epMapTableBase
            streamCursor += 12
            if (streamIndex != 0 && streamPid != primaryStreamPid) continue
            if (epMapStart < 0 || epMapStart + 4 > data.size) continue
            val coarseTableStart = epMapStart + 4
            val fineTableStart = epMapStart + readU32BE(data, epMapStart).toInt()
            if (coarseTableStart + coarseEntryCount * 8 > data.size) continue
            if (fineTableStart < 0 || fineTableStart >= data.size) continue
            val maxFineEntries = (data.size - fineTableStart) / 4
            val fineEntryCount = minOf(fineEntryCount0, maxFineEntries)
            for (coarseIndex in 0 until coarseEntryCount) {
                val coarseOffset = coarseTableStart + coarseIndex * 8
                val coarseEntry = readU32BE(data, coarseOffset)
                val fineIndexStart = ((coarseEntry shr 14) and 0x3FFFF).toInt()
                val fineOffsetBase = readU32BE(data, coarseOffset + 4)
                val fineIndexEnd = if (coarseIndex + 1 < coarseEntryCount) {
                    val nextCoarseOffset = coarseTableStart + (coarseIndex + 1) * 8
                    ((readU32BE(data, nextCoarseOffset) shr 14) and 0x3FFFF).toInt()
                } else fineEntryCount
                for (fineIndex in fineIndexStart until minOf(fineIndexEnd, fineEntryCount)) {
                    val fineOffset = fineTableStart + fineIndex * 4
                    val fineEntry = readU32BE(data, fineOffset)
                    entryPoints.add(
                        ClpiEntryPoint(
                            time45k = ((coarseEntry and 0x3FFEL) shl 18) or
                                (((fineEntry shr 17) and 0x7FFL) shl 8),
                            byteOffset = ((fineOffsetBase and 0xFFFFE000L) or
                                (fineEntry and 0x1FFFFL)) * 192,
                        )
                    )
                }
            }
        }
        return entryPoints.sortedBy { it.time45k }
    }

    /** (kind, lang) 列表，ProgramInfo 顺序；解析失败返回空（调用方按无语言处理） */
    fun parseProgramLanguages(data: ByteArray): List<Pair<String, String>> {
        try {
            if (data.size < 32 || !(data[0] == 'H'.code.toByte() && data[1] == 'D'.code.toByte()
                        && data[2] == 'M'.code.toByte() && data[3] == 'V'.code.toByte())
            ) return emptyList()
            val programInfoStart = readU32BE(data, 12).toInt()
            if (programInfoStart <= 0 || programInfoStart + 6 > data.size) return emptyList()
            val programCount = data[programInfoStart + 5].toInt() and 0xFF
            var cursor = programInfoStart + 6
            val result = ArrayList<Pair<String, String>>()
            repeat(programCount) {
                if (cursor + 8 > data.size) return result
                val streamCount = data[cursor + 6].toInt() and 0xFF
                cursor += 8
                repeat(streamCount) {
                    if (cursor + 3 > data.size) return result
                    val attrLen = data[cursor + 2].toInt() and 0xFF
                    val codingType = data[cursor + 3].toInt() and 0xFF
                    if (attrLen < 1 || cursor + 3 + attrLen > data.size) return result
                    val kind = codingTypeKind(codingType)
                    if (kind != null) {
                        // PGS(0x90) 语言在条目+4；音频/Text 在条目+5
                        val langOff = if (codingType == 0x90) cursor + 4 else cursor + 5
                        val lang = try {
                            data.copyOfRange(langOff, langOff + 3)
                                .toString(Charsets.US_ASCII).trim().lowercase()
                        } catch (_: Exception) {
                            ""
                        }
                        if (lang.length == 3 && lang.all { it.isLetter() }) {
                            result.add(kind to lang)
                        }
                    }
                    cursor += 3 + attrLen
                }
            }
            return result
        } catch (_: Exception) {
            return emptyList()
        }
    }

    internal fun codingTypeKind(codingType: Int): String? {
        if (codingType == 0x03 || codingType == 0x04 ||
            codingType in 0x80..0x87 || codingType == 0xA1 || codingType == 0xA2
        ) return "audio"
        if (codingType == 0x90 || codingType == 0x92) return "subtitle"
        return null
    }
}
