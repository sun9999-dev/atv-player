package com.xiaohei.atvplayer.iso

/**
 * ISO 播放数据模型 —— 对应 bluray_iso.py 的 dataclasses（行 38-135）。
 */
data class BluRayIsoStream(val path: String, val size: Long)

data class IsoPlaybackSegment(
    val streamPath: String,
    val streamSize: Long,
    val durationSeconds: Double,
    /** 逻辑流 -> 物理位置 的分段映射（_CachedIsoStreamSource 的 Kotlin 版） */
    val source: CachedIsoStreamSource,
)

data class IsoPlaybackPlan(
    val stream: BluRayIsoStream,
    /** 逻辑流分段（playlist 模式用；单 m2ts 时为 null，对应 Python 的 source=None） */
    val source: CachedIsoStreamSource?,
    val playlistSegments: List<IsoPlaybackSegment> = emptyList(),
    /** (kind, lang)：kind = "audio" / "subtitle"，ProgramInfo 顺序（v8 补丁） */
    val streamLanguages: List<Pair<String, String>> = emptyList(),
)

data class MplsPlayItem(
    val clipId: String,        // 如 "00001"
    val streamPath: String,    // /BDMV/STREAM/00001.M2TS
    val inTime: Long,          // 45kHz
    val outTime: Long,         // 45kHz
    val duration: Long,        // max(0, out-in)，45kHz
)

data class ParsedMplsPlaylist(
    val path: String,
    val playItems: List<MplsPlayItem>,
    val duration: Long,        // 45kHz 总和
)

data class ClpiEntryPoint(
    val time45k: Long,
    val byteOffset: Long,      // 已 *192（m2ts 包对齐）
)

data class ParsedClpi(
    val clipId: String,
    val entryPoints: List<ClpiEntryPoint>,   // 按 time_45k 排序
)

/** 逻辑偏移 -> ISO 物理偏移 的一段 */
data class CachedIsoSegment(
    val logicalOffset: Long,
    val length: Long,
    val physicalStart: Long,   // ISO 文件内的绝对字节偏移
)

data class CachedIsoStreamSource(
    val size: Long,             // 逻辑总大小
    val segments: List<CachedIsoSegment>,
    /** AD 类型 3（embedded）：文件数据内嵌，segments 为空时走这里 */
    val embeddedData: ByteArray? = null,
) {
    /**
     * 逻辑 [start, end]（闭区间）-> 物理分段。移植
     * `read_iso_stream_range_from_source` 的分段循环（bluray_iso.py:1497-1546）。
     */
    fun mapRange(start: Long, endInclusive: Long): List<Triple<Long, Long, Long>> {
        // Triple(physicalStart, physicalLength, logicalStartOfChunk)
        val out = ArrayList<Triple<Long, Long, Long>>()
        val total = size
        if (total <= 0 || start < 0 || start >= total) return out
        val end = minOf(endInclusive, total - 1)
        if (end < start) return out
        for (seg in segments) {
            val segEnd = seg.logicalOffset + seg.length - 1
            if (start > segEnd) continue
            if (end < seg.logicalOffset) break
            val localStart = maxOf(0L, start - seg.logicalOffset)
            val localEnd = minOf(seg.length - 1, end - seg.logicalOffset)
            val absStart = seg.physicalStart + localStart
            val absLen = localEnd - localStart + 1
            out.add(Triple(absStart, absLen, seg.logicalOffset + localStart))
            if (seg.logicalOffset + localEnd >= end) break
        }
        return out
    }
}
