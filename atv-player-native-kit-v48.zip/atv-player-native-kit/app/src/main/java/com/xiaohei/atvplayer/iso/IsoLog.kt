package com.xiaohei.atvplayer.iso

import android.util.Log

/** ISO 链路统一调试日志：adb logcat -s atviso */
object IsoLog {
    fun i(msg: String) {
        Log.i("atviso", msg)
    }

    fun e(msg: String, t: Throwable? = null) {
        if (t != null) Log.e("atviso", msg, t) else Log.e("atviso", msg)
    }
}
