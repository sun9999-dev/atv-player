package com.xiaohei.atvplayer.ui

import android.app.Activity
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

/** 设置页：播放器初始方向 / 预读时长（秒）/ 初始音量。改完即存。 */
class SettingsActivity : Activity() {

    private lateinit var preRollInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 设置页自身也遵从方向设置
        requestedOrientation = if (Prefs.orientation(this) == "portrait")
            android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        else
            android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE

        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(28), dp(24), dp(28), dp(24))
        }
        col.addView(TextView(this).apply {
            text = "设置"
            textSize = 24f
            setPadding(0, 0, 0, dp(16))
        })

        // 初始方向
        col.addView(TextView(this).apply { text = "播放器初始方向"; textSize = 18f })
        val rg = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val rbLand = RadioButton(this).apply { text = "横屏"; textSize = 17f }
        val rbPort = RadioButton(this).apply { text = "竖屏"; textSize = 17f }
        rg.addView(rbLand); rg.addView(rbPort)
        if (Prefs.orientation(this) == "portrait") rbPort.isChecked = true else rbLand.isChecked = true
        rg.setOnCheckedChangeListener { _, id ->
            val v = if (id == rbPort.id) "portrait" else "landscape"
            Prefs.setOrientation(this, v)
            requestedOrientation = if (v == "portrait")
                android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            else
                android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        }
        col.addView(rg)
        col.addView(TextView(this).apply {
            text = "播放中仍可用控制条的横/竖屏按钮临时切换"
            textSize = 13f
            setPadding(0, 0, 0, dp(18))
        })

        // 预读时长
        col.addView(TextView(this).apply { text = "预读时长（秒）"; textSize = 18f })
        preRollInput = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            textSize = 17f
            setText(Prefs.preRollSeconds(this@SettingsActivity).toString())
        }
        col.addView(preRollInput)
        col.addView(TextView(this).apply {
            text = "远程 ISO 起播前先预读几秒的内容（按片源平均码率换算成字节，受内存缓存上限封顶）；0 = 不预读"
            textSize = 13f
            setPadding(0, 0, 0, dp(18))
        })

        // 初始音量
        val volLabel = TextView(this).apply {
            text = "初始音量：${Prefs.volume(this@SettingsActivity)}"
            textSize = 18f
        }
        col.addView(volLabel)
        col.addView(SeekBar(this).apply {
            max = 100
            progress = Prefs.volume(this@SettingsActivity)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) {
                        Prefs.setVolume(this@SettingsActivity, p)
                        volLabel.text = "初始音量：$p"
                    }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        })

        // 播放默认语言（音轨 + 字幕）
        col.addView(TextView(this).apply {
            text = "播放默认语言（音轨+字幕）"
            textSize = 18f
            setPadding(0, dp(6), 0, 0)
        })
        val langOptions = listOf(
            "不指定（默认）" to "",
            "简体中文" to "zho",
            "繁體中文" to "zht",
            "English" to "eng",
            "日本語" to "jpn",
            "한국어" to "kor",
            "français" to "fra",
            "Deutsch" to "deu",
            "español" to "spa",
            "русский" to "rus",
        )
        val langGroup = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL }
        val currentLang = Prefs.defaultLanguage(this)
        langOptions.forEachIndexed { i, (label, code) ->
            val rb = RadioButton(this).apply {
                id = 1000 + i
                text = label
                textSize = 16f
                setOnClickListener { Prefs.setDefaultLanguage(this@SettingsActivity, code) }
            }
            langGroup.addView(rb)
            if (code == currentLang) langGroup.check(rb.id)
        }
        col.addView(langGroup)
        col.addView(TextView(this).apply {
            text = "片源里没有该语言时，按播放器默认处理"
            textSize = 13f
            setPadding(0, 0, 0, dp(20))
        })

        // 保存并关闭
        col.addView(Button(this).apply {
            text = "保存并关闭"
            textSize = 17f
            setOnClickListener {
                preRollInput.text.toString().toIntOrNull()
                    ?.let { Prefs.setPreRollSeconds(this@SettingsActivity, it) }
                finish()
            }
        })

        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onPause() {
        super.onPause()
        preRollInput.text.toString().toIntOrNull()?.let { Prefs.setPreRollSeconds(this, it) }
    }
}
