package com.xiaohei.atvplayer.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/**
 * atvplayer:// 调起入口。解包逻辑照抄 desktop 的 `_unwrap_scheme_url`
 *（standalone_player_atv_windows.py:235）：
 *   atvplayer://play?url=<内层> -> 内层；按 "?url=" 切一次（内层含 ?sign=/&/=，
 *   不能用 parse_qs）；http%3A 开头才 unquote 一次；其它原样（幂等）。
 * file/content 的 VIEW 也进这里，转给 PlayerActivity。
 */
class SchemeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val data: Uri? = intent?.data
        val raw = data?.toString() ?: ""
        val target = unwrapSchemeUrl(raw)
        val play = Intent(this, PlayerActivity::class.java).apply {
            action = Intent.ACTION_VIEW
            putExtra(PlayerActivity.EXTRA_INPUT, target)
            // content:// 进来时把读权限带过去
            data?.let {
                setData(it)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
        startActivity(play)
        finish()
    }

    companion object {
        fun unwrapSchemeUrl(text: String): String {
            if (!text.startsWith("atvplayer://")) return text
            val marker = "?url="
            val target = when {
                marker in text -> text.substringAfter(marker)
                text.startsWith("atvplayer://play/") ->
                    text.removePrefix("atvplayer://play/")
                else -> return text
            }
            if (target.isEmpty()) return text
            return if (target.startsWith("http%3A") || target.startsWith("https%3A") ||
                target.startsWith("HTTP%3A") || target.startsWith("HTTPS%3A")
            ) {
                Uri.decode(target)
            } else target
        }
    }
}
