package com.xiaohei.atvplayer.iso

/**
 * MPLS playlist 二进制解析 —— 完整移植 `_parse_mpls_playlist`
 *（bluray_iso.py:971-1014；v8 补丁只加了 STN 语言，playlist 结构本身未动）。
 *
 * MPLS 文件头：
 *   [0:4]   "MPLS"
 *   [8:12]  playlist_start（u32be）
 *   playlist_start 处：
 *     [0:4]   playlist_length（u32be，不含这 4 字节）
 *     header = playlist_start + 4
 *     [header+2:header+4] play_item_count（u16be）
 *     play_item_offset = header + 6
 *   每个 play item：
 *     [0:2]   item_length（u16be）
 *     item_start = play_item_offset + 2
 *     [item_start:item_start+5]   clip 名（ascii，如 "00001"）
 *     [item_start+5:item_start+9] codec（ascii，"M2TS" 才要）
 *     [item_start+12:item_start+16] in_time（u32be，45kHz）
 *     [item_start+16:item_start+20] out_time（u32be，45kHz）
 */
object MplsParser {

    fun parse(path: String, data: ByteArray): ParsedMplsPlaylist {
        if (data.size < 20 || !(data[0] == 'M'.code.toByte() && data[1] == 'P'.code.toByte()
                    && data[2] == 'L'.code.toByte() && data[3] == 'S'.code.toByte())
        ) {
            throw IllegalArgumentException("无效的 Blu-ray playlist")
        }
        val playlistStart = readU32BE(data, 8).toInt()
        val playlistLength = readU32BE(data, playlistStart).toInt()
        val playlistEnd = minOf(data.size, playlistStart + 4 + playlistLength)
        val headerOffset = playlistStart + 4
        val playItemCount = readU16BE(data, headerOffset + 2)
        var playItemOffset = headerOffset + 6
        val playItems = ArrayList<MplsPlayItem>()
        var totalDuration = 0L
        repeat(playItemCount) {
            val itemLength = readU16BE(data, playItemOffset)
            val itemStart = playItemOffset + 2
            val itemEnd = itemStart + itemLength
            if (itemEnd > playlistEnd || itemEnd > data.size) {
                throw IllegalArgumentException("MPLS play item 超出边界")
            }
            if (itemLength < 20) throw IllegalArgumentException("MPLS play item 长度无效")
            val clipName = data.copyOfRange(itemStart, itemStart + 5)
                .toString(Charsets.US_ASCII).trim().uppercase()
            val clipCodec = data.copyOfRange(itemStart + 5, itemStart + 9)
                .toString(Charsets.US_ASCII).trim().uppercase()
            val inTime = readU32BE(data, itemStart + 12)
            val outTime = readU32BE(data, itemStart + 16)
            val duration = maxOf(0L, outTime - inTime)
            if (clipName.isNotEmpty() && clipCodec == "M2TS") {
                playItems.add(
                    MplsPlayItem(
                        clipId = clipName,
                        streamPath = "/BDMV/STREAM/$clipName.M2TS",
                        inTime = inTime,
                        outTime = outTime,
                        duration = duration,
                    )
                )
                totalDuration += duration
            }
            playItemOffset = itemEnd
        }
        if (playItems.isEmpty()) throw IllegalArgumentException("Blu-ray playlist 中没有可播放的片段")
        return ParsedMplsPlaylist(
            path = normalizeIsoPath(path),
            playItems = playItems,
            duration = totalDuration,
        )
    }

    internal fun readU16BE(data: ByteArray, offset: Int): Int {
        if (offset < 0 || offset + 2 > data.size) throw IllegalArgumentException("MPLS 数据不完整")
        return ((data[offset].toInt() and 0xFF) shl 8) or (data[offset + 1].toInt() and 0xFF)
    }

    internal fun readU32BE(data: ByteArray, offset: Int): Long {
        if (offset < 0 || offset + 4 > data.size) throw IllegalArgumentException("MPLS 数据不完整")
        return ((data[offset].toLong() and 0xFF) shl 24) or
            ((data[offset + 1].toLong() and 0xFF) shl 16) or
            ((data[offset + 2].toLong() and 0xFF) shl 8) or
            (data[offset + 3].toLong() and 0xFF)
    }

    internal fun normalizeIsoPath(path: String): String =
        "/" + path.trim().trim('/').replace('\\', '/')
}
