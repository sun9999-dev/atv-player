plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.xiaohei.atvplayer"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.xiaohei.atvplayer"
        minSdk = 28          // Qt for Python 也是 28；低于 28 的老盒子不支持
        targetSdk = 35
        ndkVersion = "30.0.16248370" // 必须与 ndk.dir/SDK 里的 NDK 版本一致，否则 CXX1104
        versionCode = 1
        versionName = "0.1.0"

        // ABI 由 splits 控制（不能再设 ndk.abiFilters，AGP 会报 Conflicting configuration）
        externalNativeBuild {
            cmake {
                arguments += listOf("-DANDROID_STL=c++_shared")
            }
        }
    }

    // 按 ABI 分包：每个 APK 只含一个 ABI，体积小、装不錯。
    // 想要单包双 ABI（含两个 .so，体积翻倍）就把 universalApk 改 true。
    splits {
        abi {
            isEnable = true
            reset()
            include("arm64-v8a", "armeabi-v7a")
            isUniversalApk = false
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            // 调试包也分 ABI，方便直接 adb install 到 32 位盒子
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/jni/CMakeLists.txt")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    // HTTP：签名链接（SignedUrl.kt 用）
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    // Leanback：TV 启动器图标（键鼠操作，不做 DPAD 导航）
    implementation("androidx.leanback:leanback:1.2.0")
}
