# atv-player-native（Android 原生版）

**一套代码，两个 ABI**：`arm64-v8a`（64 位 TV / Pad）+ `armeabi-v7a`（32 位 TV，
很多 TV 盒子是 arm64 SoC 但跑 32 位系统）。PySide6 路线走不通 32 位
（包内 CPython 3.14 没有 32 位目标），所以 Android 用原生 Kotlin + libmpv，
双 ABI 只是两次编译，维护只有一份代码。

目标设备：Android TV（**键盘+鼠标**，不考虑遥控器/DPAD）+ Android Pad（触摸）。
不做手机。

## 代码来源

完整移植 desktop 独立播放器（上游 v0.105.0 + 补丁）的核心链路：
签名 URL（`SignedUrl.kt`）→ Blu-ray ISO 解析（`iso/`，UDF/MPLS/CLPI 全移植）
→ 本地代理（`proxy/IsoProxyServer.kt`，`/iso/` + `/m3u/`）→ libmpv 渲染
（`mpv_jni.c` + `mpv/`，`vo=gpu-next` / `hwdec=auto-safe`，与 desktop render
路径一致）→ 播放器 UI（`ui/`）。

详细映射与风险点见 [PORTING.md](PORTING.md)，**先读它再动手**。

## 构建

1. 准备 libmpv（双 ABI）：
   ```bash
   ./build-libmpv-native.sh
   # 选项：--arch arm64|armv7l|both（默认 both）
   #       --from-apk mpv-android.apk（捷径验证，不用编）
   #       --mpv-android-dir ~/src/mpv-android
   ```
   产物进 `app/src/main/jniLibs/{arm64-v8a,armeabi-v7a}/`，头文件进
   `app/src/main/jni/include/mpv/`。
2. 打包：
   ```bash
   ./build.sh            # release，按 ABI 分包（两个 APK）
   ./build.sh --debug    # 调试包
   ./build.sh --universal # 单包双 ABI（体积翻倍，不推荐）
   ```
   产物：`app/build/outputs/apk/release/`。
3. 查设备装哪个：
   ```bash
   ./check-device-abi.sh   # adb 连上后跑
   adb install app/build/outputs/apk/release/app-arm64-v8a-release.apk
   ```

环境：JDK 17、Android SDK（platform 35、build-tools 35、NDK r28c）。
Gradle wrapper 需联网下载（或本机已有 gradle 时改用系统 gradle）。

## 功能

- `atvplayer://play?url=...` 调起（与桌面端同 scheme，解包逻辑一致）
- 链接直播（mkv / http(s)）
- 本地文件（SAF 选择；`content://` v1 拷 cache）
- 本地 / 远程签名 URL 的 Blu-ray ISO：解析 playlist→拼 m2ts→代理→播放，
  音轨/字幕语言标签来自 `.clpi` ProgramInfo（与 desktop v8 补丁一致）
- 播放控制：播放/暂停、进度条、音轨/字幕菜单；键盘空格/方向键/音量

## 验证顺序

1. `./check-device-abi.sh` 确认设备 ABI 与 API（≥28）
2. 先播直链 mkv（验证 libmpv + JNI + 渲染通路）
3. 再播本地小 ISO（验证 UDF→MPLS→CLPI→代理全链，见 PORTING.md 第二节）
4. 再播远程签名 ISO（验证 SignedUrl）
5. 最后 `adb shell am start -a android.intent.action.VIEW -d "atvplayer://play?url=..."` 验证调起

## 已知 TODO

- `content://` 大 ISO 的 fd 直通（v1 全拷 cache，大文件慢）
- UDF 的 metadata 分区（Blu-ray 罕见，遇到再实现）
- File Entry AD 类型的启发式判定 → 必要时改从 icbtag.flags 取（PORTING.md 二-2）
- 真机联调前建议先给 `iso/` 写 JVM 单元测试（不依赖 Android）

## GPL

libmpv + ffmpeg 是 GPL；分发 APK 时提供源码获取方式。本 kit 代码建议 GPLv3+。
