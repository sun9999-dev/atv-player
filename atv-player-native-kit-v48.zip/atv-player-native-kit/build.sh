#!/usr/bin/env bash
# 打包 atv-player-native。先跑 ./build-libmpv-native.sh 准备好 jniLibs。
# 用法：./build.sh [--debug] [--universal]
#   默认 release + 按 ABI 分包（两个 APK）；--universal 打单包双 ABI（体积大）。
set -euo pipefail
KIT_DIR="$(cd "$(dirname "$0")" && pwd)"
MODE="release"
UNIVERSAL=0
for a in "$@"; do
  case "$a" in
    --debug) MODE="debug" ;;
    --universal) UNIVERSAL=1 ;;
  esac
done

if [[ ! -d "$KIT_DIR/app/src/main/jniLibs/arm64-v8a" ]]; then
  echo "jniLibs 为空：先跑 ./build-libmpv-native.sh"
  exit 1
fi

# --- Java 17+（AGP 8.x 硬性要求；默认 java 是 11 时自动挑 17/21）---
java_major() { java -version 2>&1 | head -n1 | sed -E 's/.*version "([0-9]+).*/\1/'; }
if [[ "$(java_major 2>/dev/null || echo 0)" -lt 17 ]]; then
  for j in /usr/lib/jvm/java-21-openjdk-* /usr/lib/jvm/java-17-openjdk-* "$HOME"/.sdkman/candidates/java/17.* "$HOME"/.sdkman/candidates/java/21.*; do
    [[ -x "$j/bin/java" ]] && export JAVA_HOME="$j" && break
  done
  if [[ "$(java_major 2>/dev/null || echo 0)" -lt 17 ]]; then
    echo "需要 JDK 17+，当前 java 太老。装：sudo apt install openjdk-17-jdk，或设 JAVA_HOME"
    exit 1
  fi
  echo "JAVA_HOME=$JAVA_HOME"
fi

# --- SDK 定位（Gradle 只认 local.properties / ANDROID_HOME）---
# 本机没有独立装 SDK 时，复用 mpv-android 下载的那份（buildscripts/sdk/android-sdk-*）。
if [[ ! -f "$KIT_DIR/local.properties" ]]; then
  SDK_DIR="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}"
  if [[ -z "$SDK_DIR" || ! -d "$SDK_DIR/platforms" ]]; then
    SDK_DIR=""
    for cand in "$HOME/Android/Sdk" "$HOME/src/mpv-android/buildscripts/sdk"/android-sdk-* /usr/lib/android-sdk; do
      [[ -d "$cand/platforms" ]] && SDK_DIR="$cand" && break
    done
  fi
  if [[ -n "$SDK_DIR" ]]; then
    {
      echo "sdk.dir=$SDK_DIR"
      # mpv-android 的 NDK 是独立目录（sdk/android-ndk-r30），AGP 找不到 side-by-side 时用 ndk.dir 指过去
      if [[ ! -d "$SDK_DIR/ndk" ]]; then
        for n in "$(dirname "$SDK_DIR")"/android-ndk-*; do
          [[ -f "$n/source.properties" ]] && echo "ndk.dir=$n" && break
        done
      fi
    } > "$KIT_DIR/local.properties"
    echo "local.properties -> $KIT_DIR/local.properties"; cat "$KIT_DIR/local.properties"
  else
    echo "找不到 Android SDK：设 ANDROID_HOME，或先跑 mpv-android 的 download.sh"
    exit 1
  fi
else
  SDK_DIR="$(sed -n 's/^sdk.dir=//p' "$KIT_DIR/local.properties" | head -n1)"
fi

# --- ndkVersion 同步（ndk.dir 的 NDK 版本与 gradle 的 ndkVersion 不一致会报 CXX1104）---
NDK_DIR_LINE="$(sed -n 's/^ndk.dir=//p' "$KIT_DIR/local.properties" 2>/dev/null | head -n1)"
if [[ -n "$NDK_DIR_LINE" && -f "$NDK_DIR_LINE/source.properties" ]]; then
  NDK_VER="$(sed -n 's/^Pkg.Revision = //p' "$NDK_DIR_LINE/source.properties" | head -n1 | tr -d ' \r')"
  if [[ -n "$NDK_VER" ]] && ! grep -q "ndkVersion = \"$NDK_VER\"" "$KIT_DIR/app/build.gradle.kts"; then
    sed -i -E "s/ndkVersion = \"[^\"]*\"/ndkVersion = \"$NDK_VER\"/" "$KIT_DIR/app/build.gradle.kts"
    echo "ndkVersion 已同步为 $NDK_VER"
  fi
fi

# --- 补齐 SDK 组件（compileSdk 35 + AGP 默认 build-tools + CMake；mpv-android 的 SDK 里没有）---
SDKMANAGER=""
for m in "$SDK_DIR/cmdline-tools/latest/bin/sdkmanager" "$SDK_DIR/cmdline-tools/bin/sdkmanager"; do
  [[ -x "$m" ]] && SDKMANAGER="$m" && break
done
if [[ -n "$SDKMANAGER" ]]; then
  PKGS=()
  [[ -d "$SDK_DIR/platforms/android-35" ]] || PKGS+=("platforms;android-35")
  [[ -d "$SDK_DIR/build-tools/35.0.0" ]] || PKGS+=("build-tools;35.0.0")
  ls "$SDK_DIR"/cmake/*/bin/cmake >/dev/null 2>&1 || PKGS+=("cmake;3.22.1")
  if [[ ${#PKGS[@]} -gt 0 ]]; then
    echo "补装 SDK 组件：${PKGS[*]}"
    yes | "$SDKMANAGER" --sdk_root="$SDK_DIR" "${PKGS[@]}" >/dev/null
  fi
fi

# --universal：临时改 splits（不污染 git，用完还原）
GRADLE_FILE="$KIT_DIR/app/build.gradle.kts"
BACKUP="$GRADLE_FILE.bak"
if [[ "$UNIVERSAL" == 1 ]]; then
  cp "$GRADLE_FILE" "$BACKUP"
  python3 - "$GRADLE_FILE" <<'PY'
import sys
p = sys.argv[1]
t = open(p).read()
t = t.replace("isUniversalApk = false", "isUniversalApk = true")
open(p, "w").write(t)
PY
  trap 'mv "$BACKUP" "$GRADLE_FILE"' EXIT
fi

cd "$KIT_DIR"
if [[ "$MODE" == "debug" ]]; then
  ./gradlew assembleDebug
  echo "产物：app/build/outputs/apk/debug/"
else
  ./gradlew assembleRelease
  echo "产物：app/build/outputs/apk/release/"
fi
ls app/build/outputs/apk/$MODE/
