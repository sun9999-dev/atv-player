#!/usr/bin/env bash
# 查目标设备的 ABI，决定装哪个 APK（arm64-v8a / armeabi-v7a）。
set -euo pipefail
command -v adb >/dev/null || { echo "缺少 adb"; exit 1; }
ABI="$(adb shell getprop ro.product.cpu.abi 2>/dev/null | tr -d '\r')"
API="$(adb shell getprop ro.build.version.sdk 2>/dev/null | tr -d '\r')"
MODEL="$(adb shell getprop ro.product.model 2>/dev/null | tr -d '\r')"
echo "机型：$MODEL / ABI：$ABI / API：$API"
case "$ABI" in
  arm64-v8a) echo "装 app-arm64-v8a-release.apk" ;;
  armeabi-v7a) echo "装 app-armeabi-v7a-release.apk（32 位系统，PySide6 版装不上，原生版可以）" ;;
  *) echo "未知 ABI" ;;
esac
[[ "${API:-0}" -ge 28 ]] || echo "注意：API < 28 不支持"
