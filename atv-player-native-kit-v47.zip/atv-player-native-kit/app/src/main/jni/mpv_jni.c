/* atvplayer JNI 胶水：libmpv render API（OpenGL）。
 *
 * 覆盖的子集（对照 desktop 的 mpv_widget.py render 路径）：
 *   create / init / terminate_destroy
 *   command_string, set_property_string, get_property_string
 *   observe_property / unobserve_property, wait_event pump -> onEvent 回调
 *   render_context_create (OPENGL, get_proc_address=eglGetProcAddress)
 *   render_context_render / report_swap / set_update_callback(onRenderUpdate) / free
 *
 * 线程模型：event pump 跑在独立 pthread，通过 JNI 回调 Kotlin；
 * render 由 GLSurfaceView 的 GL 线程调用。
 */
#include <jni.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <android/log.h>
#include <EGL/egl.h>
#include <mpv/client.h>
#include <mpv/render.h>
#include <mpv/render_gl.h>

// FFmpeg 的 JVM 注册（libavcodec/jni.h）：mpv 的 aimagereader/mediacodec 通过
// av_jni_get_java_vm() 取 JVM，不注册就报 "No Java virtual machine has been registered"
int av_jni_set_java_vm(void *vm, void *log_ctx);

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved) {
    (void)reserved;
    av_jni_set_java_vm(vm, NULL);
    return JNI_VERSION_1_6;
}

#define LOG_TAG "atvplayer_jni"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

typedef struct {
    JavaVM *jvm;
    jobject callback;          // 全局引用：com.xiaohei.atvplayer.mpv.Mpv$EventCallback
    jmethodID on_event;        // onEvent(String name, String data)
    jmethodID on_update;       // onRenderUpdate()
    mpv_handle *mpv;
    char *ca_file;             // tls-ca-file 路径（curl/ffmpeg 在 Android 上没有系统 CA 包）
    int cache_mib;             // demuxer-max-bytes（按设备内存分档，Kotlin 传入）
    int back_cache_mib;        // demuxer-max-back-bytes
    mpv_render_context *render_ctx;
    pthread_t event_thread;
    int event_thread_running;
} ctx_t;

static void *get_proc_addr(void *fn_ctx, const char *name) {
    (void)fn_ctx;
    return (void *)eglGetProcAddress(name);
}

static void on_mpv_render_update(void *callback_ctx) {
    ctx_t *c = (ctx_t *)callback_ctx;
    JNIEnv *env = NULL;
    int attached = 0;
    // mpv 从它自己的线程调这个回调，那些线程没 attach 到 JVM 时 GetEnv 返回
    // JNI_EDETACHED——旧代码直接 return，requestRender 永远不触发，
    // WHEN_DIRTY 模式下画面永远停在首帧（黑屏有声）。必须先 attach。
    if ((*c->jvm)->GetEnv(c->jvm, (void **)&env, JNI_VERSION_1_6) != JNI_OK) {
        if ((*c->jvm)->AttachCurrentThread(c->jvm, &env, NULL) != JNI_OK) return;
        attached = 1;
    }
    (*env)->CallVoidMethod(env, c->callback, c->on_update);
    if ((*env)->ExceptionCheck(env)) (*env)->ExceptionClear(env);
    if (attached) (*c->jvm)->DetachCurrentThread(c->jvm);
}

static const char *event_name(mpv_event_id id) {
    switch (id) {
        case MPV_EVENT_SHUTDOWN: return "shutdown";
        case MPV_EVENT_LOG_MESSAGE: return "log-message";
        case MPV_EVENT_FILE_LOADED: return "file-loaded";
        case MPV_EVENT_END_FILE: return "end-file";
        case MPV_EVENT_PROPERTY_CHANGE: return "property-change";
        default: return "unknown";
    }
}

static void *event_pump(void *arg) {
    ctx_t *c = (ctx_t *)arg;
    JNIEnv *env = NULL;
    (*c->jvm)->AttachCurrentThread(c->jvm, &env, NULL);
    while (c->event_thread_running) {
        mpv_event *ev = mpv_wait_event(c->mpv, 1.0);
        if (ev->event_id == MPV_EVENT_NONE) continue;
        if (ev->event_id == MPV_EVENT_SHUTDOWN) {
            c->event_thread_running = 0;
        }
        if (ev->event_id == MPV_EVENT_LOG_MESSAGE) {
            mpv_event_log_message *lm = (mpv_event_log_message *)ev->data;
            if (lm && lm->text) {
                // text 自带换行，掐掉尾巴再打
                char buf[1024];
                snprintf(buf, sizeof(buf) - 1, "%s", lm->text);
                size_t n = strlen(buf);
                while (n > 0 && (buf[n - 1] == '\n' || buf[n - 1] == '\r')) buf[--n] = 0;
                __android_log_print(ANDROID_LOG_INFO, "mpv",
                                    "[%s] %s: %s", lm->level ? lm->level : "?",
                                    lm->prefix ? lm->prefix : "?", buf);
            }
            continue;
        }
        const char *name = event_name(ev->event_id);
        char data[256] = {0};
        if (ev->event_id == MPV_EVENT_PROPERTY_CHANGE) {
            mpv_event_property *prop = (mpv_event_property *)ev->data;
            snprintf(data, sizeof(data) - 1, "%s", prop->name ? prop->name : "");
        } else if (ev->event_id == MPV_EVENT_END_FILE) {
            mpv_event_end_file *ef = (mpv_event_end_file *)ev->data;
            snprintf(data, sizeof(data) - 1, "reason=%d", (int)ef->reason);
        }
        jstring jname = (*env)->NewStringUTF(env, name);
        jstring jdata = (*env)->NewStringUTF(env, data);
        (*env)->CallVoidMethod(env, c->callback, c->on_event, jname, jdata);
        (*env)->DeleteLocalRef(env, jname);
        (*env)->DeleteLocalRef(env, jdata);
    }
    (*c->jvm)->DetachCurrentThread(c->jvm);
    return NULL;
}

static ctx_t *get_ctx(JNIEnv *env, jobject thiz) {
    jclass cls = (*env)->GetObjectClass(env, thiz);
    jfieldID fid = (*env)->GetFieldID(env, cls, "nativeCtx", "J");
    return (ctx_t *)(intptr_t)(*env)->GetLongField(env, thiz, fid);
}

static void set_ctx(JNIEnv *env, jobject thiz, ctx_t *c) {
    jclass cls = (*env)->GetObjectClass(env, thiz);
    jfieldID fid = (*env)->GetFieldID(env, cls, "nativeCtx", "J");
    (*env)->SetLongField(env, thiz, fid, (jlong)(intptr_t)c);
}

JNIEXPORT void JNICALL
Java_com_xiaohei_atvplayer_mpv_Mpv_nativeCreate(JNIEnv *env, jobject thiz, jobject callback, jstring ca_path, jint cache_mib, jint back_cache_mib) {
    ctx_t *c = (ctx_t *)calloc(1, sizeof(ctx_t));
    (*env)->GetJavaVM(env, &c->jvm);
    c->callback = (*env)->NewGlobalRef(env, callback);
    jclass cb_cls = (*env)->GetObjectClass(env, callback);
    c->on_event = (*env)->GetMethodID(env, cb_cls, "onEvent", "(Ljava/lang/String;Ljava/lang/String;)V");
    c->on_update = (*env)->GetMethodID(env, cb_cls, "onRenderUpdate", "()V");
    c->cache_mib = cache_mib;
    c->back_cache_mib = back_cache_mib;
    if (ca_path) {
        const char *p = (*env)->GetStringUTFChars(env, ca_path, NULL);
        if (p) { c->ca_file = strdup(p); (*env)->ReleaseStringUTFChars(env, ca_path, p); }
    }
    c->mpv = mpv_create();
    if (!c->mpv) {
        LOGE("mpv_create returned NULL (check LC_NUMERIC / library load)");
    } else {
        // mpv 自身日志转发到 logcat（tag=mpv）：打开失败/TLS/解码错误都从这里定性
        mpv_request_log_messages(c->mpv, "info");
    }
    set_ctx(env, thiz, c);
}

JNIEXPORT jint JNICALL
Java_com_xiaohei_atvplayer_mpv_Mpv_nativeInit(JNIEnv *env, jobject thiz) {
    ctx_t *c = get_ctx(env, thiz);
    if (!c || !c->mpv) return -1;
    // 与 desktop mpv_widget.py 的 render 路径一致：vo=libmpv, hwdec=auto-safe
    if (c->ca_file) mpv_set_option_string(c->mpv, "tls-ca-file", c->ca_file);
    // render API 的 VO 驱动名就叫 libmpv（渲染后端由 render 参数的
    // API_TYPE=OPENGL 选到 gpu 后端，render_backends[] 只有 gpu/sw）。
    // 写 gpu/gpu-next 都是在选独立窗口驱动，会去要 Android surface
    // （"Missing surface pointer"，实测两轮）。
    mpv_set_option_string(c->mpv, "vo", "libmpv");
    mpv_set_option_string(c->mpv, "hwdec", "auto-safe");
    // 远程 ISO 经本地代理喂数据，拉取有秒级抖动：mpv 侧缓存开大兜底
    // （大小由 Kotlin 按设备内存分档传入，见 CacheTuning）
    mpv_set_option_string(c->mpv, "cache", "yes");
    {
        char buf[32];
        snprintf(buf, sizeof(buf), "%dMiB", c->cache_mib > 0 ? c->cache_mib : 128);
        mpv_set_option_string(c->mpv, "demuxer-max-bytes", buf);
        snprintf(buf, sizeof(buf), "%dMiB", c->back_cache_mib > 0 ? c->back_cache_mib : 32);
        mpv_set_option_string(c->mpv, "demuxer-max-back-bytes", buf);
    }
    mpv_set_option_string(c->mpv, "gpu-api", "opengl");
    mpv_set_option_string(c->mpv, "opengl-es", "yes");
    int r = mpv_initialize(c->mpv);
    if (r < 0) {
        LOGE("mpv_initialize failed: %s", mpv_error_string(r));
        return r;
    }
    c->event_thread_running = 1;
    pthread_create(&c->event_thread, NULL, event_pump, c);
    return 0;
}

JNIEXPORT void JNICALL
Java_com_xiaohei_atvplayer_mpv_Mpv_nativeCommand(JNIEnv *env, jobject thiz, jobjectArray args) {
    ctx_t *c = get_ctx(env, thiz);
    if (!c || !c->mpv) return;
    jsize n = (*env)->GetArrayLength(env, args);
    const char **argv = (const char **)calloc((size_t)n + 1, sizeof(char *));
    for (jsize i = 0; i < n; i++) {
        jstring s = (jstring)(*env)->GetObjectArrayElement(env, args, i);
        argv[i] = (*env)->GetStringUTFChars(env, s, NULL);
    }
    argv[n] = NULL;
    mpv_command(c->mpv, argv);
    for (jsize i = 0; i < n; i++) {
        jstring s = (jstring)(*env)->GetObjectArrayElement(env, args, i);
        (*env)->ReleaseStringUTFChars(env, s, argv[i]);
        (*env)->DeleteLocalRef(env, s);
    }
    free(argv);
}

JNIEXPORT void JNICALL
Java_com_xiaohei_atvplayer_mpv_Mpv_nativeSetPropertyString(JNIEnv *env, jobject thiz, jstring jname, jstring jvalue) {
    ctx_t *c = get_ctx(env, thiz);
    if (!c || !c->mpv) return;
    const char *name = (*env)->GetStringUTFChars(env, jname, NULL);
    const char *value = jvalue ? (*env)->GetStringUTFChars(env, jvalue, NULL) : NULL;
    mpv_set_property_string(c->mpv, name, value);
    (*env)->ReleaseStringUTFChars(env, jname, name);
    if (jvalue) (*env)->ReleaseStringUTFChars(env, jvalue, value);
}

JNIEXPORT jstring JNICALL
Java_com_xiaohei_atvplayer_mpv_Mpv_nativeGetPropertyString(JNIEnv *env, jobject thiz, jstring jname) {
    ctx_t *c = get_ctx(env, thiz);
    if (!c || !c->mpv) return NULL;
    const char *name = (*env)->GetStringUTFChars(env, jname, NULL);
    char *value = mpv_get_property_string(c->mpv, name);
    (*env)->ReleaseStringUTFChars(env, jname, name);
    if (!value) return NULL;
    jstring ret = (*env)->NewStringUTF(env, value);
    mpv_free(value);
    return ret;
}

JNIEXPORT void JNICALL
Java_com_xiaohei_atvplayer_mpv_Mpv_nativeObserveProperty(JNIEnv *env, jobject thiz, jstring jname) {
    ctx_t *c = get_ctx(env, thiz);
    if (!c || !c->mpv) return;
    const char *name = (*env)->GetStringUTFChars(env, jname, NULL);
    mpv_observe_property(c->mpv, 0, name, MPV_FORMAT_STRING);
    (*env)->ReleaseStringUTFChars(env, jname, name);
}

JNIEXPORT jint JNICALL
Java_com_xiaohei_atvplayer_mpv_Mpv_nativeRenderInit(JNIEnv *env, jobject thiz) {
    ctx_t *c = get_ctx(env, thiz);
    if (!c || !c->mpv || c->render_ctx) return c && c->render_ctx ? 0 : -1;
    mpv_opengl_init_params gl_params = { .get_proc_address = get_proc_addr, .get_proc_address_ctx = NULL };
    mpv_render_param params[] = {
        { MPV_RENDER_PARAM_API_TYPE, (void *)MPV_RENDER_API_TYPE_OPENGL },
        { MPV_RENDER_PARAM_OPENGL_INIT_PARAMS, &gl_params },
        { 0, NULL },
    };
    int r = mpv_render_context_create(&c->render_ctx, c->mpv, params);
    if (r < 0) {
        LOGE("mpv_render_context_create failed: %s", mpv_error_string(r));
        return r;
    }
    mpv_render_context_set_update_callback(c->render_ctx, on_mpv_render_update, c);
    return 0;
}

JNIEXPORT void JNICALL
Java_com_xiaohei_atvplayer_mpv_Mpv_nativeRender(JNIEnv *env, jobject thiz, jint w, jint h) {
    ctx_t *c = get_ctx(env, thiz);
    if (!c || !c->render_ctx) return;
    mpv_opengl_fbo fbo = { .fbo = 0, .w = w, .h = h, .internal_format = 0 };
    int flip_y = 1;
    mpv_render_param params[] = {
        { MPV_RENDER_PARAM_OPENGL_FBO, &fbo },
        { MPV_RENDER_PARAM_FLIP_Y, &flip_y },
        { 0, NULL },
    };
    int rr = mpv_render_context_render(c->render_ctx, params);
    if (rr < 0) LOGE("mpv_render_context_render failed: %s", mpv_error_string(rr));
}

JNIEXPORT void JNICALL
Java_com_xiaohei_atvplayer_mpv_Mpv_nativeReportSwap(JNIEnv *env, jobject thiz) {
    ctx_t *c = get_ctx(env, thiz);
    if (c && c->render_ctx) mpv_render_context_report_swap(c->render_ctx);
}

JNIEXPORT void JNICALL
Java_com_xiaohei_atvplayer_mpv_Mpv_nativeDestroy(JNIEnv *env, jobject thiz) {
    ctx_t *c = get_ctx(env, thiz);
    if (!c) return;
    c->event_thread_running = 0;
    if (c->event_thread) pthread_join(c->event_thread, NULL);
    if (c->render_ctx) mpv_render_context_free(c->render_ctx);
    if (c->mpv) mpv_terminate_destroy(c->mpv);
    if (c->callback) (*env)->DeleteGlobalRef(env, c->callback);
    free(c->ca_file);
    free(c);
    set_ctx(env, thiz, NULL);
}
